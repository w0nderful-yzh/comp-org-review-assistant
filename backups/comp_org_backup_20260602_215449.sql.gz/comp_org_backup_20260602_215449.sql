--
-- PostgreSQL database dump
--

\restrict gLbEBwcZ2cZdKocsJf19bfdyAUGqDDabh6q7ZmJfnIAQ1beCApx2LpqN3xhPbQj

-- Dumped from database version 16.13 (Debian 16.13-1.pgdg12+1)
-- Dumped by pg_dump version 16.13 (Debian 16.13-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.wrong_questions DROP CONSTRAINT IF EXISTS wrong_questions_question_id_fkey;
ALTER TABLE IF EXISTS ONLY public.questions DROP CONSTRAINT IF EXISTS questions_parent_question_id_fkey;
ALTER TABLE IF EXISTS ONLY public.questions DROP CONSTRAINT IF EXISTS questions_knowledge_point_id_fkey;
ALTER TABLE IF EXISTS ONLY public.questions DROP CONSTRAINT IF EXISTS questions_chapter_id_fkey;
ALTER TABLE IF EXISTS ONLY public.question_feedback DROP CONSTRAINT IF EXISTS question_feedback_question_id_fkey;
ALTER TABLE IF EXISTS ONLY public.practice_sessions DROP CONSTRAINT IF EXISTS practice_sessions_chapter_id_fkey;
ALTER TABLE IF EXISTS ONLY public.knowledge_points DROP CONSTRAINT IF EXISTS knowledge_points_chapter_id_fkey;
ALTER TABLE IF EXISTS ONLY public.knowledge_chunks DROP CONSTRAINT IF EXISTS knowledge_chunks_chapter_id_fkey;
ALTER TABLE IF EXISTS ONLY public.answer_records DROP CONSTRAINT IF EXISTS answer_records_session_id_fkey;
ALTER TABLE IF EXISTS ONLY public.answer_records DROP CONSTRAINT IF EXISTS answer_records_question_id_fkey;
DROP INDEX IF EXISTS public.idx_wrong_questions_user_mastered;
DROP INDEX IF EXISTS public.idx_users_student_id;
DROP INDEX IF EXISTS public.idx_questions_parent_question_id;
DROP INDEX IF EXISTS public.idx_questions_chapter_type_reviewed;
DROP INDEX IF EXISTS public.idx_questions_ai_status;
DROP INDEX IF EXISTS public.idx_question_feedback_question_id;
DROP INDEX IF EXISTS public.idx_practice_sessions_user_id;
DROP INDEX IF EXISTS public.idx_knowledge_points_chapter_id;
DROP INDEX IF EXISTS public.idx_knowledge_chunks_chapter_id;
DROP INDEX IF EXISTS public.idx_answer_records_session_id;
ALTER TABLE IF EXISTS ONLY public.wrong_questions DROP CONSTRAINT IF EXISTS wrong_questions_user_id_question_id_key;
ALTER TABLE IF EXISTS ONLY public.wrong_questions DROP CONSTRAINT IF EXISTS wrong_questions_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_student_id_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.questions DROP CONSTRAINT IF EXISTS questions_pkey;
ALTER TABLE IF EXISTS ONLY public.question_feedback DROP CONSTRAINT IF EXISTS question_feedback_user_id_question_id_key;
ALTER TABLE IF EXISTS ONLY public.question_feedback DROP CONSTRAINT IF EXISTS question_feedback_pkey;
ALTER TABLE IF EXISTS ONLY public.practice_sessions DROP CONSTRAINT IF EXISTS practice_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.knowledge_points DROP CONSTRAINT IF EXISTS knowledge_points_pkey;
ALTER TABLE IF EXISTS ONLY public.knowledge_points DROP CONSTRAINT IF EXISTS knowledge_points_chapter_id_name_key;
ALTER TABLE IF EXISTS ONLY public.knowledge_chunks DROP CONSTRAINT IF EXISTS knowledge_chunks_pkey;
ALTER TABLE IF EXISTS ONLY public.knowledge_chunks DROP CONSTRAINT IF EXISTS knowledge_chunks_chunk_id_key;
ALTER TABLE IF EXISTS ONLY public.chapters DROP CONSTRAINT IF EXISTS chapters_source_file_key;
ALTER TABLE IF EXISTS ONLY public.chapters DROP CONSTRAINT IF EXISTS chapters_pkey;
ALTER TABLE IF EXISTS ONLY public.chapters DROP CONSTRAINT IF EXISTS chapters_order_index_key;
ALTER TABLE IF EXISTS ONLY public.answer_records DROP CONSTRAINT IF EXISTS answer_records_session_id_question_id_key;
ALTER TABLE IF EXISTS ONLY public.answer_records DROP CONSTRAINT IF EXISTS answer_records_pkey;
ALTER TABLE IF EXISTS public.wrong_questions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.questions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.question_feedback ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.practice_sessions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.knowledge_points ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.knowledge_chunks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.chapters ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.answer_records ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.wrong_questions_id_seq;
DROP TABLE IF EXISTS public.wrong_questions;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.questions_id_seq;
DROP TABLE IF EXISTS public.questions;
DROP SEQUENCE IF EXISTS public.question_feedback_id_seq;
DROP TABLE IF EXISTS public.question_feedback;
DROP SEQUENCE IF EXISTS public.practice_sessions_id_seq;
DROP TABLE IF EXISTS public.practice_sessions;
DROP SEQUENCE IF EXISTS public.knowledge_points_id_seq;
DROP TABLE IF EXISTS public.knowledge_points;
DROP SEQUENCE IF EXISTS public.knowledge_chunks_id_seq;
DROP TABLE IF EXISTS public.knowledge_chunks;
DROP SEQUENCE IF EXISTS public.chapters_id_seq;
DROP TABLE IF EXISTS public.chapters;
DROP SEQUENCE IF EXISTS public.answer_records_id_seq;
DROP TABLE IF EXISTS public.answer_records;
DROP TYPE IF EXISTS public.question_type;
DROP TYPE IF EXISTS public.question_difficulty;
DROP TYPE IF EXISTS public.practice_mode;
DROP EXTENSION IF EXISTS vector;
--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: practice_mode; Type: TYPE; Schema: public; Owner: comp_org
--

CREATE TYPE public.practice_mode AS ENUM (
    'chapter',
    'final_review',
    'wrong_questions'
);


ALTER TYPE public.practice_mode OWNER TO comp_org;

--
-- Name: question_difficulty; Type: TYPE; Schema: public; Owner: comp_org
--

CREATE TYPE public.question_difficulty AS ENUM (
    'easy',
    'medium',
    'hard'
);


ALTER TYPE public.question_difficulty OWNER TO comp_org;

--
-- Name: question_type; Type: TYPE; Schema: public; Owner: comp_org
--

CREATE TYPE public.question_type AS ENUM (
    'single_choice',
    'multiple_choice',
    'true_false',
    'fill_blank',
    'short_answer',
    'calculation',
    'question_group',
    'cloze',
    'matching'
);


ALTER TYPE public.question_type OWNER TO comp_org;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: answer_records; Type: TABLE; Schema: public; Owner: comp_org
--

CREATE TABLE public.answer_records (
    id bigint NOT NULL,
    session_id bigint NOT NULL,
    question_id bigint NOT NULL,
    user_answer jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_correct boolean,
    score numeric(6,2),
    feedback text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.answer_records OWNER TO comp_org;

--
-- Name: answer_records_id_seq; Type: SEQUENCE; Schema: public; Owner: comp_org
--

CREATE SEQUENCE public.answer_records_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.answer_records_id_seq OWNER TO comp_org;

--
-- Name: answer_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: comp_org
--

ALTER SEQUENCE public.answer_records_id_seq OWNED BY public.answer_records.id;


--
-- Name: chapters; Type: TABLE; Schema: public; Owner: comp_org
--

CREATE TABLE public.chapters (
    id smallint NOT NULL,
    title text NOT NULL,
    description text,
    order_index smallint NOT NULL,
    source_file text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.chapters OWNER TO comp_org;

--
-- Name: chapters_id_seq; Type: SEQUENCE; Schema: public; Owner: comp_org
--

CREATE SEQUENCE public.chapters_id_seq
    AS smallint
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.chapters_id_seq OWNER TO comp_org;

--
-- Name: chapters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: comp_org
--

ALTER SEQUENCE public.chapters_id_seq OWNED BY public.chapters.id;


--
-- Name: knowledge_chunks; Type: TABLE; Schema: public; Owner: comp_org
--

CREATE TABLE public.knowledge_chunks (
    id bigint NOT NULL,
    chapter_id smallint NOT NULL,
    chunk_id text NOT NULL,
    title text,
    content text NOT NULL,
    source_file text NOT NULL,
    source_page integer,
    embedding public.vector(1536),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.knowledge_chunks OWNER TO comp_org;

--
-- Name: knowledge_chunks_id_seq; Type: SEQUENCE; Schema: public; Owner: comp_org
--

CREATE SEQUENCE public.knowledge_chunks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.knowledge_chunks_id_seq OWNER TO comp_org;

--
-- Name: knowledge_chunks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: comp_org
--

ALTER SEQUENCE public.knowledge_chunks_id_seq OWNED BY public.knowledge_chunks.id;


--
-- Name: knowledge_points; Type: TABLE; Schema: public; Owner: comp_org
--

CREATE TABLE public.knowledge_points (
    id bigint NOT NULL,
    chapter_id smallint NOT NULL,
    name text NOT NULL,
    summary text,
    difficulty public.question_difficulty DEFAULT 'medium'::public.question_difficulty NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.knowledge_points OWNER TO comp_org;

--
-- Name: knowledge_points_id_seq; Type: SEQUENCE; Schema: public; Owner: comp_org
--

CREATE SEQUENCE public.knowledge_points_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.knowledge_points_id_seq OWNER TO comp_org;

--
-- Name: knowledge_points_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: comp_org
--

ALTER SEQUENCE public.knowledge_points_id_seq OWNED BY public.knowledge_points.id;


--
-- Name: practice_sessions; Type: TABLE; Schema: public; Owner: comp_org
--

CREATE TABLE public.practice_sessions (
    id bigint NOT NULL,
    user_id text,
    mode public.practice_mode NOT NULL,
    chapter_id smallint,
    question_count integer DEFAULT 0 NOT NULL,
    score numeric(6,2),
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    submitted_at timestamp with time zone,
    CONSTRAINT practice_sessions_question_count_check CHECK ((question_count >= 0))
);


ALTER TABLE public.practice_sessions OWNER TO comp_org;

--
-- Name: practice_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: comp_org
--

CREATE SEQUENCE public.practice_sessions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.practice_sessions_id_seq OWNER TO comp_org;

--
-- Name: practice_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: comp_org
--

ALTER SEQUENCE public.practice_sessions_id_seq OWNED BY public.practice_sessions.id;


--
-- Name: question_feedback; Type: TABLE; Schema: public; Owner: comp_org
--

CREATE TABLE public.question_feedback (
    id bigint NOT NULL,
    user_id text NOT NULL,
    question_id bigint NOT NULL,
    is_helpful boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    feedback_type text,
    reason text
);


ALTER TABLE public.question_feedback OWNER TO comp_org;

--
-- Name: question_feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: comp_org
--

CREATE SEQUENCE public.question_feedback_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.question_feedback_id_seq OWNER TO comp_org;

--
-- Name: question_feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: comp_org
--

ALTER SEQUENCE public.question_feedback_id_seq OWNED BY public.question_feedback.id;


--
-- Name: questions; Type: TABLE; Schema: public; Owner: comp_org
--

CREATE TABLE public.questions (
    id bigint NOT NULL,
    chapter_id smallint NOT NULL,
    knowledge_point_id bigint,
    parent_question_id bigint,
    type public.question_type NOT NULL,
    difficulty public.question_difficulty DEFAULT 'medium'::public.question_difficulty NOT NULL,
    stem text NOT NULL,
    options_json jsonb DEFAULT '[]'::jsonb NOT NULL,
    answer_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    rubric_json jsonb DEFAULT '[]'::jsonb NOT NULL,
    explanation text,
    source_context text,
    source_assignment text,
    is_ai_generated boolean DEFAULT false NOT NULL,
    is_reviewed boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    archived boolean DEFAULT false NOT NULL,
    ai_status text,
    quality_score integer DEFAULT 0 NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    helpful_count integer DEFAULT 0 NOT NULL,
    not_helpful_count integer DEFAULT 0 NOT NULL,
    error_count integer DEFAULT 0 NOT NULL,
    flag_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.questions OWNER TO comp_org;

--
-- Name: questions_id_seq; Type: SEQUENCE; Schema: public; Owner: comp_org
--

CREATE SEQUENCE public.questions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.questions_id_seq OWNER TO comp_org;

--
-- Name: questions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: comp_org
--

ALTER SEQUENCE public.questions_id_seq OWNED BY public.questions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: comp_org
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    student_id text NOT NULL,
    password_hash text NOT NULL,
    nickname text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO comp_org;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: comp_org
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO comp_org;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: comp_org
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: wrong_questions; Type: TABLE; Schema: public; Owner: comp_org
--

CREATE TABLE public.wrong_questions (
    id bigint NOT NULL,
    user_id text NOT NULL,
    question_id bigint NOT NULL,
    wrong_count integer DEFAULT 1 NOT NULL,
    last_wrong_at timestamp with time zone DEFAULT now() NOT NULL,
    mastered boolean DEFAULT false NOT NULL,
    CONSTRAINT wrong_questions_wrong_count_check CHECK ((wrong_count > 0))
);


ALTER TABLE public.wrong_questions OWNER TO comp_org;

--
-- Name: wrong_questions_id_seq; Type: SEQUENCE; Schema: public; Owner: comp_org
--

CREATE SEQUENCE public.wrong_questions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wrong_questions_id_seq OWNER TO comp_org;

--
-- Name: wrong_questions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: comp_org
--

ALTER SEQUENCE public.wrong_questions_id_seq OWNED BY public.wrong_questions.id;


--
-- Name: answer_records id; Type: DEFAULT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.answer_records ALTER COLUMN id SET DEFAULT nextval('public.answer_records_id_seq'::regclass);


--
-- Name: chapters id; Type: DEFAULT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.chapters ALTER COLUMN id SET DEFAULT nextval('public.chapters_id_seq'::regclass);


--
-- Name: knowledge_chunks id; Type: DEFAULT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.knowledge_chunks ALTER COLUMN id SET DEFAULT nextval('public.knowledge_chunks_id_seq'::regclass);


--
-- Name: knowledge_points id; Type: DEFAULT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.knowledge_points ALTER COLUMN id SET DEFAULT nextval('public.knowledge_points_id_seq'::regclass);


--
-- Name: practice_sessions id; Type: DEFAULT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.practice_sessions ALTER COLUMN id SET DEFAULT nextval('public.practice_sessions_id_seq'::regclass);


--
-- Name: question_feedback id; Type: DEFAULT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.question_feedback ALTER COLUMN id SET DEFAULT nextval('public.question_feedback_id_seq'::regclass);


--
-- Name: questions id; Type: DEFAULT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.questions ALTER COLUMN id SET DEFAULT nextval('public.questions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: wrong_questions id; Type: DEFAULT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.wrong_questions ALTER COLUMN id SET DEFAULT nextval('public.wrong_questions_id_seq'::regclass);


--
-- Data for Name: answer_records; Type: TABLE DATA; Schema: public; Owner: comp_org
--

COPY public.answer_records (id, session_id, question_id, user_answer, is_correct, score, feedback, created_at) FROM stdin;
1	1	1	"A"	t	1.00	答案正确	2026-06-01 12:21:27.640245+00
2	2	1	"A"	t	1.00	答案正确	2026-06-01 12:23:24.201233+00
3	3	3	["补码"]	t	1.00	填空匹配 1/1	2026-06-01 12:26:44.903108+00
4	4	164	{}	\N	\N	\N	2026-06-01 12:36:40.791009+00
5	4	176	{}	\N	\N	\N	2026-06-01 12:36:40.791009+00
6	4	153	{}	\N	\N	\N	2026-06-01 12:36:40.791009+00
7	4	173	{}	\N	\N	\N	2026-06-01 12:36:40.791009+00
8	4	155	{}	\N	\N	\N	2026-06-01 12:36:40.791009+00
9	5	172	{}	\N	\N	\N	2026-06-01 12:37:28.083395+00
10	6	196	"C"	t	1.00	答案正确	2026-06-01 12:47:35.62+00
11	6	183	"A"	t	1.00	答案正确	2026-06-01 12:47:35.62+00
12	6	199	["1", "2", "3"]	f	0.00	填空匹配 0/3	2026-06-01 12:47:35.62+00
13	6	192	"TRUE"	f	0.00	答案不正确	2026-06-01 12:47:35.62+00
14	6	193	"TRUE"	t	1.00	答案正确	2026-06-01 12:47:35.62+00
433	197	199	{}	\N	\N	\N	2026-06-02 03:02:06.387236+00
17	9	188	{}	\N	\N	\N	2026-06-01 12:59:37.159505+00
18	9	183	{}	\N	\N	\N	2026-06-01 12:59:37.159505+00
19	9	187	{}	\N	\N	\N	2026-06-01 12:59:37.159505+00
20	9	199	{}	\N	\N	\N	2026-06-01 12:59:37.159505+00
21	9	186	{}	\N	\N	\N	2026-06-01 12:59:37.159505+00
189	113	288	["A"]	f	0.00	多选题需要与标准答案完全一致	2026-06-01 14:54:13.218731+00
190	113	8	"A"	f	0.00	答案不正确	2026-06-01 14:54:13.218731+00
29	17	195	{}	\N	\N	\N	2026-06-01 13:19:57.127423+00
30	17	202	{}	\N	\N	\N	2026-06-01 13:19:57.127423+00
31	17	199	{}	\N	\N	\N	2026-06-01 13:19:57.127423+00
32	17	196	{}	\N	\N	\N	2026-06-01 13:19:57.127423+00
33	17	197	{}	\N	\N	\N	2026-06-01 13:19:57.127423+00
174	110	107	{}	\N	\N	\N	2026-06-01 14:52:12.565777+00
175	110	191	{}	\N	\N	\N	2026-06-01 14:52:12.565777+00
176	110	157	{}	\N	\N	\N	2026-06-01 14:52:12.565777+00
177	110	111	{}	\N	\N	\N	2026-06-01 14:52:12.565777+00
178	110	35	{}	\N	\N	\N	2026-06-01 14:52:12.565777+00
40	23	188	{}	\N	\N	\N	2026-06-01 13:28:47.588766+00
179	111	71	{}	\N	\N	\N	2026-06-01 14:53:23.624718+00
180	111	143	{}	\N	\N	\N	2026-06-01 14:53:23.624718+00
80	57	99	{}	\N	\N	\N	2026-06-01 14:02:28.343085+00
81	57	108	{}	\N	\N	\N	2026-06-01 14:02:28.343085+00
82	57	102	{}	\N	\N	\N	2026-06-01 14:02:28.343085+00
83	57	56	{}	\N	\N	\N	2026-06-01 14:02:28.343085+00
84	57	3	{}	\N	\N	\N	2026-06-01 14:02:28.343085+00
85	58	107	{}	\N	\N	\N	2026-06-01 14:02:57.751646+00
86	58	141	{}	\N	\N	\N	2026-06-01 14:02:57.751646+00
87	58	127	{}	\N	\N	\N	2026-06-01 14:02:57.751646+00
88	58	128	{}	\N	\N	\N	2026-06-01 14:02:57.751646+00
89	58	200	{}	\N	\N	\N	2026-06-01 14:02:57.751646+00
90	58	3	{}	\N	\N	\N	2026-06-01 14:02:57.751646+00
91	58	54	{}	\N	\N	\N	2026-06-01 14:02:57.751646+00
92	58	73	{}	\N	\N	\N	2026-06-01 14:02:57.751646+00
93	58	47	{}	\N	\N	\N	2026-06-01 14:02:57.751646+00
94	58	28	{}	\N	\N	\N	2026-06-01 14:02:57.751646+00
95	58	186	{}	\N	\N	\N	2026-06-01 14:02:57.751646+00
96	58	114	{}	\N	\N	\N	2026-06-01 14:02:57.751646+00
97	58	57	{}	\N	\N	\N	2026-06-01 14:02:57.751646+00
98	58	198	{}	\N	\N	\N	2026-06-01 14:02:57.751646+00
99	58	12	{}	\N	\N	\N	2026-06-01 14:02:57.751646+00
181	111	180	{}	\N	\N	\N	2026-06-01 14:53:23.624718+00
182	111	135	{}	\N	\N	\N	2026-06-01 14:53:23.624718+00
183	111	46	{}	\N	\N	\N	2026-06-01 14:53:23.624718+00
128	84	196	{}	\N	\N	\N	2026-06-01 14:34:43.167894+00
184	112	168	{}	\N	\N	\N	2026-06-01 14:53:28.008957+00
185	112	106	{}	\N	\N	\N	2026-06-01 14:53:28.008957+00
186	112	154	{}	\N	\N	\N	2026-06-01 14:53:28.008957+00
187	112	1	{}	\N	\N	\N	2026-06-01 14:53:28.008957+00
188	112	175	{}	\N	\N	\N	2026-06-01 14:53:28.008957+00
191	114	23	{}	\N	\N	\N	2026-06-01 15:20:17.4718+00
192	114	53	{}	\N	\N	\N	2026-06-01 15:20:17.4718+00
129	84	193	{}	\N	\N	\N	2026-06-01 14:34:43.167894+00
193	114	83	{}	\N	\N	\N	2026-06-01 15:20:17.4718+00
130	84	190	{}	\N	\N	\N	2026-06-01 14:34:43.167894+00
194	114	165	{}	\N	\N	\N	2026-06-01 15:20:17.4718+00
195	114	6	{}	\N	\N	\N	2026-06-01 15:20:17.4718+00
196	114	139	{}	\N	\N	\N	2026-06-01 15:20:17.4718+00
197	114	124	{}	\N	\N	\N	2026-06-01 15:20:17.4718+00
131	84	141	{}	\N	\N	\N	2026-06-01 14:34:43.167894+00
198	114	15	{}	\N	\N	\N	2026-06-01 15:20:17.4718+00
132	85	40	{}	\N	\N	\N	2026-06-01 14:35:06.846318+00
199	114	135	{}	\N	\N	\N	2026-06-01 15:20:17.4718+00
200	114	155	{}	\N	\N	\N	2026-06-01 15:20:17.4718+00
201	114	129	{}	\N	\N	\N	2026-06-01 15:20:17.4718+00
202	114	99	{}	\N	\N	\N	2026-06-01 15:20:17.4718+00
203	114	327	{}	\N	\N	\N	2026-06-01 15:20:17.4718+00
204	114	512	{}	\N	\N	\N	2026-06-01 15:20:17.4718+00
205	114	378	{}	\N	\N	\N	2026-06-01 15:20:17.4718+00
133	85	7	{}	\N	\N	\N	2026-06-01 14:35:06.846318+00
134	85	129	{}	\N	\N	\N	2026-06-01 14:35:06.846318+00
135	85	19	{}	\N	\N	\N	2026-06-01 14:35:06.846318+00
136	86	161	{}	\N	\N	\N	2026-06-01 14:35:14.499232+00
137	86	143	{}	\N	\N	\N	2026-06-01 14:35:14.499232+00
138	86	151	{}	\N	\N	\N	2026-06-01 14:35:14.499232+00
139	86	125	{}	\N	\N	\N	2026-06-01 14:35:14.499232+00
140	86	118	{}	\N	\N	\N	2026-06-01 14:35:14.499232+00
141	87	147	{}	\N	\N	\N	2026-06-01 14:35:20.855531+00
142	87	169	{}	\N	\N	\N	2026-06-01 14:35:20.855531+00
143	87	25	{}	\N	\N	\N	2026-06-01 14:35:20.855531+00
144	87	189	{}	\N	\N	\N	2026-06-01 14:35:20.855531+00
145	87	198	{}	\N	\N	\N	2026-06-01 14:35:20.855531+00
146	88	149	{}	\N	\N	\N	2026-06-01 14:36:54.960076+00
147	88	141	{}	\N	\N	\N	2026-06-01 14:36:54.960076+00
148	88	92	{}	\N	\N	\N	2026-06-01 14:36:54.960076+00
149	88	96	{}	\N	\N	\N	2026-06-01 14:36:54.960076+00
214	122	310	{}	\N	\N	\N	2026-06-01 15:21:52.677911+00
215	122	61	{}	\N	\N	\N	2026-06-01 15:21:52.677911+00
216	122	81	{}	\N	\N	\N	2026-06-01 15:21:52.677911+00
217	122	380	{}	\N	\N	\N	2026-06-01 15:21:52.677911+00
218	122	2	{}	\N	\N	\N	2026-06-01 15:21:52.677911+00
219	122	427	{}	\N	\N	\N	2026-06-01 15:21:52.677911+00
220	122	78	{}	\N	\N	\N	2026-06-01 15:21:52.677911+00
221	122	109	{}	\N	\N	\N	2026-06-01 15:21:52.677911+00
222	122	489	{}	\N	\N	\N	2026-06-01 15:21:52.677911+00
223	122	457	{}	\N	\N	\N	2026-06-01 15:21:52.677911+00
224	122	386	{}	\N	\N	\N	2026-06-01 15:21:52.677911+00
225	122	295	{}	\N	\N	\N	2026-06-01 15:21:52.677911+00
226	122	155	{}	\N	\N	\N	2026-06-01 15:21:52.677911+00
227	122	158	{}	\N	\N	\N	2026-06-01 15:21:52.677911+00
228	122	332	{}	\N	\N	\N	2026-06-01 15:21:52.677911+00
229	123	186	{}	\N	\N	\N	2026-06-02 02:03:44.67837+00
230	123	183	{}	\N	\N	\N	2026-06-02 02:03:44.67837+00
231	123	188	{}	\N	\N	\N	2026-06-02 02:03:44.67837+00
232	123	179	{}	\N	\N	\N	2026-06-02 02:03:44.67837+00
233	123	182	{}	\N	\N	\N	2026-06-02 02:03:44.67837+00
234	123	185	{}	\N	\N	\N	2026-06-02 02:03:44.67837+00
235	123	184	{}	\N	\N	\N	2026-06-02 02:03:44.67837+00
236	123	197	{}	\N	\N	\N	2026-06-02 02:03:44.67837+00
237	123	195	{}	\N	\N	\N	2026-06-02 02:03:44.67837+00
238	123	192	{}	\N	\N	\N	2026-06-02 02:03:44.67837+00
239	123	191	{}	\N	\N	\N	2026-06-02 02:03:44.67837+00
240	123	189	{}	\N	\N	\N	2026-06-02 02:03:44.67837+00
241	123	312	{}	\N	\N	\N	2026-06-02 02:03:44.67837+00
242	123	297	{}	\N	\N	\N	2026-06-02 02:03:44.67837+00
243	123	306	{}	\N	\N	\N	2026-06-02 02:03:44.67837+00
244	124	194	{}	\N	\N	\N	2026-06-02 02:04:44.040029+00
245	124	184	{}	\N	\N	\N	2026-06-02 02:04:44.040029+00
246	124	182	{}	\N	\N	\N	2026-06-02 02:04:44.040029+00
247	124	185	{}	\N	\N	\N	2026-06-02 02:04:44.040029+00
248	124	303	{}	\N	\N	\N	2026-06-02 02:04:44.040029+00
249	124	179	{}	\N	\N	\N	2026-06-02 02:04:44.040029+00
250	124	183	{}	\N	\N	\N	2026-06-02 02:04:44.040029+00
251	124	195	{}	\N	\N	\N	2026-06-02 02:04:44.040029+00
252	124	190	{}	\N	\N	\N	2026-06-02 02:04:44.040029+00
253	124	193	{}	\N	\N	\N	2026-06-02 02:04:44.040029+00
254	124	189	{}	\N	\N	\N	2026-06-02 02:04:44.040029+00
255	124	202	{}	\N	\N	\N	2026-06-02 02:04:44.040029+00
256	124	309	{}	\N	\N	\N	2026-06-02 02:04:44.040029+00
257	124	296	{}	\N	\N	\N	2026-06-02 02:04:44.040029+00
258	124	307	{}	\N	\N	\N	2026-06-02 02:04:44.040029+00
259	125	8	{}	\N	\N	\N	2026-06-02 02:05:00.676141+00
260	126	440	{}	\N	\N	\N	2026-06-02 02:05:39.08115+00
261	126	471	{}	\N	\N	\N	2026-06-02 02:05:39.08115+00
262	126	480	{}	\N	\N	\N	2026-06-02 02:05:39.08115+00
263	126	443	{}	\N	\N	\N	2026-06-02 02:05:39.08115+00
264	126	454	{}	\N	\N	\N	2026-06-02 02:05:39.08115+00
265	126	450	{}	\N	\N	\N	2026-06-02 02:05:39.08115+00
266	126	289	{}	\N	\N	\N	2026-06-02 02:05:39.08115+00
267	126	442	{}	\N	\N	\N	2026-06-02 02:05:39.08115+00
268	126	481	{}	\N	\N	\N	2026-06-02 02:05:39.08115+00
269	126	545	{}	\N	\N	\N	2026-06-02 02:05:39.08115+00
270	126	460	{}	\N	\N	\N	2026-06-02 02:05:39.08115+00
271	126	464	{}	\N	\N	\N	2026-06-02 02:05:39.08115+00
272	126	477	{}	\N	\N	\N	2026-06-02 02:05:39.08115+00
273	126	446	{}	\N	\N	\N	2026-06-02 02:05:39.08115+00
274	126	476	{}	\N	\N	\N	2026-06-02 02:05:39.08115+00
275	127	196	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
276	127	183	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
277	127	184	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
278	127	181	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
279	127	188	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
280	127	180	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
281	127	179	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
282	127	182	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
283	127	1	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
284	127	187	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
285	127	185	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
286	127	186	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
287	127	194	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
288	127	310	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
289	127	293	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
290	127	195	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
291	127	198	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
292	127	292	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
293	127	192	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
294	127	190	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
295	127	193	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
296	127	189	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
297	127	191	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
298	127	302	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
299	127	200	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
300	127	201	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
301	127	199	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
302	127	202	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
303	127	305	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
304	127	296	{}	\N	\N	\N	2026-06-02 02:11:09.161717+00
434	197	200	{}	\N	\N	\N	2026-06-02 03:02:06.387236+00
435	197	201	{}	\N	\N	\N	2026-06-02 03:02:06.387236+00
436	197	194	{}	\N	\N	\N	2026-06-02 03:02:06.387236+00
571	247	146	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
572	247	148	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
573	247	145	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
574	247	147	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
575	247	152	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
576	247	177	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
577	247	155	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
578	247	154	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
579	247	176	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
580	247	169	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
581	247	170	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
582	247	171	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
583	247	172	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
584	247	173	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
585	247	174	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
586	247	175	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
587	247	156	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
588	247	158	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
589	247	159	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
590	247	160	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
591	247	161	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
592	247	162	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
593	247	163	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
594	247	157	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
595	247	164	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
596	247	165	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
597	247	166	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
598	247	167	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
352	167	184	{}	\N	\N	\N	2026-06-02 02:46:41.225327+00
353	167	190	{}	\N	\N	\N	2026-06-02 02:46:41.225327+00
354	167	191	{}	\N	\N	\N	2026-06-02 02:46:41.225327+00
355	167	200	{}	\N	\N	\N	2026-06-02 02:46:41.225327+00
356	167	297	{}	\N	\N	\N	2026-06-02 02:46:41.225327+00
357	168	181	{}	\N	\N	\N	2026-06-02 02:46:58.057294+00
358	168	188	{}	\N	\N	\N	2026-06-02 02:46:58.057294+00
359	168	186	{}	\N	\N	\N	2026-06-02 02:46:58.057294+00
360	168	313	{}	\N	\N	\N	2026-06-02 02:46:58.057294+00
361	168	199	{}	\N	\N	\N	2026-06-02 02:46:58.057294+00
599	247	168	{}	\N	\N	\N	2026-06-02 06:27:29.027426+00
437	197	195	{}	\N	\N	\N	2026-06-02 03:02:06.387236+00
438	197	196	{}	\N	\N	\N	2026-06-02 03:02:06.387236+00
439	197	197	{}	\N	\N	\N	2026-06-02 03:02:06.387236+00
440	197	198	{}	\N	\N	\N	2026-06-02 03:02:06.387236+00
441	198	194	{}	\N	\N	\N	2026-06-02 03:02:29.360153+00
442	198	195	{}	\N	\N	\N	2026-06-02 03:02:29.360153+00
443	198	196	{}	\N	\N	\N	2026-06-02 03:02:29.360153+00
444	198	197	{}	\N	\N	\N	2026-06-02 03:02:29.360153+00
445	198	198	{}	\N	\N	\N	2026-06-02 03:02:29.360153+00
446	198	199	{}	\N	\N	\N	2026-06-02 03:02:29.360153+00
447	198	200	{}	\N	\N	\N	2026-06-02 03:02:29.360153+00
448	198	201	{}	\N	\N	\N	2026-06-02 03:02:29.360153+00
411	183	194	{}	\N	\N	\N	2026-06-02 03:00:30.945306+00
412	183	195	{}	\N	\N	\N	2026-06-02 03:00:30.945306+00
413	183	196	{}	\N	\N	\N	2026-06-02 03:00:30.945306+00
414	183	197	{}	\N	\N	\N	2026-06-02 03:00:30.945306+00
415	183	198	{}	\N	\N	\N	2026-06-02 03:00:30.945306+00
416	184	199	{}	\N	\N	\N	2026-06-02 03:00:41.269743+00
417	184	200	{}	\N	\N	\N	2026-06-02 03:00:41.269743+00
418	184	201	{}	\N	\N	\N	2026-06-02 03:00:41.269743+00
498	215	2	"TRUE"	t	1.00	答案正确	2026-06-02 05:50:45.607715+00
499	215	340	["数据"]	f	0.00	填空匹配 0/1	2026-06-02 05:50:45.607715+00
500	215	323	["电气", "机械", "功能", "时间"]	t	1.00	填空匹配 4/4	2026-06-02 05:50:45.607715+00
501	215	360	["时间"]	t	1.00	填空匹配 1/1	2026-06-02 05:50:45.607715+00
502	215	363	["计数器"]	t	1.00	填空匹配 1/1	2026-06-02 05:50:45.607715+00
478	214	1	{}	\N	\N	\N	2026-06-02 03:12:02.649233+00
479	214	191	{}	\N	\N	\N	2026-06-02 03:12:02.649233+00
480	214	312	{}	\N	\N	\N	2026-06-02 03:12:02.649233+00
481	214	194	{}	\N	\N	\N	2026-06-02 03:12:02.649233+00
482	214	195	{}	\N	\N	\N	2026-06-02 03:12:02.649233+00
483	214	196	{}	\N	\N	\N	2026-06-02 03:12:02.649233+00
484	214	197	{}	\N	\N	\N	2026-06-02 03:12:02.649233+00
485	214	198	{}	\N	\N	\N	2026-06-02 03:12:02.649233+00
486	214	199	{}	\N	\N	\N	2026-06-02 03:12:02.649233+00
487	214	200	{}	\N	\N	\N	2026-06-02 03:12:02.649233+00
488	214	201	{}	\N	\N	\N	2026-06-02 03:12:02.649233+00
489	215	335	"C"	t	1.00	答案正确	2026-06-02 05:50:45.607715+00
490	215	338	"B"	t	1.00	答案正确	2026-06-02 05:50:45.607715+00
491	215	326	"A"	t	1.00	答案正确	2026-06-02 05:50:45.607715+00
492	215	318	"B"	t	1.00	答案正确	2026-06-02 05:50:45.607715+00
493	215	359	"B"	t	1.00	答案正确	2026-06-02 05:50:45.607715+00
494	215	349	"B"	t	1.00	答案正确	2026-06-02 05:50:45.607715+00
495	215	355	"B"	t	1.00	答案正确	2026-06-02 05:50:45.607715+00
496	215	356	["A", "B", "C", "D"]	t	1.00	答案完全正确	2026-06-02 05:50:45.607715+00
497	215	316	["A", "B", "C", "D"]	t	1.00	答案完全正确	2026-06-02 05:50:45.607715+00
503	215	320	["5.96"]	f	0.00	填空匹配 0/1	2026-06-02 05:50:45.607715+00
780	269	1	"B"	f	0.00	答案不正确	2026-06-02 12:46:36.895775+00
781	269	183	"C"	f	0.00	答案不正确	2026-06-02 12:46:36.895775+00
782	269	179	"C"	t	1.00	答案正确	2026-06-02 12:46:36.895775+00
783	269	312	"TRUE"	t	1.00	答案正确	2026-06-02 12:46:36.895775+00
784	269	202	["2", "3"]	f	0.00	填空匹配 0/2	2026-06-02 12:46:36.895775+00
785	270	301	[]	f	0.00	多选题需要与标准答案完全一致	2026-06-02 12:51:56.164277+00
701	262	691	"A"	f	0.00	答案不正确	2026-06-02 10:14:18.039435+00
702	262	693	"A"	f	0.00	答案不正确	2026-06-02 10:14:18.039435+00
703	262	694	"B"	f	0.00	答案不正确	2026-06-02 10:14:18.039435+00
704	262	692	["B"]	f	0.00	多选题需要与标准答案完全一致	2026-06-02 10:14:18.039435+00
705	262	695	["B"]	f	0.00	多选题需要与标准答案完全一致	2026-06-02 10:14:18.039435+00
706	263	696	"D"	f	0.00	答案不正确	2026-06-02 10:20:44.24814+00
707	263	697	"TRUE"	t	1.00	答案正确	2026-06-02 10:20:44.24814+00
708	263	698	"lll"	f	0.00	请对照解析复盘	2026-06-02 10:20:44.24814+00
\.


--
-- Data for Name: chapters; Type: TABLE DATA; Schema: public; Owner: comp_org
--

COPY public.chapters (id, title, description, order_index, source_file, created_at, updated_at) FROM stdin;
1	概论	计算机系统概论与基础概念	1	materials/review-notes/chapter-01-overview-summary.docx	2026-06-01 12:03:19.485313+00	2026-06-01 12:03:19.485313+00
2	总线	总线结构、通信与控制	2	materials/review-notes/chapter-02-bus-summary.docx	2026-06-01 12:03:19.485313+00	2026-06-01 12:03:19.485313+00
3	信息编码与数据表示	数据表示、编码与数制转换	3	materials/review-notes/chapter-03-data-representation-summary.docx	2026-06-01 12:03:19.485313+00	2026-06-01 12:03:19.485313+00
4	运算方法与运算器	算术逻辑运算、补码与运算器	4	materials/review-notes/chapter-04-arithmetic-alu-summary.docx	2026-06-01 12:03:19.485313+00	2026-06-01 12:03:19.485313+00
5	存储体系	主存、Cache、虚拟存储与层次结构	5	materials/review-notes/chapter-05-memory-hierarchy-summary.docx	2026-06-01 12:03:19.485313+00	2026-06-01 12:03:19.485313+00
6	指令系统	指令格式、寻址方式与指令类型	6	materials/review-notes/chapter-06-instruction-system-summary.docx	2026-06-01 12:03:19.485313+00	2026-06-01 12:03:19.485313+00
7	控制器	控制单元、微程序与流水线基础	7	materials/review-notes/chapter-07-control-unit-summary.docx	2026-06-01 12:03:19.485313+00	2026-06-01 12:03:19.485313+00
8	RISC-V 与 ARM 模型机设计实例	RISC-V、ARM 与模型机设计	8	materials/review-notes/chapter-08-riscv-arm-model-machine-summary.docx	2026-06-01 12:03:19.485313+00	2026-06-01 12:03:19.485313+00
9	输入输出系统	I/O 接口、中断、DMA 与外设管理	9	materials/review-notes/chapter-09-io-system-summary.docx	2026-06-01 12:03:19.485313+00	2026-06-01 12:03:19.485313+00
\.


--
-- Data for Name: knowledge_chunks; Type: TABLE DATA; Schema: public; Owner: comp_org
--

COPY public.knowledge_chunks (id, chapter_id, chunk_id, title, content, source_file, source_page, embedding, created_at) FROM stdin;
286	1	ch01-s001-01	一、本章主线	这一章的作用不是让你背计算机历史，而是建立整门“计算机组成原理与系统结构”的总地图：计算机如何从物理硬件出发，经过指令、程序、操作系统和应用软件，最终完成用户任务。\n用户任务\n→ 高级语言程序\n→ 编译 / 汇编 / 链接\n→ 机器语言指令\n→ 控制器取指、译码、发控制信号\n→ 运算器、存储器、输入输出设备协同工作\n→ 程序完成\n→ 用 CPI、主频、MIPS、FLOPS、存储容量等指标评价性能\n计算机的发展与分类：了解计算机从电子数字计算机到微处理器的发展。\n冯·诺依曼体系结构：本章最核心的结构模型。\n计算机硬件系统五大部件：存储器、运算器、控制器、输入设备、输出设备。\n软件、语言与程序运行过程：高级语言如何变成机器可执行程序。\n计算机系统层次结构：从物理电路到应用软件的抽象层。\n计算机性能指标：机器字长、存储容量、CPI、MIPS、FLOPS 等。	materials/review-notes/chapter-01-overview-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
287	1	ch01-s002-01	二、计算机的发展：重点抓住“二进制 + 存储程序”	电子数字计算机的主要特点是高速、高精度，并以二进制方式表示和处理信息。第一台电子数字计算机 ENIAC 于 1946 年诞生，早期采用十进制操作，并通过布线和拨动开关控制运算。\n真正需要记住的不是年份细节，而是它引出了现代计算机的两个关键思想：\n1. 二进制：数据和指令都可以用 0/1 表示，便于电子线路实现。\n2. 存储程序：程序和数据一起放入存储器，CPU 按照指令序列自动执行。	materials/review-notes/chapter-01-overview-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
288	1	ch01-s003-01	三、计算机分类：重点是 Flynn 分类法	Flynn 分类法根据计算机运行时的两类信息流进行划分：指令流和数据流。指令流表示“执行什么操作”，数据流表示“被处理的数据”。\n本课程主要讨论对象：电子数字计算机、SISD 计算机、冯·诺依曼体系结构计算机。	materials/review-notes/chapter-01-overview-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
289	1	ch01-s004-01	4.1 硬件系统	硬件系统是计算机系统的物质基础，主要由主机和外围设备组成。\n硬件系统\n├── 主机\n│ ├── CPU = 运算器 + 控制器\n│ └── 内存储器：RAM、ROM\n└── 外围设备\n ├── 外存储器：磁盘、磁带、光盘等\n ├── 输入设备：键盘、鼠标、扫描仪等\n └── 输出设备：显示器、打印机、绘图仪等	materials/review-notes/chapter-01-overview-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
290	1	ch01-s005-01	4.2 软件系统	软件系统是硬件功能的扩充和完善，它负责管理硬件资源、组织程序运行并服务用户任务。\n软件系统\n├── 系统软件\n│ ├── 操作系统\n│ ├── 语言处理程序\n│ ├── 数据库管理系统\n│ ├── 网络管理软件\n│ └── 服务性程序\n└── 应用软件\n ├── 工程设计程序\n ├── 数据处理程序\n ├── 自动控制程序\n ├── 企业管理程序\n └── 科学计算程序\n操作系统是直接运行在裸机上的最基本系统软件，是系统软件的核心。它管理计算机软硬件资源，提高资源利用率，并为用户和计算机之间提供接口。	materials/review-notes/chapter-01-overview-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
291	1	ch01-s006-01	五、冯·诺依曼体系结构：本章核心	冯·诺依曼体系结构的核心不是某个具体机器，而是一套现代通用计算机的基本组织原则。\n1. 采用二进制表示数据和指令。计算机内部所有信息最终都以 0/1 表示。\n2. 采用存储程序思想。程序和数据预先存入主存，计算机工作时自动从存储器取指令并执行。\n3. 指令一般按顺序执行。遇到分支、跳转、循环等指令时，执行顺序会被改变。\n4. 硬件由五大部件组成：运算器、存储器、控制器、输入设备、输出设备。\n5. 现代计算机更强调以存储器为中心。程序和数据都在存储器中，CPU 与 I/O 设备围绕存储器进行信息交换。\n程序和数据放入存储器\n→ CPU 取指令\n→ 控制器分析指令\n→ 控制器发出控制信号\n→ 运算器、存储器、I/O 设备执行相应操作\n→ 继续取下一条指令	materials/review-notes/chapter-01-overview-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
292	1	ch01-s007-01	7.2 编译、汇编、链接、解释	以 C 程序为例，典型编译型语言的运行过程如下：\n高级语言源程序\n→ 预处理\n→ 编译\n→ 汇编\n→ 链接\n→ 可执行机器语言程序\n→ CPU 执行\nGCC 的典型翻译过程可以写成：\nhello.c → hello.i → hello.s → hello.o → 可执行文件\n预处理：处理 include、宏定义等。\n编译：把高级语言翻译成汇编语言。\n汇编：把汇编语言翻译成机器语言目标文件。\n链接：把目标文件和库函数组合成可执行程序。\n解释：不是一次性全部翻译，而是一边翻译一边执行。	materials/review-notes/chapter-01-overview-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
293	1	ch01-s008-01	八、计算机系统层次结构：理解“抽象层”	计算机系统是分层结构。越往下越接近硬件，越往上越接近用户任务。分层的作用是隐藏底层复杂细节，让上层只面对更简单的模型。\n应用软件层\n语言处理程序及其他系统软件层\n操作系统层\n机器语言层\n微体系结构层\n逻辑实现层\n物理电路层\n这里最重要的两个关键词是“抽象”和“界面”。抽象负责隐藏复杂细节，界面负责连接不同层次，例如软件和硬件之间的界面、使用者和设计者之间的界面、各层计算机语言之间的界面。	materials/review-notes/chapter-01-overview-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
294	1	ch01-s009-01	9.1 机器字长	机器字长是 CPU 一次能处理的数据位数，常见有 8 位、16 位、32 位、64 位。它会影响寄存器位数、运算部件位数、数据总线位数、运算能力和可寻址空间。	materials/review-notes/chapter-01-overview-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
295	1	ch01-s010-01	9.2 存储容量	存储容量表示能存放的二进制信息量大小。\n存储容量 = 存储单元个数 × 存储字长\n1K = 2^10，1M = 2^20，1G = 2^30，1T = 2^40\n例：主存地址线 30 根，存储字长 32 位，则存储单元个数为 2^30，每个单元 32 bit = 4 Byte，所以容量为 2^30 × 4 Byte = 4GB。	materials/review-notes/chapter-01-overview-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
296	1	ch01-s011-01	9.3 运算速度指标	性能判断的关键陷阱：不能只看主频、CPI 或 MIPS 中的某一个指标。真正比较程序快慢，应以 CPU 执行时间为核心，并结合指令条数、CPI、主频、Cache 命中率、I/O 等因素综合判断。	materials/review-notes/chapter-01-overview-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
297	1	ch01-s012-01	10.1 概念题高频点	冯·诺依曼结构是什么？\n什么是存储程序思想？\nCPU 由哪两部分组成？\n操作系统的作用是什么？\n机器语言、汇编语言、高级语言有什么区别？\n编译器、汇编器、解释器分别干什么？	materials/review-notes/chapter-01-overview-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
298	1	ch01-s013-01	10.2 分类题高频点	Flynn 分类法：SISD、SIMD、MISD、MIMD。\n通用计算机和专用计算机的区别。\n桌面型、服务器型、嵌入式计算机的区别。	materials/review-notes/chapter-01-overview-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
299	1	ch01-s014-01	10.3 计算题高频点	平均 CPI：按不同指令比例加权平均。\n时钟周期：由主频取倒数得到。\nCPU 执行时间：指令条数 × CPI × 时钟周期。\nMIPS：每秒百万条指令数。\n存储容量：存储单元个数 × 存储字长。\n计算题通用步骤：先算平均 CPI，再由主频求时钟周期，接着代入 CPU 时间公式，最后根据题目需要计算 MIPS 或进行性能比较。	materials/review-notes/chapter-01-overview-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
316	3	ch03-s006-01	3.6 浮点数表示	浮点数一般写成：数值 = 尾数 × 基数^阶码。\n规格化的目的：使表示唯一，提高尾数有效位利用率。\nIEEE 754单精度通常由1位符号位、8位阶码、23位尾数组成；双精度由1位符号位、11位阶码、52位尾数组成。\n浮点数要关注特殊值：0、非规格化数、无穷大、NaN。	materials/review-notes/chapter-03-data-representation-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
300	1	ch01-s015-01	十一、本章必须背下来的压缩版	五大部件：运算器、控制器、存储器、输入设备、输出设备\nCPU = 运算器 + 控制器\n冯·诺依曼核心：二进制、存储程序、程序控制、五大部件、顺序执行\nFlynn 分类：SISD、SIMD、MISD、MIMD\n程序翻译：高级语言 → 编译 → 汇编 → 链接 → 机器语言 → CPU 执行\n性能公式：\n 时钟周期 = 1 / 主频\n 平均 CPI = Σ 指令比例 × 指令 CPI\n CPU 执行时间 = 指令条数 × CPI × 时钟周期\n MIPS = 主频 / CPI / 10^6	materials/review-notes/chapter-01-overview-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
301	2	ch02-s001-01	一、本章主线	本章围绕“计算机各部件怎样连接并交换信息”展开。总线不是简单的几根线，而是一组带有电气、机械、功能和时序约定的公共通信通道。后面学习CPU、存储器和I/O时，所有数据传送都要落回总线结构、总线控制和总线时序。\n主线可压缩为：总线特性 -> 总线分类 -> 总线结构 -> 总线标准 -> 总线控制，其中总线控制又重点落在总线判优和通信定时。	materials/review-notes/chapter-02-bus-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
302	2	ch02-s002-01	2.1 总线的基本概念	物理角度：总线是一组实现互连和通信的导线。\n系统角度：总线是连接CPU、存储器、I/O设备等模块的公共信息通路。\n总线特性包括电气特性、机械特性、功能特性和时间特性。	materials/review-notes/chapter-02-bus-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
303	2	ch02-s003-01	2.3 总线分类	按功能可分为地址总线AB、数据总线DB、控制总线CB。\n地址总线通常从CPU发出，决定寻址范围；数据总线常为双向，传送数据；控制总线传送读写、中断、总线请求/响应等控制信号。\n按位置和层次可分为片内总线、系统总线、通信总线等。\n按传送方式可分为并行总线与串行总线；并行适合短距离高速，串行适合远距离和高速差分传输。	materials/review-notes/chapter-02-bus-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
304	2	ch02-s004-01	2.4 总线系统结构	单总线结构简单、成本低，但所有部件共享一条通路，容易形成瓶颈。\n多总线结构把CPU-存储器高速通路和I/O通路分开，可以提高并发性和扩展性。\n现代系统常通过桥接器/控制器连接不同层次总线，例如CPU-内存总线、I/O总线、外设总线。	materials/review-notes/chapter-02-bus-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
305	2	ch02-s005-01	2.5 总线性能指标	总线宽度：一次并行传送的二进制位数，常见为8/16/32/64位。\n总线频率：总线时钟频率，影响单位时间传送次数。\n总线带宽：单位时间传送的数据量，常用B/s、MB/s、GB/s表示。\n典型估算：总线带宽 = 总线宽度(bit) / 8 × 总线频率 × 每周期传送次数。	materials/review-notes/chapter-02-bus-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
306	2	ch02-s006-01	2.6 总线控制	总线判优解决“多个主设备同时申请总线时谁先使用”的问题。\n集中式判优常见有链式查询、计数器定时查询、独立请求方式。\n分布式判优把判优逻辑分散到各模块，可靠性和扩展性更好，但控制复杂。\n通信定时包括同步通信、异步通信和半同步通信。同步通信靠统一时钟，异步通信靠请求/应答握手。	materials/review-notes/chapter-02-bus-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
307	2	ch02-s007-01	2.7 总线标准	总线标准规定信号、电气、机械、协议和时序，使不同厂商设备可以互联。\n常见标准可按历史和用途理解：片内/板级总线、系统扩展总线、外设接口总线、串行高速总线。\n复习时不必死记所有历史细节，关键是理解“标准 = 互联接口规范”。	materials/review-notes/chapter-02-bus-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
308	2	ch02-s008-01	三、必须背下来的结构与公式	总线三类信号：地址总线AB、数据总线DB、控制总线CB。\n总线四类特性：电气、机械、功能、时间。\n总线带宽 = 总线宽度(bit)/8 × 总线频率 × 每周期传送次数。\n集中式判优：链式查询、计数器定时查询、独立请求。\n通信定时：同步、异步、半同步。	materials/review-notes/chapter-02-bus-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
309	2	ch02-s009-01	四、考试/笔试高频点	概念辨析：地址总线、数据总线、控制总线各自传什么。\n计算题：根据总线宽度、频率、传送次数求带宽。\n结构题：单总线与多总线的优缺点。\n简答题：为什么需要总线判优，常见判优方式有什么区别。\n简答题：同步通信和异步通信的区别。	materials/review-notes/chapter-02-bus-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
310	2	ch02-s010-01	五、一句话收束	第2章的本质是把“计算机部件如何互连”讲清楚：地址线决定访问谁，数据线传送内容，控制线决定何时、怎样传；判优解决谁用总线，时序解决何时有效。	materials/review-notes/chapter-02-bus-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
311	3	ch03-s001-01	一、本章主线	本章回答“现实世界的信息怎样变成计算机内部的0和1”。数值信息要经过进位制、符号位、定点/浮点格式表示；非数值信息要经过字符编码、汉字编码等方式表示；为了发现或纠正传输与存储错误，还要引入校验码。\n主线可压缩为：进位计数制 -> 数制转换 -> 有符号数编码 -> 定点数/浮点数 -> 非数值编码 -> 校验码 -> 现代数据类型。	materials/review-notes/chapter-03-data-representation-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
312	3	ch03-s002-01	3.1 进位计数制与数制转换	任意R进制数由基数R、权值R^i和数码D_i组成，其实际值是各位数码乘权后求和。\n常见进制：十进制、二进制、八进制、十六进制。\n计算机采用二进制的原因：物理实现简单、抗干扰强、运算规则简单、逻辑表达自然。\n二进制与八进制/十六进制转换最方便：3位二进制对应1位八进制，4位二进制对应1位十六进制。	materials/review-notes/chapter-03-data-representation-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
313	3	ch03-s003-01	3.2 数值数据格式	数值数据首先分为整数和实数；整数常用定点表示，实数常用浮点表示。\n定点数的小数点位置固定，硬件简单、速度快，但表示范围受限。\n浮点数用阶码和尾数共同表示，能扩大数值范围，但运算规则更复杂。	materials/review-notes/chapter-03-data-representation-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
314	3	ch03-s004-01	3.4 补码与溢出	n位补码整数的表示范围通常为 -2^(n-1) 到 2^(n-1)-1。\n补码的优势是加法和减法可以统一为加法，硬件实现简单。\n溢出不是进位本身，而是运算结果超出可表示范围。\n同号相加结果变异号通常表示溢出；异号相加一般不会溢出。	materials/review-notes/chapter-03-data-representation-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
315	3	ch03-s005-01	3.5 定点数表示	定点小数把小数点固定在符号位之后，适合表示绝对值小于1的数。\n定点整数把小数点固定在最低位之后，适合普通整数运算。\n定点表示要区分机器数与真值：机器数是编码形式，真值是数学含义。	materials/review-notes/chapter-03-data-representation-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
317	3	ch03-s007-01	3.7 非数值数据编码	字符编码用于表示英文、数字、标点等，常见有ASCII。\n汉字编码涉及输入码、内码、字形码等层次。\nBCD码用二进制编码十进制数字，适合金融等需要十进制精确表示的场景。	materials/review-notes/chapter-03-data-representation-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
318	3	ch03-s008-01	3.8 校验码	奇偶校验能发现奇数位错误，但不能定位和纠正错误。\n海明码通过多个校验位实现一位错定位和纠正。\nCRC循环冗余校验适合数据块传输，检错能力强，常用于通信和存储。	materials/review-notes/chapter-03-data-representation-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
319	3	ch03-s009-01	三、必须背下来的结构与公式	R进制数值 = Σ D_i × R^i。\nn位补码范围：-2^(n-1) 到 2^(n-1)-1。\n补码减法：A - B = A + (-B)补。\nIEEE 754浮点数：符号位 + 阶码 + 尾数。\n奇偶校验、海明码、CRC的功能差别。	materials/review-notes/chapter-03-data-representation-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
320	3	ch03-s010-01	四、考试/笔试高频点	数制转换题：二/八/十/十六进制互转。\n编码题：原码、反码、补码、移码求值。\n判断题：补码溢出条件。\n浮点题：根据符号、阶码、尾数还原真值。\n校验题：奇偶校验、海明码、CRC的用途辨析。	materials/review-notes/chapter-03-data-representation-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
321	3	ch03-s011-01	五、一句话收束	第3章的本质是“信息到0/1的翻译规则”：整数看补码，实数看浮点，字符看编码，可靠性看校验码。	materials/review-notes/chapter-03-data-representation-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
322	4	ch04-s001-01	一、本章主线	本章回答“计算机如何在硬件中完成加、减、乘、除和浮点运算”。高级语言中的+、-、*、/最终要变成机器指令，再由ALU、移位器、寄存器和控制逻辑完成。重点是定点补码运算、溢出判断、乘除法移位加减思想、浮点运算流程和运算器结构。\n主线可压缩为：运算类型 -> 移位运算 -> 定点加减 -> 定点乘法 -> 定点除法 -> 浮点运算 -> 运算器组成。	materials/review-notes/chapter-04-arithmetic-alu-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
323	4	ch04-s002-01	4.1 计算机中的运算操作	算术运算包括加、减、乘、除。\n逻辑/位运算包括与、或、非、异或、取反等。\n移位运算包括逻辑移位、算术移位、循环移位。\n高级语言运算需要被编译为机器指令，最后由硬件电路执行。	materials/review-notes/chapter-04-arithmetic-alu-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
324	4	ch04-s003-01	4.3 定点加减运算	补码加法是硬件整数运算的核心：符号位也参与运算，丢弃最高进位。\n减法可以转化为加法：X - Y = X + (-Y)。\n溢出判断重点：两个同号数相加，结果符号与加数符号不同，则溢出。\n也可用符号位进位与最高数值位进位异或判断溢出。	materials/review-notes/chapter-04-arithmetic-alu-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
325	4	ch04-s004-01	4.4 定点乘法运算	乘法本质是“部分积累加 + 移位”。\n原码乘法比较直观，先处理符号，再对数值位做移位加法。\n补码乘法常见思想是Booth算法，根据相邻位变化决定加、减或只移位。\n乘法器性能主要取决于部分积生成、压缩和最终加法速度。	materials/review-notes/chapter-04-arithmetic-alu-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
326	4	ch04-s005-01	4.5 定点除法运算	除法本质是“试商 + 减法/恢复 + 移位”。\n恢复余数法：试减后如果余数为负，要恢复再继续。\n不恢复余数法：用后续加减规则避免每次恢复，提高效率。\n除法比加法和乘法更复杂，硬件实现代价更高。	materials/review-notes/chapter-04-arithmetic-alu-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
327	4	ch04-s006-01	4.6 浮点运算	浮点加减流程：对阶 -> 尾数加减 -> 规格化 -> 舍入 -> 溢出判断。\n对阶通常把小阶向大阶对齐，小阶尾数右移。\n浮点乘除流程：阶码相加/相减，尾数相乘/相除，再规格化与舍入。\n浮点误差来自有限位尾数、舍入和阶码范围限制。	materials/review-notes/chapter-04-arithmetic-alu-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
328	4	ch04-s007-01	4.7 运算器组成	定点运算器通常由ALU、通用寄存器、移位器、状态标志和内部数据通路组成。\nALU完成算术和逻辑运算，标志位记录进位、溢出、零、符号等状态。\n现代处理器常有整数运算单元、浮点运算单元、向量/SIMD单元等多种执行部件。	materials/review-notes/chapter-04-arithmetic-alu-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
329	4	ch04-s008-01	三、必须背下来的结构与公式	算术右移补符号位，逻辑右移补0。\n补码加减法统一：减法转化为加负数。\n溢出判断：同号相加变异号，或符号位进位与最高数值位进位异或。\n浮点加减五步：对阶、尾数运算、规格化、舍入、溢出判断。\nALU是运算器核心，配合寄存器、移位器和状态标志工作。	materials/review-notes/chapter-04-arithmetic-alu-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
330	4	ch04-s009-01	四、考试/笔试高频点	移位题：逻辑移位、算术移位、循环移位区别。\n补码加减题：计算结果并判断溢出。\n乘除法简答：为什么乘除可以用移位和加减实现。\n浮点题：说明浮点加法为什么要先对阶。\n结构题：运算器由哪些部件组成，各自作用是什么。	materials/review-notes/chapter-04-arithmetic-alu-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
331	4	ch04-s010-01	五、一句话收束	第4章的本质是把数学运算落到硬件动作上：加减靠补码统一，乘除靠移位加减反复，浮点靠对阶、规格化和舍入。	materials/review-notes/chapter-04-arithmetic-alu-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
332	5	ch05-s001-01	一、本章主线	本章回答“程序和数据存在哪里、怎样快速访问”。存储系统不是单一存储器，而是由寄存器、Cache、主存、外存构成的层次结构。重点是主存分类与性能、主存与CPU连接、Cache映射与替换、虚拟存储器、外存和存储保护。\n主线可压缩为：存储器分类 -> 主存指标 -> 主存组织 -> Cache -> 虚拟存储器 -> 外存 -> 存储保护。	materials/review-notes/chapter-05-memory-hierarchy-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
333	5	ch05-s002-01	5.1 存储体系概述	bit是构成存储器的最小单位，Byte是数据存储的基本单位。\n存储单元地址是内存单元的唯一标识。\n存储器基本操作是读和写。\n存储体系的矛盾是容量、速度、成本三者难以同时最优，因此需要层次结构。	materials/review-notes/chapter-05-memory-hierarchy-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
334	5	ch05-s003-01	5.3 主存储器与CPU连接	主存通过地址线、数据线和控制线与CPU连接。\n地址线根数决定可寻址单元数，数据线宽度影响一次传送的数据位数。\n存储芯片扩展包括位扩展和字扩展：位扩展增加字长，字扩展增加地址空间。\n片选信号用于确定当前访问哪个存储芯片。	materials/review-notes/chapter-05-memory-hierarchy-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
335	5	ch05-s004-01	5.4 高速存储器	SRAM速度快、成本高、集成度低，常用于Cache。\nDRAM集成度高、成本低、需刷新，常用于主存。\n多体交叉存储器通过多个存储体并行/交叉访问，提高连续访问带宽。	materials/review-notes/chapter-05-memory-hierarchy-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
336	5	ch05-s005-01	5.5 Cache高速缓冲存储器	Cache利用程序局部性原理：时间局部性和空间局部性。\nCache命中时直接从Cache取数据，未命中时从主存调入块。\n映射方式包括直接映射、全相联映射、组相联映射。\n替换算法常见有FIFO、LRU、随机替换等。\n写策略包括写直达和写回；写分配和非写分配决定写未命中时是否装入Cache。	materials/review-notes/chapter-05-memory-hierarchy-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
337	5	ch05-s006-01	5.6 虚拟存储器	虚拟存储器把辅存和主存结合起来，为程序提供比实际主存更大的逻辑地址空间。\n地址转换把虚拟地址映射为物理地址，常通过页表和TLB加速。\n页式管理把地址空间划分为固定大小页面，段式管理按逻辑模块划分。\n缺页时由操作系统把所需页面从外存调入主存。	materials/review-notes/chapter-05-memory-hierarchy-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
338	5	ch05-s007-01	5.7 外存与存储保护	外存用于长期保存程序和数据，典型设备有磁盘、固态硬盘、光盘等。\n磁盘性能关注寻道时间、旋转延迟、传输时间。\n存储保护用于防止程序越界访问、非法读写和破坏系统区。\n现代系统常通过权限位、段页机制、保护模式等实现保护。	materials/review-notes/chapter-05-memory-hierarchy-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
339	5	ch05-s008-01	三、必须背下来的结构与公式	存储容量 = 存储单元个数 × 存储字长。\n1K=2^10，1M=2^20，1G=2^30，1T=2^40。\nSRAM用于Cache，DRAM用于主存。\nCache三种映射：直接、全相联、组相联。\n程序局部性：时间局部性、空间局部性。\n虚拟地址需要经过地址转换才能得到物理地址。	materials/review-notes/chapter-05-memory-hierarchy-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
340	5	ch05-s009-01	四、考试/笔试高频点	容量计算：由地址线、数据线、芯片规格求存储容量和芯片数。\n辨析题：SRAM与DRAM、RAM与ROM、主存与辅存。\nCache题：给定地址判断块号、组号、标记位。\n简答题：为什么Cache能提高速度。\n虚拟存储题：虚拟地址、物理地址、页表、TLB的关系。	materials/review-notes/chapter-05-memory-hierarchy-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
341	5	ch05-s010-01	五、一句话收束	第5章的本质是用“层次化缓存思想”缓解速度、容量和成本矛盾：越靠近CPU越快越贵越小，越远离CPU越慢越便宜越大。	materials/review-notes/chapter-05-memory-hierarchy-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
342	6	ch06-s001-01	一、本章主线	本章回答“CPU能执行什么命令，以及命令如何编码”。指令系统是软件和硬件之间的接口：程序员/编译器面向ISA生成指令，硬件设计者实现这些指令。重点是指令格式、地址码、操作数类型、寻址方式、CISC/RISC、RISC-V和ARM。\n主线可压缩为：机器指令 -> 指令信息 -> ISA -> 指令格式 -> 寻址方式 -> 指令系统设计 -> RISC-V/ARM实例。	materials/review-notes/chapter-06-instruction-system-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
343	6	ch06-s002-01	6.1 机器指令与指令系统	计算机指令是指示计算机硬件执行某种操作的命令。\n机器指令是用二进制编码表示、能被硬件识别并执行的指令。\n机器语言程序是机器指令的有序集合。\n指令系统是某台计算机所有机器指令的集合，是软硬件交界面。	materials/review-notes/chapter-06-instruction-system-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
344	6	ch06-s003-01	6.2 指令信息	一条指令通常包含：操作码、源操作数、目的操作数、下一条指令地址或隐含的PC更新规则。\n操作码说明“做什么”，地址码或寄存器字段说明“对谁做”。\n不同CPU的指令格式、指令类型、寻址方式、指令条数可能不同。	materials/review-notes/chapter-06-instruction-system-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
345	6	ch06-s004-01	6.3 ISA指令集体系结构	ISA规定处理器支持的指令集合、寄存器、数据类型、寻址方式、存储空间、异常和中断等程序可见部分。\nISA给软件设计者提供抽象机器，也给硬件设计者规定实现目标。\n同一ISA可以有不同微体系结构实现，例如同样的指令集可以做成单周期、多周期或流水线处理器。	materials/review-notes/chapter-06-instruction-system-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
346	6	ch06-s005-01	6.5 寻址方式	立即寻址：操作数直接在指令中，速度快但范围受字段限制。\n直接寻址：地址字段给出有效地址。\n间接寻址：地址字段指向存放有效地址的单元。\n寄存器寻址：操作数在寄存器中，速度快。\n寄存器间接寻址：寄存器中存放有效地址。\n基址/变址/相对寻址常用于数组、程序重定位和分支跳转。	materials/review-notes/chapter-06-instruction-system-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
347	6	ch06-s006-01	6.6 指令系统设计	设计要平衡硬件复杂度、代码密度、执行效率、编译器友好性和扩展性。\nCISC指令复杂、格式多样、寻址方式丰富，代码密度高但译码复杂。\nRISC指令简单、格式规整、Load/Store结构明显，适合流水线和高频实现。	materials/review-notes/chapter-06-instruction-system-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
348	6	ch06-s007-01	6.7 RISC-V与ARM	RISC-V是开放的RISC指令集，基础整数指令集RV32I常作为教学模型。\nRISC-V常见格式包括R、I、S、B、U、J型。\nARM也是典型RISC体系，在嵌入式和移动设备中广泛使用。\n复习时重点看指令格式字段含义，而不是死记所有指令编码。	materials/review-notes/chapter-06-instruction-system-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
349	6	ch06-s008-01	三、必须背下来的结构与公式	指令系统 = 一台计算机所有机器指令的集合。\nISA是软硬件接口。\n指令基本信息：操作码、源操作数、目的操作数、下一条指令地址。\n寻址方式：立即、直接、间接、寄存器、寄存器间接、基址、变址、相对。\nRISC特点：指令简单、格式规整、Load/Store、适合流水线。	materials/review-notes/chapter-06-instruction-system-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
350	6	ch06-s009-01	四、考试/笔试高频点	概念题：机器指令、机器语言、汇编语言、指令系统、ISA。\n格式题：操作码字段和地址码字段含义。\n寻址题：给出寻址方式求有效地址。\n辨析题：CISC与RISC区别。\n实例题：识别RISC-V的R/I/S/B/U/J格式。	materials/review-notes/chapter-06-instruction-system-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
351	6	ch06-s010-01	五、一句话收束	第6章的本质是“软件如何命令硬件”：操作码规定做什么，寻址方式规定去哪取操作数，ISA规定软件与硬件共同遵守的边界。	materials/review-notes/chapter-06-instruction-system-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
352	7	ch07-s001-01	一、本章主线	本章回答“CPU如何按指令一步步控制硬件动作”。控制器不是执行运算的部件，而是根据指令、状态和时序产生控制信号，驱动取指、译码、执行、访存、写回。重点是CPU基本功能、数据通路、时序系统、硬布线控制器和微程序控制器。\n主线可压缩为：CPU功能 -> 存储器结构 -> 指令执行阶段 -> 数据通路 -> 时序控制 -> 控制器设计。	materials/review-notes/chapter-07-control-unit-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
353	7	ch07-s002-01	7.1 CPU基本功能	指令控制：保证指令按程序规定顺序执行。\n操作控制：产生完成各微操作所需的控制信号。\n时间控制：按时序安排各操作的先后。\n数据加工：通过运算器完成算术和逻辑处理。\nCPU从本质上看是一个复杂的有限状态机。	materials/review-notes/chapter-07-control-unit-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
354	7	ch07-s003-01	7.3 指令执行过程	取指阶段：PC给出指令地址，从存储器取出指令送入IR，PC更新。\n译码阶段：分析操作码、寻址方式、寄存器字段等。\n执行阶段：根据指令类型完成ALU运算、访存、转移或写回。\n在流水线中，执行阶段可进一步拆分为IF、ID、EX、MEM、WB等阶段。	materials/review-notes/chapter-07-control-unit-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
355	7	ch07-s004-01	7.4 数据通路	数据通路由寄存器组、ALU、存储器接口、总线、多路选择器和控制信号组成。\n数据通路回答“数据从哪里来，到哪里去，中间经过什么部件”。\n控制器回答“什么时候打开哪条通路，哪个部件执行什么操作”。	materials/review-notes/chapter-07-control-unit-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
356	7	ch07-s005-01	7.5 时序系统	时钟周期是控制动作的基本节拍。\n机器周期通常对应一次相对完整的基本操作，如取指、访存等。\n指令周期是一条指令从取指到执行完成所需时间。\n单周期CPU一条指令一个长周期完成；多周期CPU把指令拆成多个短周期；流水线CPU让多条指令重叠执行。	materials/review-notes/chapter-07-control-unit-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
357	7	ch07-s006-01	7.6 硬布线控制器	硬布线控制器由组合逻辑和时序逻辑直接产生控制信号。\n优点是速度快，适合RISC和指令格式规整的处理器。\n缺点是设计和修改困难，指令复杂时逻辑庞大。	materials/review-notes/chapter-07-control-unit-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
358	7	ch07-s007-01	7.7 微程序控制器	微程序控制把控制信号编码成微指令，微指令组成微程序。\n一条机器指令对应一段微程序，由控制存储器顺序取出微指令执行。\n优点是结构规整、易修改、适合复杂指令；缺点是速度通常慢于硬布线控制。	materials/review-notes/chapter-07-control-unit-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
359	7	ch07-s008-01	三、必须背下来的结构与公式	CPU四类基本控制：指令控制、操作控制、时间控制、数据加工。\n指令执行阶段：取指、译码、执行；流水线常拆为IF、ID、EX、MEM、WB。\n指令周期、机器周期、时钟周期的层次关系。\n硬布线控制：快但难改。微程序控制：灵活但较慢。\n控制器 + 数据通路共同构成CPU核心。	materials/review-notes/chapter-07-control-unit-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
360	7	ch07-s009-01	四、考试/笔试高频点	概念题：CPU为什么可看作有限状态机。\n流程题：说明一条指令从取指到执行的全过程。\n比较题：冯·诺依曼结构和哈佛结构区别。\n比较题：单周期、多周期、流水线CPU区别。\n简答题：硬布线控制器与微程序控制器优缺点。	materials/review-notes/chapter-07-control-unit-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
361	7	ch07-s010-01	五、一句话收束	第7章的本质是把“执行一条指令”拆成一串微操作，再由时序和控制信号把数据通路一步步打开。	materials/review-notes/chapter-07-control-unit-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
362	8	ch08-s001-01	一、本章主线	本章把前面学过的信息表示、指令系统、运算器、存储器、控制器串起来，用RISC-V和ARM模型机展示“如何真正设计一台简化CPU”。重点不是背全部指令，而是理解目标指令集、数据通路、控制信号和指令执行过程之间的对应关系。\n主线可压缩为：确定目标指令集 -> 确定系统结构 -> 设计数据通路 -> 分析各类指令执行流程 -> 设计控制单元。	materials/review-notes/chapter-08-riscv-arm-model-machine-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
363	8	ch08-s002-01	8.1 RISC-V模型机目标指令集	课件选取RV32I核心指令子集作为模型机目标，包含算术逻辑、传送、访存和转移类指令。\n典型格式包括R型、I型、S型、B型、U型、J型。\nR型多用于寄存器-寄存器运算；I型用于立即数运算、load、jalr等；S型用于store；B型用于条件分支；U型用于高位立即数；J型用于跳转。	materials/review-notes/chapter-08-riscv-arm-model-machine-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
364	8	ch08-s003-01	8.3 运算与传送指令数据通路	add、sub、and、or等R型指令：读rs1和rs2 -> ALU运算 -> 写回rd。\naddi、ori等I型立即数指令：读rs1 -> 立即数符号扩展 -> ALU运算 -> 写回rd。\nlui等U型指令：立即数高位装入 -> 写回rd。	materials/review-notes/chapter-08-riscv-arm-model-machine-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
365	8	ch08-s004-01	8.4 访存指令数据通路	load指令：rs1 + 符号扩展立即数得到有效地址 -> 读数据存储器 -> 写回rd。\nstore指令：rs1 + 符号扩展立即数得到有效地址 -> 把rs2内容写入数据存储器。\n访存类指令体现RISC的Load/Store思想：只有load/store直接访问存储器，普通运算在寄存器之间进行。	materials/review-notes/chapter-08-riscv-arm-model-machine-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
366	8	ch08-s005-01	8.5 转移类指令数据通路	条件分支如beq：比较rs1和rs2，若满足条件，则PC = PC + 分支偏移；否则PC = PC + 4。\njal：保存返回地址PC+4到rd，并跳转到目标地址。\njalr：保存PC+4到rd，目标地址通常由rs1 + offset得到。\n转移指令的关键是同时处理“比较/目标地址计算/PC选择”。	materials/review-notes/chapter-08-riscv-arm-model-machine-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
367	8	ch08-s006-01	8.6 控制单元设计	控制单元根据opcode、funct3、funct7等字段产生控制信号。\n常见控制信号包括寄存器写使能、ALU操作选择、立即数类型选择、存储器读写、写回数据选择、PC选择等。\n硬布线控制适合RISC-V这类格式规整、指令简单的模型机。	materials/review-notes/chapter-08-riscv-arm-model-machine-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
368	8	ch08-s007-01	8.7 ARM模型机设计	ARM模型机同样围绕目标指令集、寄存器、数据通路和控制信号设计。\nARM强调嵌入式应用和高效指令执行，常具有条件执行、灵活移位寻址等特点。\n与RISC-V对比时，重点看“指令格式和控制逻辑如何影响数据通路复杂度”。	materials/review-notes/chapter-08-riscv-arm-model-machine-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
369	8	ch08-s008-01	三、必须背下来的结构与公式	RISC-V常见格式：R、I、S、B、U、J。\n五阶段：IF、ID、EX、MEM、WB。\nR型：读rs1/rs2 -> ALU -> 写rd。\nload：算地址 -> 读存储器 -> 写rd。store：算地址 -> 写存储器。\nbranch/jump的核心是PC选择。\n控制信号由指令字段译码产生。	materials/review-notes/chapter-08-riscv-arm-model-machine-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
370	8	ch08-s009-01	四、考试/笔试高频点	流程题：给出一条RISC-V指令，说明它经过哪些数据通路。\n结构题：五阶段流水线每阶段做什么。\n辨析题：load和store的数据通路差别。\n控制题：某类指令需要哪些控制信号。\n综合题：为什么RISC-V适合教学CPU设计。	materials/review-notes/chapter-08-riscv-arm-model-machine-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
371	8	ch08-s010-01	五、一句话收束	第8章的本质是一次综合设计训练：每条指令都要回答读哪些寄存器、ALU做什么、是否访存、写回什么、PC如何更新。	materials/review-notes/chapter-08-riscv-arm-model-machine-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
372	9	ch09-s001-01	一、本章主线	本章回答“CPU如何与外部设备交换数据”。外设速度慢、类型多、格式杂，不能直接和CPU裸连，因此需要I/O接口作为适配器。重点是I/O接口、主机与外设交换方式、中断系统和DMA。\n主线可压缩为：外设特点 -> I/O接口 -> 程序查询 -> 中断 -> DMA。	materials/review-notes/chapter-09-io-system-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
373	9	ch09-s002-01	9.1 I/O系统概述	外设的作用包括人机交互、数据格式转换、信息存储和扩展计算机应用领域。\n外设特点：工作速度差异大、结构原理差异大、时序独立、异步性明显。\n外设信息不能直接与CPU兼容，原因包括数据格式、速度、逻辑时序和信号电平差异。\nI/O接口电路是CPU与外设之间的桥梁，也叫I/O适配器。	materials/review-notes/chapter-09-io-system-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
374	9	ch09-s003-01	9.2 输入输出接口	I/O接口通常包含数据寄存器、状态寄存器、控制寄存器、地址译码、电平转换和控制逻辑。\n数据寄存器暂存CPU与外设交换的数据。\n状态寄存器反映外设是否就绪、是否忙、是否出错。\n控制寄存器接收CPU发出的启动、停止、读写方式等控制命令。	materials/review-notes/chapter-09-io-system-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
375	9	ch09-s004-01	9.3 I/O端口与编址	I/O端口是CPU访问接口寄存器的地址化入口。\n统一编址：I/O端口和内存统一在一个地址空间，用普通访存指令访问。\n独立编址：I/O端口有独立地址空间，需要专门I/O指令。\n统一编址编程统一，独立编址地址空间清晰、I/O语义明确。	materials/review-notes/chapter-09-io-system-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
376	9	ch09-s005-01	9.5 中断系统	中断是外设或异常事件请求CPU暂停当前程序，转去执行服务程序的机制。\n中断过程包括中断请求、中断判优、中断响应、保护现场、执行中断服务程序、恢复现场和返回。\n中断判优解决多个中断源同时请求时的优先级问题。\n中断屏蔽用于允许或禁止某些中断请求。	materials/review-notes/chapter-09-io-system-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
377	9	ch09-s006-01	9.6 DMA	DMA用于外设与主存之间直接进行数据块传送，CPU只负责初始化和结束处理。\nDMA控制器通常需要掌握主存地址、传送字数、传送方向、设备地址等信息。\nDMA传送方式常见有停止CPU访存、周期挪用和透明DMA。\nDMA适合磁盘、网卡、显卡等高速大块数据传输。	materials/review-notes/chapter-09-io-system-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
378	9	ch09-s007-01	三、必须背下来的结构与公式	I/O接口 = CPU与外设之间的适配桥梁。\n接口寄存器：数据、状态、控制。\nI/O编址：统一编址、独立编址。\n交换方式：程序查询、中断、DMA。\n中断过程：请求、判优、响应、保护现场、服务、恢复、返回。\nDMA核心：外设与主存直接交换数据，CPU少参与。	materials/review-notes/chapter-09-io-system-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
379	9	ch09-s008-01	四、考试/笔试高频点	概念题：为什么外设不能直接连CPU。\n结构题：I/O接口包含哪些寄存器，各自作用是什么。\n比较题：查询、中断、DMA的区别和适用场景。\n流程题：中断响应和中断服务过程。\n简答题：DMA为什么能提高高速I/O效率。	materials/review-notes/chapter-09-io-system-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
380	9	ch09-s009-01	五、一句话收束	第9章的本质是解决CPU和外设之间的速度、格式、时序不匹配：接口做适配，查询靠CPU等，中断让外设通知CPU，DMA让数据绕开CPU直接成块搬运。	materials/review-notes/chapter-09-io-system-summary.docx	\N	\N	2026-06-02 05:49:44.611295+00
\.


--
-- Data for Name: knowledge_points; Type: TABLE DATA; Schema: public; Owner: comp_org
--

COPY public.knowledge_points (id, chapter_id, name, summary, difficulty, created_at, updated_at) FROM stdin;
1	1	一、本章主线	这一章的作用不是让你背计算机历史，而是建立整门“计算机组成原理与系统结构”的总地图：计算机如何从物理硬件出发，经过指令、程序、操作系统和应用软件，最终完成用户任务。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
2	1	二、计算机的发展：重点抓住“二进制 + 存储程序”	电子数字计算机的主要特点是高速、高精度，并以二进制方式表示和处理信息。第一台电子数字计算机 ENIAC 于 1946 年诞生，早期采用十进制操作，并通过布线和拨动开关控制运算。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
3	1	三、计算机分类：重点是 Flynn 分类法	Flynn 分类法根据计算机运行时的两类信息流进行划分：指令流和数据流。指令流表示“执行什么操作”，数据流表示“被处理的数据”。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
4	1	4.1 硬件系统	硬件系统是计算机系统的物质基础，主要由主机和外围设备组成。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
5	1	4.2 软件系统	软件系统是硬件功能的扩充和完善，它负责管理硬件资源、组织程序运行并服务用户任务。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
6	1	五、冯·诺依曼体系结构：本章核心	冯·诺依曼体系结构的核心不是某个具体机器，而是一套现代通用计算机的基本组织原则。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
7	1	7.2 编译、汇编、链接、解释	以 C 程序为例，典型编译型语言的运行过程如下：	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
8	1	八、计算机系统层次结构：理解“抽象层”	计算机系统是分层结构。越往下越接近硬件，越往上越接近用户任务。分层的作用是隐藏底层复杂细节，让上层只面对更简单的模型。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
9	1	9.1 机器字长	机器字长是 CPU 一次能处理的数据位数，常见有 8 位、16 位、32 位、64 位。它会影响寄存器位数、运算部件位数、数据总线位数、运算能力和可寻址空间。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
10	1	9.2 存储容量	存储容量表示能存放的二进制信息量大小。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
11	1	9.3 运算速度指标	性能判断的关键陷阱：不能只看主频、CPI 或 MIPS 中的某一个指标。真正比较程序快慢，应以 CPU 执行时间为核心，并结合指令条数、CPI、主频、Cache 命中率、I/O 等因素综合判断。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
12	1	10.1 概念题高频点	冯·诺依曼结构是什么？	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
13	1	10.2 分类题高频点	Flynn 分类法：SISD、SIMD、MISD、MIMD。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
14	1	10.3 计算题高频点	平均 CPI：按不同指令比例加权平均。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
15	1	十一、本章必须背下来的压缩版	五大部件：运算器、控制器、存储器、输入设备、输出设备	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
16	2	一、本章主线	本章围绕“计算机各部件怎样连接并交换信息”展开。总线不是简单的几根线，而是一组带有电气、机械、功能和时序约定的公共通信通道。后面学习CPU、存储器和I/O时，所有数据传送都要落回总线结构、总线控制和总线时序。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
17	2	2.1 总线的基本概念	物理角度：总线是一组实现互连和通信的导线。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
18	2	2.3 总线分类	按功能可分为地址总线AB、数据总线DB、控制总线CB。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
19	2	2.4 总线系统结构	单总线结构简单、成本低，但所有部件共享一条通路，容易形成瓶颈。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
20	2	2.5 总线性能指标	总线宽度：一次并行传送的二进制位数，常见为8/16/32/64位。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
21	2	2.6 总线控制	总线判优解决“多个主设备同时申请总线时谁先使用”的问题。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
22	2	2.7 总线标准	总线标准规定信号、电气、机械、协议和时序，使不同厂商设备可以互联。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
23	2	三、必须背下来的结构与公式	总线三类信号：地址总线AB、数据总线DB、控制总线CB。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
24	2	四、考试/笔试高频点	概念辨析：地址总线、数据总线、控制总线各自传什么。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
25	2	五、一句话收束	第2章的本质是把“计算机部件如何互连”讲清楚：地址线决定访问谁，数据线传送内容，控制线决定何时、怎样传；判优解决谁用总线，时序解决何时有效。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
26	3	一、本章主线	本章回答“现实世界的信息怎样变成计算机内部的0和1”。数值信息要经过进位制、符号位、定点/浮点格式表示；非数值信息要经过字符编码、汉字编码等方式表示；为了发现或纠正传输与存储错误，还要引入校验码。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
27	3	3.1 进位计数制与数制转换	任意R进制数由基数R、权值R^i和数码D_i组成，其实际值是各位数码乘权后求和。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
28	3	3.2 数值数据格式	数值数据首先分为整数和实数；整数常用定点表示，实数常用浮点表示。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
29	3	3.4 补码与溢出	n位补码整数的表示范围通常为 -2^(n-1) 到 2^(n-1)-1。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
30	3	3.5 定点数表示	定点小数把小数点固定在符号位之后，适合表示绝对值小于1的数。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
31	3	3.6 浮点数表示	浮点数一般写成：数值 = 尾数 × 基数^阶码。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
32	3	3.7 非数值数据编码	字符编码用于表示英文、数字、标点等，常见有ASCII。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
33	3	3.8 校验码	奇偶校验能发现奇数位错误，但不能定位和纠正错误。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
34	3	三、必须背下来的结构与公式	R进制数值 = Σ D_i × R^i。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
35	3	四、考试/笔试高频点	数制转换题：二/八/十/十六进制互转。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
36	3	五、一句话收束	第3章的本质是“信息到0/1的翻译规则”：整数看补码，实数看浮点，字符看编码，可靠性看校验码。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
37	4	一、本章主线	本章回答“计算机如何在硬件中完成加、减、乘、除和浮点运算”。高级语言中的+、-、*、/最终要变成机器指令，再由ALU、移位器、寄存器和控制逻辑完成。重点是定点补码运算、溢出判断、乘除法移位加减思想、浮点运算流程和运算器结构。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
38	4	4.1 计算机中的运算操作	算术运算包括加、减、乘、除。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
39	4	4.3 定点加减运算	补码加法是硬件整数运算的核心：符号位也参与运算，丢弃最高进位。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
40	4	4.4 定点乘法运算	乘法本质是“部分积累加 + 移位”。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
41	4	4.5 定点除法运算	除法本质是“试商 + 减法/恢复 + 移位”。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
42	4	4.6 浮点运算	浮点加减流程：对阶 -> 尾数加减 -> 规格化 -> 舍入 -> 溢出判断。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
43	4	4.7 运算器组成	定点运算器通常由ALU、通用寄存器、移位器、状态标志和内部数据通路组成。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
44	4	三、必须背下来的结构与公式	算术右移补符号位，逻辑右移补0。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
45	4	四、考试/笔试高频点	移位题：逻辑移位、算术移位、循环移位区别。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
46	4	五、一句话收束	第4章的本质是把数学运算落到硬件动作上：加减靠补码统一，乘除靠移位加减反复，浮点靠对阶、规格化和舍入。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
47	5	一、本章主线	本章回答“程序和数据存在哪里、怎样快速访问”。存储系统不是单一存储器，而是由寄存器、Cache、主存、外存构成的层次结构。重点是主存分类与性能、主存与CPU连接、Cache映射与替换、虚拟存储器、外存和存储保护。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
48	5	5.1 存储体系概述	bit是构成存储器的最小单位，Byte是数据存储的基本单位。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
49	5	5.3 主存储器与CPU连接	主存通过地址线、数据线和控制线与CPU连接。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
50	5	5.4 高速存储器	SRAM速度快、成本高、集成度低，常用于Cache。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
51	5	5.5 Cache高速缓冲存储器	Cache利用程序局部性原理：时间局部性和空间局部性。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
52	5	5.6 虚拟存储器	虚拟存储器把辅存和主存结合起来，为程序提供比实际主存更大的逻辑地址空间。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
53	5	5.7 外存与存储保护	外存用于长期保存程序和数据，典型设备有磁盘、固态硬盘、光盘等。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
54	5	三、必须背下来的结构与公式	存储容量 = 存储单元个数 × 存储字长。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
55	5	四、考试/笔试高频点	容量计算：由地址线、数据线、芯片规格求存储容量和芯片数。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
56	5	五、一句话收束	第5章的本质是用“层次化缓存思想”缓解速度、容量和成本矛盾：越靠近CPU越快越贵越小，越远离CPU越慢越便宜越大。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
57	6	一、本章主线	本章回答“CPU能执行什么命令，以及命令如何编码”。指令系统是软件和硬件之间的接口：程序员/编译器面向ISA生成指令，硬件设计者实现这些指令。重点是指令格式、地址码、操作数类型、寻址方式、CISC/RISC、RISC-V和ARM。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
58	6	6.1 机器指令与指令系统	计算机指令是指示计算机硬件执行某种操作的命令。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
59	6	6.2 指令信息	一条指令通常包含：操作码、源操作数、目的操作数、下一条指令地址或隐含的PC更新规则。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
60	6	6.3 ISA指令集体系结构	ISA规定处理器支持的指令集合、寄存器、数据类型、寻址方式、存储空间、异常和中断等程序可见部分。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
61	6	6.5 寻址方式	立即寻址：操作数直接在指令中，速度快但范围受字段限制。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
62	6	6.6 指令系统设计	设计要平衡硬件复杂度、代码密度、执行效率、编译器友好性和扩展性。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
63	6	6.7 RISC-V与ARM	RISC-V是开放的RISC指令集，基础整数指令集RV32I常作为教学模型。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
64	6	三、必须背下来的结构与公式	指令系统 = 一台计算机所有机器指令的集合。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
65	6	四、考试/笔试高频点	概念题：机器指令、机器语言、汇编语言、指令系统、ISA。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
66	6	五、一句话收束	第6章的本质是“软件如何命令硬件”：操作码规定做什么，寻址方式规定去哪取操作数，ISA规定软件与硬件共同遵守的边界。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
67	7	一、本章主线	本章回答“CPU如何按指令一步步控制硬件动作”。控制器不是执行运算的部件，而是根据指令、状态和时序产生控制信号，驱动取指、译码、执行、访存、写回。重点是CPU基本功能、数据通路、时序系统、硬布线控制器和微程序控制器。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
68	7	7.1 CPU基本功能	指令控制：保证指令按程序规定顺序执行。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
69	7	7.3 指令执行过程	取指阶段：PC给出指令地址，从存储器取出指令送入IR，PC更新。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
70	7	7.4 数据通路	数据通路由寄存器组、ALU、存储器接口、总线、多路选择器和控制信号组成。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
71	7	7.5 时序系统	时钟周期是控制动作的基本节拍。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
72	7	7.6 硬布线控制器	硬布线控制器由组合逻辑和时序逻辑直接产生控制信号。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
73	7	7.7 微程序控制器	微程序控制把控制信号编码成微指令，微指令组成微程序。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
74	7	三、必须背下来的结构与公式	CPU四类基本控制：指令控制、操作控制、时间控制、数据加工。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
75	7	四、考试/笔试高频点	概念题：CPU为什么可看作有限状态机。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
76	7	五、一句话收束	第7章的本质是把“执行一条指令”拆成一串微操作，再由时序和控制信号把数据通路一步步打开。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
77	8	一、本章主线	本章把前面学过的信息表示、指令系统、运算器、存储器、控制器串起来，用RISC-V和ARM模型机展示“如何真正设计一台简化CPU”。重点不是背全部指令，而是理解目标指令集、数据通路、控制信号和指令执行过程之间的对应关系。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
78	8	8.1 RISC-V模型机目标指令集	课件选取RV32I核心指令子集作为模型机目标，包含算术逻辑、传送、访存和转移类指令。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
79	8	8.3 运算与传送指令数据通路	add、sub、and、or等R型指令：读rs1和rs2 -> ALU运算 -> 写回rd。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
80	8	8.4 访存指令数据通路	load指令：rs1 + 符号扩展立即数得到有效地址 -> 读数据存储器 -> 写回rd。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
81	8	8.5 转移类指令数据通路	条件分支如beq：比较rs1和rs2，若满足条件，则PC = PC + 分支偏移；否则PC = PC + 4。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
82	8	8.6 控制单元设计	控制单元根据opcode、funct3、funct7等字段产生控制信号。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
83	8	8.7 ARM模型机设计	ARM模型机同样围绕目标指令集、寄存器、数据通路和控制信号设计。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
84	8	三、必须背下来的结构与公式	RISC-V常见格式：R、I、S、B、U、J。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
85	8	四、考试/笔试高频点	流程题：给出一条RISC-V指令，说明它经过哪些数据通路。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
86	8	五、一句话收束	第8章的本质是一次综合设计训练：每条指令都要回答读哪些寄存器、ALU做什么、是否访存、写回什么、PC如何更新。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
87	9	一、本章主线	本章回答“CPU如何与外部设备交换数据”。外设速度慢、类型多、格式杂，不能直接和CPU裸连，因此需要I/O接口作为适配器。重点是I/O接口、主机与外设交换方式、中断系统和DMA。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
88	9	9.1 I/O系统概述	外设的作用包括人机交互、数据格式转换、信息存储和扩展计算机应用领域。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
89	9	9.2 输入输出接口	I/O接口通常包含数据寄存器、状态寄存器、控制寄存器、地址译码、电平转换和控制逻辑。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
90	9	9.3 I/O端口与编址	I/O端口是CPU访问接口寄存器的地址化入口。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
91	9	9.5 中断系统	中断是外设或异常事件请求CPU暂停当前程序，转去执行服务程序的机制。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
92	9	9.6 DMA	DMA用于外设与主存之间直接进行数据块传送，CPU只负责初始化和结束处理。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
93	9	三、必须背下来的结构与公式	I/O接口 = CPU与外设之间的适配桥梁。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
94	9	四、考试/笔试高频点	概念题：为什么外设不能直接连CPU。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
95	9	五、一句话收束	第9章的本质是解决CPU和外设之间的速度、格式、时序不匹配：接口做适配，查询靠CPU等，中断让外设通知CPU，DMA让数据绕开CPU直接成块搬运。	medium	2026-06-01 13:05:15.47451+00	2026-06-01 13:05:15.47451+00
\.


--
-- Data for Name: practice_sessions; Type: TABLE DATA; Schema: public; Owner: comp_org
--

COPY public.practice_sessions (id, user_id, mode, chapter_id, question_count, score, started_at, submitted_at) FROM stdin;
1	demo	chapter	1	1	1.00	2026-06-01 12:21:27.640245+00	2026-06-01 12:21:31.454521+00
2	demo	chapter	1	1	1.00	2026-06-01 12:23:24.201233+00	2026-06-01 12:23:25.514816+00
3	demo	chapter	3	1	1.00	2026-06-01 12:26:44.903108+00	2026-06-01 12:27:02.940405+00
4	demo	chapter	3	5	\N	2026-06-01 12:36:40.791009+00	\N
5	demo	chapter	3	1	\N	2026-06-01 12:37:28.083395+00	\N
6	demo	chapter	1	5	3.00	2026-06-01 12:47:35.62+00	2026-06-01 12:48:52.353558+00
167	anon-faa2677b-9147-40e8-b35b-844d3cf1ef62	chapter	1	5	\N	2026-06-02 02:46:41.225327+00	\N
168	anon-8c7d7651-8613-4ac7-921a-3a4836f35c05	chapter	1	5	\N	2026-06-02 02:46:58.057294+00	\N
9	demo	chapter	1	5	\N	2026-06-01 12:59:37.159505+00	\N
247	anon-2f10427c-5413-46a7-ac98-9d64c60a4e30	chapter	3	15	\N	2026-06-02 06:27:29.027426+00	\N
17	demo	chapter	1	5	\N	2026-06-01 13:19:57.127423+00	\N
57	demo	final_review	\N	5	\N	2026-06-01 14:02:28.343085+00	\N
58	demo	final_review	\N	15	\N	2026-06-01 14:02:57.751646+00	\N
110	demo	final_review	\N	5	\N	2026-06-01 14:52:12.565777+00	\N
111	demo	final_review	\N	5	\N	2026-06-01 14:53:23.624718+00	\N
112	demo	final_review	\N	5	\N	2026-06-01 14:53:28.008957+00	\N
23	demo	chapter	1	1	\N	2026-06-01 13:28:47.588766+00	\N
113	demo	chapter	8	2	0.00	2026-06-01 14:54:13.218731+00	2026-06-01 14:54:42.520875+00
114	demo	final_review	\N	15	\N	2026-06-01 15:20:17.4718+00	\N
183	smoke-reading	chapter	1	1	\N	2026-06-02 03:00:30.945306+00	\N
184	smoke-reading	chapter	1	1	\N	2026-06-02 03:00:41.269743+00	\N
262	1	chapter	1	5	0.00	2026-06-02 10:14:18.039435+00	2026-06-02 10:14:56.270175+00
263	1	chapter	1	3	1.00	2026-06-02 10:20:44.24814+00	2026-06-02 10:21:54.825158+00
122	demo	final_review	\N	15	\N	2026-06-01 15:21:52.677911+00	\N
123	demo	chapter	1	15	\N	2026-06-02 02:03:44.67837+00	\N
124	demo	chapter	1	15	\N	2026-06-02 02:04:44.040029+00	\N
125	demo	chapter	8	1	\N	2026-06-02 02:05:00.676141+00	\N
126	demo	chapter	8	15	\N	2026-06-02 02:05:39.08115+00	\N
127	demo	chapter	1	30	\N	2026-06-02 02:11:09.161717+00	\N
214	pw-unsubmitted-1780369921935	chapter	1	5	\N	2026-06-02 03:12:02.649233+00	\N
269	1	chapter	1	5	2.00	2026-06-02 12:46:36.895775+00	2026-06-02 12:46:48.727174+00
270	2	chapter	1	1	0.00	2026-06-02 12:51:56.164277+00	2026-06-02 12:51:56.199536+00
84	demo	final_review	\N	4	\N	2026-06-01 14:34:43.167894+00	\N
85	demo	final_review	\N	4	\N	2026-06-01 14:35:06.846318+00	\N
86	demo	final_review	\N	5	\N	2026-06-01 14:35:14.499232+00	\N
87	demo	final_review	\N	5	\N	2026-06-01 14:35:20.855531+00	\N
88	demo	final_review	\N	4	\N	2026-06-01 14:36:54.960076+00	\N
197	anon-fd1ac5c7-be8c-4aec-94d1-289f53e29e55	chapter	1	2	\N	2026-06-02 03:02:06.387236+00	\N
198	anon-3031ad21-be98-441e-a09e-af0332bf63a1	chapter	1	2	\N	2026-06-02 03:02:29.360153+00	\N
215	anon-2f10427c-5413-46a7-ac98-9d64c60a4e30	chapter	2	15	13.00	2026-06-02 05:50:45.607715+00	2026-06-02 06:04:48.224875+00
\.


--
-- Data for Name: question_feedback; Type: TABLE DATA; Schema: public; Owner: comp_org
--

COPY public.question_feedback (id, user_id, question_id, is_helpful, created_at, feedback_type, reason) FROM stdin;
36	anon-2f10427c-5413-46a7-ac98-9d64c60a4e30	146	t	2026-06-02 06:30:18.625527+00	helpful	\N
37	1	686	t	2026-06-02 09:54:51.634268+00	helpful	\N
38	1	690	t	2026-06-02 09:54:52.98953+00	helpful	\N
39	1	689	t	2026-06-02 09:54:54.820287+00	helpful	\N
40	1	688	t	2026-06-02 09:54:56.31763+00	helpful	\N
41	1	687	t	2026-06-02 09:54:58.002219+00	helpful	\N
\.


--
-- Data for Name: questions; Type: TABLE DATA; Schema: public; Owner: comp_org
--

COPY public.questions (id, chapter_id, knowledge_point_id, parent_question_id, type, difficulty, stem, options_json, answer_json, rubric_json, explanation, source_context, source_assignment, is_ai_generated, is_reviewed, created_at, updated_at, archived, ai_status, quality_score, attempt_count, helpful_count, not_helpful_count, error_count, flag_count) FROM stdin;
1	1	\N	\N	single_choice	easy	冯·诺依曼计算机的核心思想是？	[{"key": "A", "text": "存储程序"}, {"key": "B", "text": "分布式计算"}, {"key": "C", "text": "流水线并行"}, {"key": "D", "text": "虚拟存储"}]	{"answer": "A"}	[]	冯·诺依曼体系结构的核心是把程序和数据以二进制形式存放在存储器中，并按指令序列自动执行。	phase-1 sample seed	\N	f	t	2026-06-01 12:20:54.189578+00	2026-06-01 12:20:54.189578+00	f	\N	0	0	0	0	0	0
2	2	\N	\N	true_false	easy	总线是一组能为多个部件分时共享的信息传输线。	[{"key": "true", "text": "对"}, {"key": "false", "text": "错"}]	{"answer": "TRUE"}	[]	总线通常由多个部件共享，通过总线仲裁和时序控制完成信息传输。	phase-1 sample seed	\N	f	t	2026-06-01 12:20:54.189578+00	2026-06-01 12:20:54.189578+00	f	\N	0	0	0	0	0	0
3	3	\N	\N	fill_blank	medium	带符号整数常用的机器数表示包括原码、反码和____。	[]	{"blanks": [{"index": 1, "answer": "补码", "acceptable_answers": ["二进制补码"]}]}	[]	补码可以把减法转换为加法，是计算机中最常用的带符号整数表示方式。	phase-1 sample seed	\N	f	t	2026-06-01 12:20:54.189578+00	2026-06-01 12:20:54.189578+00	f	\N	0	0	0	0	0	0
4	4	\N	\N	multiple_choice	medium	下列哪些部件通常属于运算器的组成部分？	[{"key": "A", "text": "ALU"}, {"key": "B", "text": "累加器"}, {"key": "C", "text": "状态寄存器"}, {"key": "D", "text": "外部磁盘"}]	{"answer": ["A", "B", "C"]}	[]	运算器通常包含 ALU、通用/专用寄存器及状态标志相关部件，外部磁盘属于外存设备。	phase-1 sample seed	\N	f	t	2026-06-01 12:20:54.189578+00	2026-06-01 12:20:54.189578+00	f	\N	0	0	0	0	0	0
5	5	\N	\N	single_choice	medium	Cache 的主要作用是？	[{"key": "A", "text": "扩大外存容量"}, {"key": "B", "text": "缓解 CPU 与主存速度差异"}, {"key": "C", "text": "替代寄存器"}, {"key": "D", "text": "执行算术运算"}]	{"answer": "B"}	[]	Cache 利用程序局部性，在 CPU 和主存之间提供高速缓冲。	phase-1 sample seed	\N	f	t	2026-06-01 12:20:54.189578+00	2026-06-01 12:20:54.189578+00	f	\N	0	0	0	0	0	0
6	6	\N	\N	multiple_choice	medium	指令通常可以包含哪些字段？	[{"key": "A", "text": "操作码"}, {"key": "B", "text": "地址码"}, {"key": "C", "text": "寻址方式信息"}, {"key": "D", "text": "显示器刷新率"}]	{"answer": ["A", "B", "C"]}	[]	指令格式通常描述操作码、操作数地址以及寻址方式等信息。	phase-1 sample seed	\N	f	t	2026-06-01 12:20:54.189578+00	2026-06-01 12:20:54.189578+00	f	\N	0	0	0	0	0	0
7	7	\N	\N	short_answer	medium	简述控制器的主要功能。	[]	{"reference_answer": "控制器负责取指令、分析指令，并按时序产生控制信号，协调运算器、存储器和输入输出设备完成指令执行。"}	["取指令", "分析指令", "控制信号", "协调"]	控制器是 CPU 的指挥部件，核心任务是产生正确的操作控制信号和时序信号。	phase-1 sample seed	\N	f	t	2026-06-01 12:20:54.189578+00	2026-06-01 12:20:54.189578+00	f	\N	0	0	0	0	0	0
8	8	\N	\N	single_choice	easy	RISC-V 属于哪类指令集体系结构？	[{"key": "A", "text": "复杂指令集 CISC"}, {"key": "B", "text": "精简指令集 RISC"}, {"key": "C", "text": "专用图形指令集"}, {"key": "D", "text": "数据库查询语言"}]	{"answer": "B"}	[]	RISC-V 是开放的精简指令集架构。	phase-1 sample seed	\N	f	t	2026-06-01 12:20:54.189578+00	2026-06-01 12:20:54.189578+00	f	\N	0	0	0	0	0	0
9	9	\N	\N	true_false	medium	DMA 可以在不经过 CPU 逐字节干预的情况下完成主存与外设之间的数据传送。	[{"key": "true", "text": "对"}, {"key": "false", "text": "错"}]	{"answer": "TRUE"}	[]	DMA 通过专门控制器管理数据块传送，CPU 主要负责初始化和结束处理。	phase-1 sample seed	\N	f	t	2026-06-01 12:20:54.189578+00	2026-06-01 12:20:54.189578+00	f	\N	0	0	0	0	0	0
10	7	\N	\N	multiple_choice	medium	系统总线中含哪三组总线？	[{"key": "A", "text": "IB"}, {"key": "B", "text": "AB"}, {"key": "C", "text": "DB"}, {"key": "D", "text": "CB"}]	{"answer": ["B", "C", "D"]}	[]	AB; DB; CB;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/01-第7章作业-1st.txt#1	第7章作业-1st 已完成 智能分析 剩余148小时13分钟	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
11	7	\N	\N	multiple_choice	medium	关于普林斯顿结构和哈佛结构，正确的说法是：	[{"key": "A", "text": "它们都是运算器的结构类型"}, {"key": "B", "text": "普林斯顿结构指计算机中只有一个存储器，用于存储指令和数据；"}, {"key": "C", "text": "哈佛结构指计算机中的指令和数据分别存储于不同的存储器，并且有各自独立的一套总线来访问存储器"}, {"key": "D", "text": "哈佛结构的指令总线宽度和数据总线宽度可以不一致"}]	{"answer": ["B", "C", "D"]}	[]	普林斯顿结构指计算机中只有一个存储器，用于存储指令和数据；; 哈佛结构指计算机中的指令和数据分别存储于不同的存储器，并且有各自独立的一套总线来访问存储器; 哈佛结构的指令总线宽度和数据总线宽度可以不一致;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/01-第7章作业-1st.txt#2	第7章作业-1st 已完成 智能分析 剩余148小时13分钟	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
12	7	\N	\N	multiple_choice	medium	有关指令周期的说法中，正确的是：	[{"key": "A", "text": "不同指令的指令周期是不同的。"}, {"key": "B", "text": "同种操作的指令，寻址方式不同，其指令周期也是不同的。"}, {"key": "C", "text": "指令周期是指从主存取一条指令，到这条指令执行完所花的时间。"}, {"key": "D", "text": "如果采用同步控制时序，则可以选择所有指令中，指令周期最长的那条，作为统一的指令周期。"}]	{"answer": ["A", "B", "C", "D"]}	[]	不同指令的指令周期是不同的。; 同种操作的指令，寻址方式不同，其指令周期也是不同的。; 指令周期是指从主存取一条指令，到这条指令执行完所花的时间。; 如果采用同步控制时序，则可以选择所有指令中，指令周期最长的那条，作为统一的指令周期。;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/01-第7章作业-1st.txt#3	第7章作业-1st 已完成 智能分析 剩余148小时13分钟	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
13	7	\N	\N	multiple_choice	medium	关于指令集体系架构ISA的说法中，正确的是：	[{"key": "A", "text": "ISA是底层软件和硬件之间的抽象接口和规约。"}, {"key": "B", "text": "ISA为底层软件设计者，规定了如何使用硬件。"}, {"key": "C", "text": "ISA为硬件设计者指明了处理器硬件设计的目标。"}, {"key": "D", "text": "ISA就是指令系统。"}]	{"answer": ["A", "B", "C"]}	[]	ISA是底层软件和硬件之间的抽象接口和规约。; ISA为底层软件设计者，规定了如何使用硬件。; ISA为硬件设计者指明了处理器硬件设计的目标。;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/01-第7章作业-1st.txt#4	第7章作业-1st 已完成 智能分析 剩余148小时13分钟	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
121	4	\N	\N	true_false	medium	串行乘法运算是通过多次累加、左移来完成的，而串行除法运算是通过多次加减法、右移来完成的。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "FALSE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/07-第4章作业.txt#1	第4章作业 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
14	7	\N	\N	multiple_choice	medium	控制器由以下哪些部件构成？	[{"key": "A", "text": "一组专用寄存器（PC、IR、AR、DR等）"}, {"key": "B", "text": "一组通用寄存器"}, {"key": "C", "text": "指令译码器"}, {"key": "D", "text": "时序系统"}, {"key": "E", "text": "操作控制信号形成部件"}]	{"answer": ["A", "C", "D", "E"]}	[]	一组专用寄存器（PC、IR、AR、DR等）; 指令译码器; 时序系统; 操作控制信号形成部件;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/01-第7章作业-1st.txt#5	第7章作业-1st 已完成 智能分析 剩余148小时13分钟	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
15	7	\N	\N	multiple_choice	medium	控制器的功能包含：	[{"key": "A", "text": "取指令、分析指令、执行指令"}, {"key": "B", "text": "按时发送 完成指令功能所需要的所有微操作控制信号"}, {"key": "C", "text": "运算和存储数据"}, {"key": "D", "text": "处理随机发生的中断请求和特殊请求"}]	{"answer": ["A", "B", "D"]}	[]	取指令、分析指令、执行指令; 按时发送 完成指令功能所需要的所有微操作控制信号; 处理随机发生的中断请求和特殊请求;\n二. 单选题（共13题，36分）	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/01-第7章作业-1st.txt#6	第7章作业-1st 已完成 智能分析 剩余148小时13分钟	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
16	7	\N	\N	single_choice	medium	下面的总线中，（ ）是单向总线。	[{"key": "A", "text": "IB"}, {"key": "B", "text": "AB"}, {"key": "C", "text": "DB"}, {"key": "D", "text": "CB"}]	{"answer": "B"}	[]	AB;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/01-第7章作业-1st.txt#7	第7章作业-1st 已完成 智能分析 剩余148小时13分钟	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
17	7	\N	\N	single_choice	medium	存储器写信号Mem_write是属于哪组总线？	[{"key": "A", "text": "IB"}, {"key": "B", "text": "AB"}, {"key": "C", "text": "DB"}, {"key": "D", "text": "CB"}]	{"answer": "D"}	[]	CB;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/01-第7章作业-1st.txt#8	第7章作业-1st 已完成 智能分析 剩余148小时13分钟	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
18	7	\N	\N	single_choice	medium	一般地，取指令操作中用到的专用寄存器是：	[{"key": "A", "text": "PC和IR"}, {"key": "B", "text": "PC和DR"}, {"key": "C", "text": "IR和AR"}, {"key": "D", "text": "DR和AR"}]	{"answer": "A"}	[]	PC和IR;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/01-第7章作业-1st.txt#9	第7章作业-1st 已完成 智能分析 剩余148小时13分钟	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
19	7	\N	\N	single_choice	medium	指令的地址存放在CPU的哪个寄存器中？	[{"key": "A", "text": "PC"}, {"key": "B", "text": "IR"}, {"key": "C", "text": "AR"}, {"key": "D", "text": "DR"}]	{"answer": "A"}	[]	PC;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/01-第7章作业-1st.txt#10	第7章作业-1st 已完成 智能分析 剩余148小时13分钟	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
20	7	\N	\N	single_choice	medium	从主存取出的指令代码，存放在CPU的哪个寄存器中？	[{"key": "A", "text": "PC"}, {"key": "B", "text": "IR"}, {"key": "C", "text": "AR"}, {"key": "D", "text": "DR"}]	{"answer": "B"}	[]	IR;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/01-第7章作业-1st.txt#11	第7章作业-1st 已完成 智能分析 剩余148小时13分钟	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
21	7	\N	\N	single_choice	medium	对程序员可见的寄存器是：（ ）	[{"key": "A", "text": "PC和IR"}, {"key": "B", "text": "AR和DR"}, {"key": "C", "text": "通用寄存器"}, {"key": "D", "text": "MAR和MDR"}]	{"answer": "C"}	[]	通用寄存器;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/01-第7章作业-1st.txt#12	第7章作业-1st 已完成 智能分析 剩余148小时13分钟	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
22	7	\N	\N	single_choice	medium	一个指令周期含若干个：	[{"key": "A", "text": "机器周期（CPU周期）"}, {"key": "B", "text": "时钟周期"}, {"key": "C", "text": "工作脉冲"}, {"key": "D", "text": "节拍"}]	{"answer": "A"}	[]	机器周期（CPU周期）;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/01-第7章作业-1st.txt#13	第7章作业-1st 已完成 智能分析 剩余148小时13分钟	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
23	7	\N	\N	single_choice	medium	一个机器周期含若干个：	[{"key": "A", "text": "状态周期"}, {"key": "B", "text": "时钟周期"}, {"key": "C", "text": "工作脉冲"}, {"key": "D", "text": "指令周期"}]	{"answer": "B"}	[]	时钟周期;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/01-第7章作业-1st.txt#14	第7章作业-1st 已完成 智能分析 剩余148小时13分钟	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
24	7	\N	\N	single_choice	medium	在一个（ ）中，通常完成一个运算器的操作、或者存储器的操作、或者总线的传送。	[{"key": "A", "text": "机器周期"}, {"key": "B", "text": "时钟周期"}, {"key": "C", "text": "工作脉冲"}, {"key": "D", "text": "指令周期"}]	{"answer": "A"}	[]	机器周期;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/01-第7章作业-1st.txt#15	第7章作业-1st 已完成 智能分析 剩余148小时13分钟	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
25	7	\N	\N	single_choice	medium	控制器分为硬布线控制器和微程序控制器，是根据其中的哪个部件来划分的？	[{"key": "A", "text": "时序系统"}, {"key": "B", "text": "指令译码器"}, {"key": "C", "text": "寄存器组"}, {"key": "D", "text": "操作控制信号形成部件"}]	{"answer": "D"}	[]	操作控制信号形成部件;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/01-第7章作业-1st.txt#16	第7章作业-1st 已完成 智能分析 剩余148小时13分钟	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
26	7	\N	\N	single_choice	medium	单周期CPU中，所有指令的指令周期就是一个（ ）。	[{"key": "A", "text": "机器周期"}, {"key": "B", "text": "时钟周期"}, {"key": "C", "text": "工作脉冲"}, {"key": "D", "text": "指令周期"}]	{"answer": "B"}	[]	时钟周期;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/01-第7章作业-1st.txt#17	第7章作业-1st 已完成 智能分析 剩余148小时13分钟	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
27	7	\N	\N	single_choice	medium	单周期CPU的CPI：	[{"key": "A", "text": "等于1"}, {"key": "B", "text": "等于2"}, {"key": "C", "text": "大于等于1"}, {"key": "D", "text": "大于1"}]	{"answer": "A"}	[]	等于1;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/01-第7章作业-1st.txt#18	第7章作业-1st 已完成 智能分析 剩余148小时13分钟	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
28	7	\N	\N	single_choice	medium	多周期CPU的CPI：	[{"key": "A", "text": "等于1"}, {"key": "B", "text": "等于2"}, {"key": "C", "text": "大于等于1"}, {"key": "D", "text": "大于1"}]	{"answer": "D"}	[]	大于1;\n三. 填空题（共2题，28分）	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/01-第7章作业-1st.txt#19	第7章作业-1st 已完成 智能分析 剩余148小时13分钟	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
29	7	\N	\N	fill_blank	medium	设某机平均执行一条指令需要两次访问内存，平均需要三个机器周期，每个机器周期包含4个节拍周期。若机器主频为25MHz，试回答：\n（1）若访问主存不需要插入等待周期，则平均执行一条指令的时间为 ns；\n（2）若每次访问内存需要插入2个等待节拍周期，则平均执行一条指令的时间是 ns。	[]	{"blanks": [{"index": 1, "answer": "480", "acceptable_answers": []}, {"index": 2, "answer": "640", "acceptable_answers": []}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/01-第7章作业-1st.txt#20	第7章作业-1st 已完成 智能分析 剩余148小时13分钟	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
30	7	\N	\N	fill_blank	medium	设某机主频为8MHz，每个机器周期包含4个节拍周期，该机平均指令执行速度为1MIPS。试回答：\n（1）该机的平均指令周期是 ns；\n（2）平均每条指令周期包含 个机器周期。	[]	{"blanks": [{"index": 1, "answer": "1000", "acceptable_answers": []}, {"index": 2, "answer": "2\\n四. 阅读理解（共1题，18分）", "acceptable_answers": []}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/01-第7章作业-1st.txt#21	第7章作业-1st 已完成 智能分析 剩余148小时13分钟	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
31	7	\N	595	fill_blank	medium	如果使用单周期CPU实现，则其时钟周期至少为 ns；则主频5MHz (是/否)合适。	[]	{"blanks": [{"index": 1, "answer": "155", "acceptable_answers": []}, {"index": 2, "answer": "是", "acceptable_answers": ["合适"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/01-第7章作业-1st.txt#22.1	第7章作业-1st 已完成 智能分析 剩余148小时13分钟	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
35	6	\N	596	short_answer	medium	请描述这一段程序的功能。	[]	{"reference_answer": "取出内存单元0020 0100H的内容，将其高16位保留，低16位变为0555H。"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/02-第6章作业-2nd.txt#1.2	第6章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
289	8	\N	\N	multiple_choice	medium	关于RISC-V模型机中jal和jalr指令的描述，以下哪些是正确的？	[{"key": "A", "text": "jal指令保存返回地址PC+4到rd，并跳转到目标地址。"}, {"key": "B", "text": "jalr指令保存返回地址PC+4到rd，目标地址通常由rs1 + offset得到。"}, {"key": "C", "text": "jal和jalr指令都属于S型格式。"}, {"key": "D", "text": "jal和jalr指令都属于转移类指令。"}]	{"answer": ["A", "B", "D"]}	[]	A和B正确，根据知识块[05]对jal和jalr指令数据通路的描述。D正确，根据知识块[02]和[05]，jal和jalr属于转移类指令。C错误，jal属于J型格式，jalr属于I型格式，而非S型格式（S型用于store指令）。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 14:54:02.130643+00	2026-06-01 14:54:02.130643+00	f	temporary	0	0	0	0	0	0
39	6	\N	\N	fill_blank	medium	下面是一段C语言程序，宿主机是32位：\nint i, a[];\nfor(i=0;i<10;i++){\na[i]+=100;\n}\n将其翻译成汇编程序，并进行优化，请完成下面的填空：\nlui t0, 0x800 #t0保存数组a在主存的首地址，执行结果t0=0x ①\naddi t1,x0, 10 #t1相当于变量i\nL: lw t2, 0(t0)\naddi t2,t2, 100\n②\n③\naddi t1,t1,-1\n④	[]	{"blanks": [{"index": 1, "answer": "800000", "acceptable_answers": ["00800000", "800000H", "00800000H", "0x800000", "0x00800000"]}, {"index": 2, "answer": "sw t2,0(t0)", "acceptable_answers": []}, {"index": 3, "answer": "addi t0,t0,4", "acceptable_answers": []}, {"index": 4, "answer": "bne t1,x0,L", "acceptable_answers": ["bne x0,t1,L"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/02-第6章作业-2nd.txt#2	第6章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
57	6	\N	\N	single_choice	medium	某机采用16位定长指令字格式，操作码位数和寻址方式位数固定，指令系统中有48条指令，支持直接、间接、立即、相对4种寻址方式，直接寻址的单地址指令可寻址范围是 。	[{"key": "A", "text": "0~255"}, {"key": "B", "text": "0~1023"}, {"key": "C", "text": "-128~127"}, {"key": "D", "text": "-512~511"}]	{"answer": "A"}	[]	0~255;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/03-第6章作业-1st.txt#6	第6章作业-1st 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
340	2	\N	\N	fill_blank	medium	总线按功能可分为地址总线、______和控制总线。	[]	{"blanks": [{"index": 1, "answer": "数据总线", "acceptable_answers": ["DB", "数据总线"]}]}	[]	根据知识块[ch02-s003-01]和[ch02-s008-01]，总线按功能分为地址总线（AB）、数据总线（DB）和控制总线（CB），这是必须掌握的核心分类。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	1	0	0	0	0
58	6	\N	\N	single_choice	medium	某计算机采用大端模式，按字节编址。某指令中操作数的机器数为1234FF00H，该操作数采用基址寻址方式，形式地址（用补码表示）为FF12H，基址寄存器内容为F000 0000H，则该操作数的LSB（最低有效字节）所在的地址是 。	[{"key": "A", "text": "F000 FF12H"}, {"key": "B", "text": "F000 FF15H"}, {"key": "C", "text": "EFFF FF12H"}, {"key": "D", "text": "EFFF FF15H"}]	{"answer": "D"}	[]	EFFF FF15H;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/03-第6章作业-1st.txt#7	第6章作业-1st 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
104	5	\N	\N	single_choice	medium	多体交叉技术的目的是：	[{"key": "A", "text": "增加主存容量"}, {"key": "B", "text": "增加数据线宽度"}, {"key": "C", "text": "降低控制的复杂度"}, {"key": "D", "text": "提高数据传输带宽"}]	{"answer": "D"}	[]	提高数据传输带宽;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#14	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
678	9	\N	\N	true_false	medium	因为外设工作速度差异大、结构原理差异大、时序独立且异步性明显，所以外设可以直接与CPU相连进行数据交换。	[]	{"answer": "FALSE"}	[]	根据知识块[ch09-s002-01]和[ch09-s001-01]，外设的特点（速度差异大、结构差异大、时序独立、异步性）决定了其信息不能直接与CPU兼容（存在数据格式、速度、逻辑时序和信号电平差异）。因此，需要I/O接口作为适配器或桥梁，外设不能直接与CPU相连。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-02 09:14:02.631362+00	2026-06-02 09:14:02.631362+00	f	temporary	0	0	0	0	0	0
679	9	\N	\N	multiple_choice	medium	I/O接口中，用于反映外设是否就绪、是否忙或是否出错的寄存器是（ ）。	[{"key": "A", "text": "数据寄存器"}, {"key": "B", "text": "状态寄存器"}, {"key": "C", "text": "控制寄存器"}, {"key": "D", "text": "地址译码器"}]	{"answer": ["B"]}	[]	根据知识块[ch09-s003-01]，状态寄存器的作用是反映外设是否就绪、是否忙、是否出错。数据寄存器用于暂存交换数据，控制寄存器用于接收CPU的控制命令，地址译码器用于地址选择。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-02 09:14:02.631362+00	2026-06-02 09:14:02.631362+00	f	temporary	0	0	0	0	0	0
680	9	\N	\N	true_false	medium	在独立编址方式下，I/O端口和主存地址统一在一个地址空间，CPU可以使用普通的访存指令来访问I/O端口。	[]	{"answer": "FALSE"}	[]	根据知识块[ch09-s004-01]，这是对统一编址方式的描述。独立编址是指I/O端口有独立的地址空间，需要使用专门的I/O指令进行访问。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-02 09:14:02.631362+00	2026-06-02 09:14:02.631362+00	f	temporary	0	0	0	0	0	0
681	9	\N	\N	fill_blank	medium	中断处理过程包括中断请求、中断判优、中断响应、______、执行中断服务程序、恢复现场和返回。	[]	{"blanks": [{"index": 1, "answer": "保护现场", "acceptable_answers": ["保护现场"]}]}	[]	根据知识块[ch09-s005-01]和[ch09-s007-01]，中断过程包括中断请求、中断判优、中断响应、保护现场、执行中断服务程序、恢复现场和返回。填入“保护现场”符合标准流程。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-02 09:14:02.631362+00	2026-06-02 09:14:02.631362+00	f	temporary	0	0	0	0	0	0
682	9	\N	\N	multiple_choice	medium	在DMA的三种常见传送方式中，CPU和DMA控制器交替使用总线，对CPU透明的方式是（ ）。	[{"key": "A", "text": "停止CPU访存"}, {"key": "B", "text": "周期挪用"}, {"key": "C", "text": "透明DMA"}, {"key": "D", "text": "CPU轮询"}]	{"answer": ["C"]}	[]	根据知识块[ch09-s006-01]，DMA传送方式常见有停止CPU访存、周期挪用和透明DMA。其中，透明DMA是指CPU和DMA控制器交替使用总线，且对CPU透明（即不影响CPU正常工作）。停止CPU访存会暂停CPU，周期挪用会窃取CPU周期。CPU轮询是程序查询方式，不是DMA方式。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-02 09:14:02.631362+00	2026-06-02 09:14:02.631362+00	f	temporary	0	0	0	0	0	0
52	6	\N	\N	single_choice	medium	存储器类型的操作数，存放在（ ）中，指令的地址码字段是（ ）。	[{"key": "A", "text": "指令，操作数本身"}, {"key": "B", "text": "存储器，存储器的单元地址相关信息"}, {"key": "C", "text": "寄存器，寄存器编号"}, {"key": "D", "text": "指令，操作数地址信息"}]	{"answer": "B"}	[]	存储器，存储器的单元地址相关信息;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/03-第6章作业-1st.txt#1	第6章作业-1st 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
53	6	\N	\N	single_choice	medium	寄存器类型的操作数，存放在（ ）中，指令的地址码字段是（ ）。	[{"key": "A", "text": "指令，操作数本身"}, {"key": "B", "text": "存储器，存储器的单元地址相关信息"}, {"key": "C", "text": "寄存器，寄存器编号"}, {"key": "D", "text": "指令，操作数地址信息"}]	{"answer": "C"}	[]	寄存器，寄存器编号;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/03-第6章作业-1st.txt#2	第6章作业-1st 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
54	6	\N	\N	single_choice	medium	立即数类型的操作数，存放在（ ）中，指令的地址码字段是（ ）。	[{"key": "A", "text": "指令，操作数本身"}, {"key": "B", "text": "存储器，存储器的单元地址相关信息"}, {"key": "C", "text": "寄存器，寄存器编号"}, {"key": "D", "text": "指令，操作数地址信息"}]	{"answer": "A"}	[]	指令，操作数本身;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/03-第6章作业-1st.txt#3	第6章作业-1st 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
55	6	\N	\N	single_choice	medium	寻址速度最快的是（ ）类型操作数。	[{"key": "A", "text": "寄存器"}, {"key": "B", "text": "存储器"}, {"key": "C", "text": "立即数"}]	{"answer": "C"}	[]	立即数;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/03-第6章作业-1st.txt#4	第6章作业-1st 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
56	6	\N	\N	single_choice	medium	寻址速度最慢的是（ ）类型操作数。	[{"key": "A", "text": "寄存器"}, {"key": "B", "text": "存储器"}, {"key": "C", "text": "立即数"}]	{"answer": "B"}	[]	存储器;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/03-第6章作业-1st.txt#5	第6章作业-1st 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
59	6	\N	\N	single_choice	medium	按字节编址的计算机中，某double型数组A的首地址为2000H，使用变址寻址和循环结构访问数组A，保存数组下标的变址寄存器初值为0，每次循环取一个数组元素，其偏移地址为变址值乘以sizeof(double)，取完后变址寄存器内容自动加1。若某次循环所取元素的地址为2100H，则进入该次循环时变址寄存器的内容是 。	[{"key": "A", "text": "2"}, {"key": "B", "text": "32"}, {"key": "C", "text": "64"}, {"key": "D", "text": "100"}]	{"answer": "B"}	[]	32;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/03-第6章作业-1st.txt#8	第6章作业-1st 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
60	6	\N	\N	single_choice	medium	某计算机按照字节编址，指令字长固定且只有两种指令格式，其中三地址格式指令29条，二地址指令107条，每个地址字段6位，则指令字长至少 位。	[{"key": "A", "text": "24位"}, {"key": "B", "text": "26位"}, {"key": "C", "text": "28位"}, {"key": "D", "text": "32位"}]	{"answer": "A"}	[]	24位;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/03-第6章作业-1st.txt#9	第6章作业-1st 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
61	6	\N	\N	single_choice	medium	下列寻址方式中，最适合按照下标顺序访问一维数组元素的是 。	[{"key": "A", "text": "相对寻址"}, {"key": "B", "text": "寄存器寻址"}, {"key": "C", "text": "直接寻址"}, {"key": "D", "text": "变址寻址"}]	{"answer": "D"}	[]	变址寻址;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/03-第6章作业-1st.txt#10	第6章作业-1st 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
62	6	\N	\N	single_choice	medium	某指令格式含4个字段，从左到右排列为OP、M、I和D，其中M为寻址方式，I为变址寄存器编号，D为形式地址。若采用先变址后间址的寻址方式，则操作数的有效地址是 。	[{"key": "A", "text": "I+D"}, {"key": "B", "text": "(I)+D"}, {"key": "C", "text": "((I)+D)"}, {"key": "D", "text": "((I))+D"}]	{"answer": "C"}	[]	((I)+D);	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/03-第6章作业-1st.txt#11	第6章作业-1st 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
63	6	\N	\N	single_choice	medium	某计算机有16个通用寄存器，采用32位定长指令，操作码字段（含寻址方式位）为8位，Store指令的源操作数和目的操作数分别采用寄存器寻址和基址寻址方式。若基址寄存器可选择任一通用寄存器，且偏移量采用补码表示，则Store指令中偏移量的取值范围是 。	[{"key": "A", "text": "-32768~+32767"}, {"key": "B", "text": "-32767~+32768"}, {"key": "C", "text": "-65536~+65535"}, {"key": "D", "text": "-65535~+65536"}]	{"answer": "A"}	[]	-32768~+32767;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/03-第6章作业-1st.txt#12	第6章作业-1st 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
64	6	\N	\N	single_choice	medium	假设变址寄存器R的内容为1000H，指令中的形式地址为2000H，地址1000H中的内容为2000H，地址2000H中的内容为3000H，地址3000H中的内容为4000H，则变址寻址方式下访问到的操作数是 。	[{"key": "A", "text": "1000H"}, {"key": "B", "text": "2000H"}, {"key": "C", "text": "3000H"}, {"key": "D", "text": "4000H"}]	{"answer": "D"}	[]	4000H;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/03-第6章作业-1st.txt#13	第6章作业-1st 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
65	6	\N	\N	single_choice	medium	某计算机字长为16位，主存按字节编址，转移指令采用相对寻址，由两个字节组成，第一字节为操作码字段，第二字节为相对位移量字段。假定取指令时，每取一个字节，PC自动加1。若某转移指令所在主存地址为2000H，相对偏移量字段内容为06H，则该转移指令成功转移后的目标地址是 。	[{"key": "A", "text": "2006H"}, {"key": "B", "text": "2007H"}, {"key": "C", "text": "2008H"}, {"key": "D", "text": "2009H"}]	{"answer": "C"}	[]	2008H;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/03-第6章作业-1st.txt#14	第6章作业-1st 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
66	6	\N	\N	single_choice	medium	下列关于RISC的叙述中，错误的是 。	[{"key": "A", "text": "RISC普遍采用微程序控制器"}, {"key": "B", "text": "RISC中的大多数指令在一个时钟周期内完成"}, {"key": "C", "text": "RISC的内部通用寄存器数量比CISC多"}, {"key": "D", "text": "RISC的指令数、寻址方式和指令格式种类比CISC少"}]	{"answer": "A"}	[]	RISC普遍采用微程序控制器;\n二. 多选题（共1题，2分）	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/03-第6章作业-1st.txt#15	第6章作业-1st 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
67	6	\N	\N	multiple_choice	medium	下面哪种寻址方式中，操作数不是存储器类型操作数：（ ） 。	[{"key": "A", "text": "立即寻址"}, {"key": "B", "text": "直接寻址"}, {"key": "C", "text": "间接寻址"}, {"key": "D", "text": "寄存器寻址"}, {"key": "E", "text": "寄存器间接寻址"}, {"key": "F", "text": "变址寻址"}, {"key": "G", "text": "堆栈寻址"}, {"key": "H", "text": "基址寻址"}]	{"answer": ["A", "D"]}	[]	立即寻址; 寄存器寻址;\n三. 简答题（共1题，10分）	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/03-第6章作业-1st.txt#16	第6章作业-1st 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
68	6	\N	\N	short_answer	medium	某机器字长16位，采用单字长指令，每个地址码6位。试采用操作码扩展技术，设计14条二地址指令，80条一地址指令，60条零地址指令。请给出一种指令编码方案。	[]	{"reference_answer": "四. 填空题（共4题，58分）"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/03-第6章作业-1st.txt#17	第6章作业-1st 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
69	6	\N	\N	fill_blank	medium	某机指令字长24位，有128个寄存器：\n（1）假设每个操作数都是寄存器类型，则指令中一个操作数的地址码是（ 1 ）位；\n（2）假设所有指令都是三地址格式，则最多有（ 2 ）条三地址指令;\n（3）假设除了三地址指令外，还有二地址指令若干条，则最多有（ 3 ）条三地址指令，此时最多有（ 4 ）条二地址指令。	[]	{"blanks": [{"index": 1, "answer": "7", "acceptable_answers": ["7位"]}, {"index": 2, "answer": "8", "acceptable_answers": ["8条"]}, {"index": 3, "answer": "7", "acceptable_answers": ["7条"]}, {"index": 4, "answer": "128", "acceptable_answers": ["128条"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/03-第6章作业-1st.txt#18	第6章作业-1st 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
70	6	\N	\N	fill_blank	medium	某机32位指令字长，有100条指令；含16个寄存器，8种寻址方式，所有指令都是双操作数指令，每个操作数均含寄存器编号和寻址方式码两个字段，除此之外，每条指令还包含一个立即数/偏移量字段。\n（1）指令的OP字段，是 位。\n（2）指令中每个操作数占 位。\n（3）立即数/偏移量字段占 位。	[]	{"blanks": [{"index": 1, "answer": "7", "acceptable_answers": ["7位"]}, {"index": 2, "answer": "7", "acceptable_answers": ["7位"]}, {"index": 3, "answer": "11", "acceptable_answers": ["11位"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/03-第6章作业-1st.txt#19	第6章作业-1st 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
71	6	\N	\N	fill_blank	medium	若某机器指令长16位，指令中每个操作数地址码长4位，采用扩展码技术，假设指令系统有三地址指令M条，两地址指令N条，没有零地址指令。问：该指令系统最多有多少条一地址指令？(写出最简式，客观题）	[]	{"blanks": [{"index": 1, "answer": "4096-256M-16N", "acceptable_answers": ["16[ 16( 16 - M ) -N ]", "（（16-M）*16-N））*16", "16*(256-16M-N)", "4096-16N-256M", "2^12-M*2^8-N*2^4"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/03-第6章作业-1st.txt#20	第6章作业-1st 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
288	8	\N	\N	multiple_choice	medium	在RISC-V模型机中，执行条件分支指令（如beq）时，如果分支条件不满足，程序计数器（PC）的更新方式是什么？	[{"key": "A", "text": "PC = PC + 分支偏移"}, {"key": "B", "text": "PC = PC + 4"}, {"key": "C", "text": "PC = rs1 + 立即数"}, {"key": "D", "text": "PC = rd + 4"}]	{"answer": ["B"]}	[]	根据知识块[8.5]，条件分支如beq，若满足条件则PC = PC + 分支偏移；否则PC = PC + 4。选项A是满足条件时的更新方式。选项C是jalr指令计算目标地址的方式，但并非直接赋值给PC的默认方式，且题干明确问不满足时的PC更新。选项D中rd通常用于保存返回地址（如jal），而非PC更新来源。因此，分支条件不满足时，PC默认顺序执行，增加4（假设指令字长为32位）。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 14:51:59.02153+00	2026-06-01 14:51:59.02153+00	f	temporary	0	1	0	0	0	0
73	5	\N	\N	true_false	medium	Cache的容量小，价格高，速度是主存的5～10倍。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "TRUE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/05-第5章作业-2nd.txt#1	第5章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
74	5	\N	\N	true_false	medium	Cache的内容是主存部分内容的一个副本，功能全部由硬件实现。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "TRUE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/05-第5章作业-2nd.txt#2	第5章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
75	5	\N	\N	true_false	medium	Cach与主存统一编址。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "FALSE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/05-第5章作业-2nd.txt#3	第5章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
76	5	\N	\N	true_false	medium	程序访问的局部性原理是设置Cache的理论基础。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "TRUE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/05-第5章作业-2nd.txt#4	第5章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
77	5	\N	\N	true_false	medium	程序可在辅助存储器中直接运行。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "FALSE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/05-第5章作业-2nd.txt#5	第5章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
78	5	\N	\N	true_false	medium	虚拟存储器是指主存-辅存层次，其主要目的是扩大程序访问的存储空间，并能实现自动管理和调度。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "TRUE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/05-第5章作业-2nd.txt#6	第5章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
79	5	\N	\N	true_false	medium	采用虚拟存贮器技术能提高外存贮器的存取速度。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "FALSE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/05-第5章作业-2nd.txt#7	第5章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
80	5	\N	\N	true_false	medium	实现主存地址与Cache地址的映射、虚拟存储器的虚拟地址和物理地址的映射，均是完全由硬件自动完成。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "FALSE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/05-第5章作业-2nd.txt#8	第5章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
81	5	\N	\N	single_choice	medium	Cache的三种地址映像方法中，命中率最高的是（ ）。	[{"key": "A", "text": "直接映像法"}, {"key": "B", "text": "全相联映像"}, {"key": "C", "text": "组相联映像法"}]	{"answer": "B"}	[]	全相联映像;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/05-第5章作业-2nd.txt#9	第5章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
82	5	\N	\N	single_choice	medium	Cache的三种地址映像方法中，命中率最低的是（ ）。	[{"key": "A", "text": "直接映像法"}, {"key": "B", "text": "全相联映像法"}, {"key": "C", "text": "组相联映像法"}]	{"answer": "A"}	[]	直接映像法;\n三. 填空题（共4题，64分）	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/05-第5章作业-2nd.txt#10	第5章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
83	5	\N	\N	fill_blank	medium	某16位计算机，CPU地址总线24位，按字节编址，则该机所能配备的最大主存容量是（ 1 ）字节；若按字编址，则该机所能配备的最大主存容量是（ 2 ）字节。	[]	{"blanks": [{"index": 1, "answer": "16M", "acceptable_answers": ["16M字节", "16MB", "2^24", "2^24B", "16,777,216", "16777216"]}, {"index": 2, "answer": "32M", "acceptable_answers": ["32M字节", "32MB", "2^25", "2^25B", "4,294,967,296", "4294967296"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/05-第5章作业-2nd.txt#11	第5章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
84	5	\N	\N	fill_blank	medium	某机字长32位，存储器容量为 4GB，如果存储器采用按字节编址，CPU的地址总线位数为（ 1 ）位；如果存储器按字编址，则CPU的地址总线位数为（ 2 ）位。	[]	{"blanks": [{"index": 1, "answer": "32", "acceptable_answers": ["32位"]}, {"index": 2, "answer": "30", "acceptable_answers": ["30位"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/05-第5章作业-2nd.txt#12	第5章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
85	5	\N	\N	fill_blank	medium	CPU执行一段程序的过程中，命中Cache的次数为3900次，不命中直接从主存存取数据的次数为100次，已知Cache的存储周期为40ns，主存的存储周期为240ns；CPU。求：\n（1）Cache的命中率h为： %；（保留一位小数）\n（2）Cache/主存系统的平均访问时间ta为： ns ；\n（3）Cache/主存系统的效率e为： % 。（保留一位小数）	[]	{"blanks": [{"index": 1, "answer": "97.5", "acceptable_answers": ["97.5%"]}, {"index": 2, "answer": "45", "acceptable_answers": ["45ns"]}, {"index": 3, "answer": "88.9", "acceptable_answers": ["88.9%"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/05-第5章作业-2nd.txt#13	第5章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
86	5	\N	\N	fill_blank	medium	设某计算机主存容量1MB，存储器按字节编址；Cache容量64KB，每块32个字节，Cache按照4路组相联方式组织：\n1、主存地址 （1） 位；\n2、按照Cache的地址映射方式，主存地址划分成三个字段：高位标记 （2）位，Cache组地址 （3）位，块内地址 （4） 位；\n3、主存地址6234H可映射到Cache的哪一组： （5） H（十六进制表示）；\n4、设Cache初态为空，采用先进先出替换策略，若CPU依次访问主存第0，1，…，99号单元读出100个字节，并重复按此次序读10次，问命中率为 （6）%（保留2位小数）；\n5、设Cache的命中率为90%，CPU总是从Cache取得数据，如果Cache的存取时间是10ns，主存的存取时间是50ns，则Cache-主存系统的平均存取时间为 （7）ns。\n6、Cache-主存系统的效率为 （8） %（保留1位小数）。	[]	{"blanks": [{"index": 1, "answer": "20", "acceptable_answers": []}, {"index": 2, "answer": "6", "acceptable_answers": []}, {"index": 3, "answer": "9", "acceptable_answers": []}, {"index": 4, "answer": "5", "acceptable_answers": []}, {"index": 5, "answer": "111", "acceptable_answers": ["111H", "111h"]}, {"index": 6, "answer": "99.6", "acceptable_answers": ["99.60", "99.6%", "99.60%"]}, {"index": 7, "answer": "15", "acceptable_answers": []}, {"index": 8, "answer": "66.7", "acceptable_answers": ["66.7%", "66.70", "66.70%\\n四. 阅读理解（共1题，46分）"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/05-第5章作业-2nd.txt#14	第5章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
683	1	\N	\N	single_choice	medium	根据冯·诺依曼体系结构，现代计算机设计强调以什么为中心，CPU 与 I/O 设备围绕它进行信息交换？	[{"key": "A", "text": "运算器"}, {"key": "B", "text": "控制器"}, {"key": "C", "text": "存储器"}, {"key": "D", "text": "输入设备"}]	{"answer": "C"}	[]	冯·诺依曼体系结构中，硬件由运算器、存储器、控制器、输入设备、输出设备五大部件组成。现代计算机更强调以存储器为中心，程序和数据都在存储器中，CPU 与 I/O 设备围绕存储器进行信息交换。选项 A、B、D 分别是五大部件的一部分，但不是现代计算机设计强调的中心。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-02 09:54:04.90771+00	2026-06-02 09:54:04.90771+00	f	temporary	0	0	0	0	0	0
684	1	\N	\N	multiple_choice	medium	下列哪些属于系统软件？（多选）	[{"key": "A", "text": "操作系统"}, {"key": "B", "text": "语言处理程序"}, {"key": "C", "text": "数据库管理系统"}, {"key": "D", "text": "工程设计程序"}]	{"answer": ["A", "B", "C"]}	[]	根据知识块，系统软件包括操作系统、语言处理程序、数据库管理系统、网络管理软件和服务性程序。选项 A、B、C 均在其中。选项 D（工程设计程序）属于应用软件，不属于系统软件。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-02 09:54:04.90771+00	2026-06-02 09:54:04.90771+00	f	temporary	0	0	0	0	0	0
685	1	\N	\N	single_choice	medium	本课程主要讨论的计算机类型，在 Flynn 分类法中属于哪一种？	[{"key": "A", "text": "SIMD"}, {"key": "B", "text": "MISD"}, {"key": "C", "text": "MIMD"}, {"key": "D", "text": "SISD"}]	{"answer": "D"}	[]	根据知识块，Flynn 分类法根据指令流和数据流进行划分。本课程主要讨论对象包括电子数字计算机、SISD 计算机、冯·诺依曼体系结构计算机。因此，本课程主要讨论 SISD 计算机。选项 A、B、C 均不是本课程的主要讨论对象。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-02 09:54:04.90771+00	2026-06-02 09:54:04.90771+00	f	temporary	0	0	0	0	0	0
290	1	\N	\N	single_choice	easy	冯·诺依曼体系结构最核心的组织原则不包括以下哪一项？	[{"key": "A", "text": "采用二进制表示数据和指令"}, {"key": "B", "text": "采用存储程序思想，程序和数据预先存入主存"}, {"key": "C", "text": "指令必须严格按顺序执行，不能改变执行顺序"}, {"key": "D", "text": "硬件由五大部件组成：运算器、存储器、控制器、输入设备、输出设备"}]	{"answer": "C"}	[]	根据知识块[ch01-s006-01]，冯·诺依曼体系结构的第3条是“指令一般按顺序执行。遇到分支、跳转、循环等指令时，执行顺序会被改变”。因此，选项C“不能改变执行顺序”的说法是错误的。选项A、B、D均是冯·诺依曼体系结构的核心原则。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-01 14:57:21.438814+00	2026-06-01 14:57:21.438814+00	f	verified	0	0	0	0	0	0
91	5	\N	\N	single_choice	medium	关于存储器的速度指标的描述中，错误的是：	[{"key": "A", "text": "存取时间是从访问一个存储器单元开始，到访问完成所需的时间。"}, {"key": "B", "text": "存储周期是指连续2次访问存储器的最短时间间隔。"}, {"key": "C", "text": "对于某个存储器来说，存取时间一般大于存储周期。"}, {"key": "D", "text": "存储器带宽是指单位时间内，存储器访问的最大信息量。"}]	{"answer": "C"}	[]	对于某个存储器来说，存取时间一般大于存储周期。;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#1	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
92	5	\N	\N	single_choice	medium	以下各个层次的存储器，按照速度越来越快的顺序排列，正确的是：	[{"key": "A", "text": "寄存器、Cache、主存、辅存；"}, {"key": "B", "text": "辅存、主存、Cache、寄存器；"}, {"key": "C", "text": "寄存器、辅存、主存、Cache；"}, {"key": "D", "text": "辅存、Cache、主存、寄存器。"}]	{"answer": "B"}	[]	辅存、主存、Cache、寄存器；;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#2	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
93	5	\N	\N	single_choice	medium	一般情况下，主存、辅存、Cache、寄存器的容量，分别是以（ ）为数量单位。	[{"key": "A", "text": "TB、GB、MB、B"}, {"key": "B", "text": "B、MB、GB、TB"}, {"key": "C", "text": "MB、GB、KB、B"}, {"key": "D", "text": "GB、TB、MB、B"}]	{"answer": "D"}	[]	GB、TB、MB、B;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#3	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
94	5	\N	\N	single_choice	medium	若存储周期100ns，每次读出一个字节，则该存储器的数据传输率为：	[{"key": "A", "text": "32×10^6bps"}, {"key": "B", "text": "8×10^6b/s"}, {"key": "C", "text": "80MB/s"}, {"key": "D", "text": "8×10^7b/s"}]	{"answer": "D"}	[]	8×10^7b/s;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#4	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
95	5	\N	\N	single_choice	medium	SRAM用（ ）存储0、1代码，DRAM用（ ）存储0、1代码。	[{"key": "A", "text": "双稳态触发器、单稳态触发器"}, {"key": "B", "text": "单稳态触发器、双稳态触发器"}, {"key": "C", "text": "极间电容、双稳态触发器"}, {"key": "D", "text": "双稳态触发器、极间电容"}]	{"answer": "D"}	[]	双稳态触发器、极间电容;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#5	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
96	5	\N	\N	single_choice	medium	静态半导体存储器SRAM指：	[{"key": "A", "text": "在工作过程中，如果没有读写操作，存储内容保持不变"}, {"key": "B", "text": "在断电后信息仍能维持不变"}, {"key": "C", "text": "不需要再生"}, {"key": "D", "text": "芯片内部有自动刷新逻辑"}]	{"answer": "A"}	[]	在工作过程中，如果没有读写操作，存储内容保持不变;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#6	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
97	5	\N	\N	single_choice	medium	假设一个DRAM芯片的地址线有9根，则其最多有 （ ）个存储单元？	[{"key": "A", "text": "2^9"}, {"key": "B", "text": "2^18"}, {"key": "C", "text": "2^19"}, {"key": "D", "text": "不确定"}]	{"answer": "B"}	[]	2^18;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#7	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
98	5	\N	\N	single_choice	medium	哪种刷新方式，存在存储器访问的“死时间”？	[{"key": "A", "text": "集中式刷新"}, {"key": "B", "text": "分散式刷新"}, {"key": "C", "text": "异步式刷新"}]	{"answer": "A"}	[]	集中式刷新;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#8	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
99	5	\N	\N	single_choice	medium	哪种刷新方式，导致存储器刷新次数过多，效率不高？	[{"key": "A", "text": "集中式刷新"}, {"key": "B", "text": "分散式刷新"}, {"key": "C", "text": "异步式刷新"}]	{"answer": "B"}	[]	分散式刷新;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#9	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
100	5	\N	\N	single_choice	medium	关于DRAM芯片的说法，错误的是：	[{"key": "A", "text": "因为DRAM容量比较大，所以内部采用行和列双向译码方式；"}, {"key": "B", "text": "DRAM芯片的地址一般分两次接收，先送行地址，再送列地址；"}, {"key": "C", "text": "DRAM的地址引脚数量约为单元地址位数的一半；"}, {"key": "D", "text": "DRAM的刷新计数器内，存放的是列地址。"}]	{"answer": "D"}	[]	DRAM的刷新计数器内，存放的是列地址。;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#10	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
101	5	\N	\N	single_choice	medium	关于RAM，下述说法中正确的的是：	[{"key": "A", "text": "半导体RAM信息可读可写，且断电后信息仍能保持。"}, {"key": "B", "text": "DRAM是易失性的，而SRAM是非易失性的。"}, {"key": "C", "text": "DRAM和SRAM都是易失性的。"}, {"key": "D", "text": "DRAM是非易失性的，而SRAM是易失性的。"}]	{"answer": "C"}	[]	DRAM和SRAM都是易失性的。;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#11	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
102	5	\N	\N	single_choice	medium	在ROM存储器中必须有（ ）电路。	[{"key": "A", "text": "数据写入"}, {"key": "B", "text": "再生"}, {"key": "C", "text": "地址译码"}, {"key": "D", "text": "刷新"}]	{"answer": "C"}	[]	地址译码;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#12	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
103	5	\N	\N	single_choice	medium	主存贮器和CPU之间增加Cache的目的是：	[{"key": "A", "text": "扩大CPU中寄存器的数量"}, {"key": "B", "text": "扩大主存贮器容量"}, {"key": "C", "text": "提高CPU访问存储系统的速度"}, {"key": "D", "text": "提高CPU的速度"}]	{"answer": "C"}	[]	提高CPU访问存储系统的速度;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#13	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
105	5	\N	\N	single_choice	medium	相联存储器的访问方式是：	[{"key": "A", "text": "先进先出顺序访问"}, {"key": "B", "text": "按地址访问"}, {"key": "C", "text": "无地址访问"}, {"key": "D", "text": "按内容访问"}]	{"answer": "D"}	[]	按内容访问;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#15	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
106	5	\N	\N	single_choice	medium	双端口存储器能高速进行读/写的原因是：采用：	[{"key": "A", "text": "高速芯片"}, {"key": "B", "text": "两套相互独立的读写电路"}, {"key": "C", "text": "流水技术"}, {"key": "D", "text": "新型器件"}]	{"answer": "B"}	[]	两套相互独立的读写电路;\n二. 判断题（共12题，36分）	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#16	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
107	5	\N	\N	true_false	medium	主存都是易失性存储器，而辅存都是非易失性存储器。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "FALSE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#17	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
108	5	\N	\N	true_false	medium	存储系统采用层次结构的目的是：解决各种存储器的容量、速度和价格之间的矛盾。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "TRUE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#18	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
109	5	\N	\N	true_false	medium	速度快的存储器往往价格较高，容量也较小。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "TRUE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#19	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
110	5	\N	\N	true_false	medium	主存都是随机存取的存储器，辅存大多是顺序存取的存储器。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "TRUE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#20	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
111	5	\N	\N	true_false	medium	程序和数据必须从辅存装载到主存中，才能被CPU执行。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "TRUE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#21	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
112	5	\N	\N	true_false	medium	易失性存储器是指电源不掉电的情况下，数据仍会丢失的存储器。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "FALSE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#22	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
113	5	\N	\N	true_false	medium	磁盘是半顺序存取的存储器，磁带是典型的顺序存取的存储器。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "TRUE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#23	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
114	5	\N	\N	true_false	medium	SRAM不需要刷新，但需要再生；而DRAM则既需要刷新又需要再生。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "FALSE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#24	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
115	5	\N	\N	true_false	medium	在电源不掉电的情况下，SRAM信息稳定保持，而DRAM信息丢失。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "TRUE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#25	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
116	5	\N	\N	true_false	medium	在电源掉电的情况下，SRAM信息稳定保持，而DRAM信息丢失。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "FALSE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#26	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
117	5	\N	\N	true_false	medium	多体交叉存储器的每个模块都有自己的MAR和MDR。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "TRUE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#27	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
118	5	\N	\N	true_false	medium	多体交叉存储器的每个模块的体选信号是由地址总线的低位经过译码产生的，故每个模块内的单元地址是不连续的。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "TRUE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#28	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
119	5	\N	\N	fill_blank	medium	SRAM存储1位二进制，需要（ ）个MOS管，DRAM存储1位二进制，需要（ ）个MOS管。	[]	{"blanks": [{"index": 1, "answer": "6", "acceptable_answers": []}, {"index": 2, "answer": "1", "acceptable_answers": []}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#29	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
291	1	\N	\N	true_false	easy	第一台电子数字计算机ENIAC的设计思想奠定了现代计算机“二进制”和“存储程序”两大关键基础。	[]	{"answer": "FALSE"}	[]	根据知识块[ch01-s002-01]，ENIAC早期采用十进制操作，并通过布线和拨动开关控制运算。它引出了“二进制”和“存储程序”的关键思想，但并非其自身奠定了这两大基础。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-01 14:57:21.438814+00	2026-06-01 14:57:21.438814+00	f	verified	0	0	0	0	0	0
314	1	\N	\N	true_false	easy	本课程主要讨论的计算机类型是SISD计算机。	[]	{"answer": "TRUE"}	[]	根据知识块[01-s003-01]，Flynn分类法根据指令流和数据流划分计算机，而本课程主要讨论对象包括“SISD计算机”。因此该陈述正确。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-01 14:57:21.438814+00	2026-06-01 14:57:21.438814+00	f	verified	0	0	0	0	0	0
122	4	\N	\N	true_false	medium	原码加减交替除法算法，因为移位和加减的次数是确定的，所以使得运算器完成除法计算的时间变得固定、可控。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "TRUE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/07-第4章作业.txt#2	第4章作业 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
123	4	\N	\N	true_false	medium	原码加减交替除法算法中，当部分余数是负数时，执行的操作是：+除数|Y|，左移一位，-除数|Y|。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "FALSE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/07-第4章作业.txt#3	第4章作业 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
124	4	\N	\N	true_false	medium	并行除法器是按照恢复余数除法算法设计的。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "FALSE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/07-第4章作业.txt#4	第4章作业 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
125	4	\N	\N	true_false	medium	CF对无符号数有意义，而OF对带符号数有意义。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "TRUE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/07-第4章作业.txt#5	第4章作业 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
126	4	\N	\N	single_choice	medium	下面有关浮点数加减运算的叙述中，正确的是 。\nI.对阶操作不会引起阶码上溢或下溢 II.右规和尾数舍入都可能引起阶码上溢\nIII.左规时可能引起阶码下溢 IV.尾数溢出时结果不一定溢出	[{"key": "A", "text": "仅I、III"}, {"key": "B", "text": "仅I、II、IV"}, {"key": "C", "text": "仅II、III、IV"}, {"key": "D", "text": "I、II、III、IV"}]	{"answer": "D"}	[]	I、II、III、IV;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/07-第4章作业.txt#6	第4章作业 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
127	4	\N	\N	single_choice	medium	int型变量x和y的补码机器数分别是FFFF FFDFH和0000 0041H，则x、y的值以及x-y的机器数分别是 。	[{"key": "A", "text": "x=-65,y=41,x-y的机器数溢出"}, {"key": "B", "text": "x=-33,y=65,x-y机器数为FFFF FF9DH"}, {"key": "C", "text": "x=-33,y=65,x-y机器数为FFFF FF9EH"}, {"key": "D", "text": "x=-65,y=41,x-y机器数为FFFF FF96H"}]	{"answer": "C"}	[]	x=-33,y=65,x-y机器数为FFFF FF9EH;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/07-第4章作业.txt#7	第4章作业 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
128	4	\N	\N	single_choice	medium	整数x的机器数为1101 1000，分别对x进行逻辑右移1位和算术右移1位操作，得到的机器数分别是 。	[{"key": "A", "text": "1110 1100、1110 1100"}, {"key": "B", "text": "0110 1100、1110 1100"}, {"key": "C", "text": "1110 1100、0110 1100"}, {"key": "D", "text": "0110 1100、0110 1100"}]	{"answer": "B"}	[]	0110 1100、1110 1100;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/07-第4章作业.txt#8	第4章作业 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
129	4	\N	\N	single_choice	medium	某计算机字长8位，整型变量x和y的机器数为[x]补=1111 0100，[y]补=1011 0000，整型变量z=2*x+y/2，则z的机器数为 。	[{"key": "A", "text": "1100 0000"}, {"key": "B", "text": "0010 0100"}, {"key": "C", "text": "1010 1010"}, {"key": "D", "text": "溢出"}]	{"answer": "A"}	[]	1100 0000;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/07-第4章作业.txt#9	第4章作业 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
130	4	\N	\N	single_choice	medium	减法指令sub R1,R2,R3的功能为（R1）-（R2）→R3，该指令执行后将生成进位/借位标志CF和溢出标志OF。若（R1）=FFFF FFFFH，（R2）=FFFF FFF0H，则该指令执行后，CF和OF分别是 。	[{"key": "A", "text": "CF=0，OF=0"}, {"key": "B", "text": "CF=1，OF=0"}, {"key": "C", "text": "CF=0，OF=1"}, {"key": "D", "text": "CF=1，OF=1"}]	{"answer": "A"}	[]	CF=0，OF=0;\n三. 填空题（共2题，30分）	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/07-第4章作业.txt#10	第4章作业 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
131	4	\N	\N	fill_blank	medium	假设某32位宿主机上，用C语言函数实现了两个数据的比较，程序如下：\nint LessThan(int X, int Y) {\nif (X<Y) return(1);\nelse return(0);\n}\n假设调用这个函数：\nint w; int A=0x88990000; int B=0x00003344;\nw = LessThan(A,B);\n①w=（1）；假设X和Y以及A和B被定义为unsigned类型，则w=（2） 。\n②假设p=&B，p的值是100；内存按字节编址、大端模式存放多字节数据，则内存102号单元的内容是 （3） H。\n③计算机中对X>Y的比较，是通过X-Y实现的，请计算A-B的运算结果= （4） H，进位标志CF= （5） ，溢出标志OF= （6） 、结果为零标志ZF= （7） 、符号标志SF= （8） 、奇偶标志PF= （9） 。	[]	{"blanks": [{"index": 1, "answer": "1", "acceptable_answers": []}, {"index": 2, "answer": "0", "acceptable_answers": []}, {"index": 3, "answer": "33", "acceptable_answers": ["33H"]}, {"index": 4, "answer": "8898ccbc", "acceptable_answers": ["8898CCBC", "8898ccbch", "8898CCBCH"]}, {"index": 5, "answer": "0", "acceptable_answers": []}, {"index": 6, "answer": "0", "acceptable_answers": []}, {"index": 7, "answer": "0", "acceptable_answers": []}, {"index": 8, "answer": "1", "acceptable_answers": []}, {"index": 9, "answer": "1", "acceptable_answers": []}]}	[]		/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/07-第4章作业.txt#11	第4章作业 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
132	4	\N	\N	fill_blank	medium	假定在一个16位字长的嵌入式计算机中运行如下的C语言程序段：\nchar a, b;\nint x, y, m, n;\na=0x65; b=0x84;\nx=a; y=b;\nm=x - y; n= y + y;\n（1）假设编译器为变量x和y分配了16位寄存器R3和R4，则执行上述程序段后，R3 = ① H； R4 = ② H；（用十六进制表示）。\n（2）执行上述程序段后，变量m的十进制真值m= ③ ；（用十进制表示）。\n（3）执行完变量n的计算后，溢出标志OF= ④ 、进位标志CF= ⑤ 、结果为零标志ZF= ⑥ 。	[]	{"blanks": [{"index": 1, "answer": "0065", "acceptable_answers": ["0065H", "0065h", "65", "65H", "65h"]}, {"index": 2, "answer": "FF84", "acceptable_answers": ["FF84H", "ff84", "ff84h"]}, {"index": 3, "answer": "225", "acceptable_answers": []}, {"index": 4, "answer": "0", "acceptable_answers": []}, {"index": 5, "answer": "1", "acceptable_answers": []}, {"index": 6, "answer": "0\\n四. 计算题（共1题，8分）", "acceptable_answers": []}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/07-第4章作业.txt#12	第4章作业 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
133	4	\N	\N	calculation	medium	已知X和Y如下，用变形补码计算X+Y和X-Y（写出运算过程），并指出运算结果是否溢出：\n（1） X=0.11011，Y=0.11111\n（2） X=-0.1101，Y=0.0110	[]	{"reference_answer": ""}	[]	五. 阅读理解（共2题，37分）	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/07-第4章作业.txt#13	第4章作业 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
686	1	\N	\N	fill_blank	medium	冯·诺依曼体系结构最核心的两个思想是采用______表示数据和指令，以及采用______思想。	[]	{"blanks": [{"index": 1, "answer": "二进制", "acceptable_answers": ["二进制"]}, {"index": 2, "answer": "存储程序", "acceptable_answers": ["存储程序"]}]}	[]	根据知识块 [ch01-s006-01]，冯·诺依曼体系结构的核心原则包括两点：1. 采用二进制表示数据和指令；2. 采用存储程序思想，即程序和数据预先存入主存，计算机自动取指并执行。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI巩固练习	t	t	2026-06-02 09:53:59.810803+00	2026-06-02 09:53:59.810803+00	f	temporary	2	0	1	0	0	0
690	1	\N	\N	fill_blank	medium	对于典型的编译型语言（如 C 语言），从源程序（.c）生成可执行文件的主要处理步骤依次是：预处理、______、______、链接。	[]	{"blanks": [{"index": 1, "answer": "编译", "acceptable_answers": ["编译"]}, {"index": 2, "answer": "汇编", "acceptable_answers": ["汇编"]}]}	[]	根据知识块 [ch01-s007-01]，以 C 程序为例，典型编译型语言的运行过程为：高级语言源程序 → 预处理 → 编译 → 汇编 → 链接 → 可执行机器语言程序。GCC 的翻译过程 hello.c → hello.i → hello.s → hello.o → 可执行文件也印证了这一点。因此，预处理之后、链接之前的两个步骤是“编译”和“汇编”。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI巩固练习	t	t	2026-06-02 09:53:59.810803+00	2026-06-02 09:53:59.810803+00	f	temporary	2	0	1	0	0	0
688	1	\N	\N	true_false	medium	MIPS（每秒百万条指令）是衡量计算机性能的指标之一，它总是能全面反映计算机执行所有类型任务的性能。	[]	{"answer": "FALSE"}	[]	根据知识块 [ch01-s001-01]，MIPS 是用于评价性能的指标之一。但 MIPS 主要衡量指令执行速率，对不同类型指令（如浮点运算、访存操作）的执行时间差异不敏感，因此不能全面反映计算机执行所有任务（如科学计算中的浮点密集型任务）的性能。其他指标如 FLOPS、CPI 等在特定场景下更能说明问题。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI巩固练习	t	t	2026-06-02 09:53:59.810803+00	2026-06-02 09:53:59.810803+00	f	temporary	2	0	1	0	0	0
687	1	\N	\N	single_choice	medium	根据冯·诺依曼体系结构，计算机硬件系统由五大部件组成。其中，CPU 由哪两部分组成？	[{"key": "A", "text": "运算器和控制器"}, {"key": "B", "text": "运算器和存储器"}, {"key": "C", "text": "控制器和输入设备"}, {"key": "D", "text": "存储器和输出设备"}]	{"answer": "A"}	[]	根据知识块 [ch01-s004-01] 和 [ch01-s006-01]，硬件系统五大部件是运算器、存储器、控制器、输入设备、输出设备。其中，CPU（中央处理器）由运算器和控制器组成。选项B、C、D均不符合冯·诺依曼体系结构对硬件组成的标准划分。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI巩固练习	t	t	2026-06-02 09:53:59.810803+00	2026-06-02 09:53:59.810803+00	f	temporary	2	0	1	0	0	0
292	1	\N	\N	multiple_choice	easy	以下关于计算机硬件系统的描述，哪些是正确的？	[{"key": "A", "text": "CPU由运算器和控制器组成"}, {"key": "B", "text": "主机包括CPU和外存储器"}, {"key": "C", "text": "内存储器包括RAM和ROM"}, {"key": "D", "text": "外围设备包括输入设备、输出设备和外存储器"}]	{"answer": ["A", "C", "D"]}	[]	根据知识块[ch01-s004-01]，硬件系统包括主机和外围设备。主机包括CPU（运算器+控制器）和内存储器（RAM、ROM），因此A、C正确。外围设备包括外存储器、输入设备和输出设备，因此D正确。选项B错误，因为主机不包括外存储器，外存储器属于外围设备。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-01 14:57:21.438814+00	2026-06-01 14:57:21.438814+00	f	verified	0	0	0	0	0	0
293	1	\N	\N	single_choice	easy	在计算机系统中，直接运行在“裸机”上、是系统软件核心的是？	[{"key": "A", "text": "应用软件"}, {"key": "B", "text": "语言处理程序"}, {"key": "C", "text": "操作系统"}, {"key": "D", "text": "数据库管理系统"}]	{"answer": "C"}	[]	根据知识块[ch01-s005-01]，操作系统是直接运行在裸机上的最基本系统软件，是系统软件的核心。应用软件、语言处理程序和数据库管理系统都属于系统软件或应用软件，但都不是直接运行在裸机上的核心。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-01 14:57:21.438814+00	2026-06-01 14:57:21.438814+00	f	verified	0	0	0	0	0	0
144	3	\N	\N	single_choice	medium	当计算机进行浮点运算，结果超出浮点数所能表示的最大值时，被称为（ ）；计算机进行的操作是（ ）。	[{"key": "A", "text": "下溢；当做机器零处理"}, {"key": "B", "text": "上溢；当做机器零处理"}, {"key": "C", "text": "正溢出；溢出报警"}, {"key": "D", "text": "负溢出；溢出报警"}]	{"answer": "C"}	[]	正溢出；溢出报警;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/08-第3章作业-2nd.txt#1	第3章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
145	3	\N	\N	single_choice	medium	假定有4个整数用8位补码分别表示r1=FEH，r2=F2H，r3=90H，r4=F8H，若将运算结果存放在一个8位寄存器中，则下列运算会发生溢出的是（ ）。	[{"key": "A", "text": "r1×r2"}, {"key": "B", "text": "r2×r3"}, {"key": "C", "text": "r1×r4"}, {"key": "D", "text": "r2×r4"}]	{"answer": "B"}	[]	r2×r3;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/08-第3章作业-2nd.txt#2	第3章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
146	3	\N	\N	single_choice	medium	假定变量i，f，d数据类型分别为int, float, double(int用补码表示，float和double用IEEE754单精度和双精度浮点数据格式表示)，已知i=785，f=1.5678e3，d=1.5e100，若在32位机器中执行下列关系表达式，则结果为真的是( )。\n(I) i==(int)(float)i\n(II)f==(float)(int)f\n(III)f==(float)(double)f\n(IV)(d+f)-d==f	[{"key": "A", "text": "仅I和II"}, {"key": "B", "text": "仅I和III"}, {"key": "C", "text": "仅II和III"}, {"key": "D", "text": "仅III和IV"}]	{"answer": "B"}	[]	仅I和III;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/08-第3章作业-2nd.txt#3	第3章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
147	3	\N	\N	single_choice	medium	一个C语言程序程序在一台32位机器上运行。程序中定义了三个变量x,y,和z，其中x和z为int型，y为short型。当x=127，y= -9时，执行赋值语句z=x+y后，x、y和z的值分别是（ )。	[{"key": "A", "text": "x=0000007FH, y=FFF9H, z=00000076H"}, {"key": "B", "text": "x=0000007FH, y=FFF9H, z=FFFF0076H"}, {"key": "C", "text": "x=0000007FH, y=FFF7H, z=FFFF0076H"}, {"key": "D", "text": "x=0000007FH, y=FFF7H, z=00000076H"}]	{"answer": "D"}	[]	x=0000007FH, y=FFF7H, z=00000076H;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/08-第3章作业-2nd.txt#4	第3章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
148	3	\N	\N	single_choice	medium	已知内存某块存储区中存储了若干西文字符和中文字符，假设从中取出了2个字节数据，值为B1A3H，则它是（ ）。	[{"key": "A", "text": "1个中文字符"}, {"key": "B", "text": "2个西文字符"}, {"key": "C", "text": "1个西文字符和1个中文字符"}, {"key": "D", "text": "2个中文字符"}]	{"answer": "A"}	[]	1个中文字符;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/08-第3章作业-2nd.txt#5	第3章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
149	3	\N	\N	single_choice	medium	RISC-V架构按字节编址、小端模式，已知内存地址0040 0000H~0040 0003H中存放了四个字节数据，分别是：3eh，58h，06h，afh。lh指令从0040 0002H地址取出一个半字（16位）数据，则取出的数据是：	[{"key": "A", "text": "3e58h"}, {"key": "B", "text": "583eh"}, {"key": "C", "text": "06afh"}, {"key": "D", "text": "af06h"}]	{"answer": "D"}	[]	af06h;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/08-第3章作业-2nd.txt#6	第3章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
150	3	\N	\N	single_choice	medium	下面哪种校验码不是纠错码：（ ）。	[{"key": "A", "text": "奇（偶）校验码"}, {"key": "B", "text": "海明校验码"}, {"key": "C", "text": "CRC校验码"}]	{"answer": "A"}	[]	奇（偶）校验码;\n二. 多选题（共2题，6分）	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/08-第3章作业-2nd.txt#7	第3章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
151	3	\N	\N	multiple_choice	medium	假设下面的定点机器数是浮点数的尾数，请选择规格化的浮点数：	[{"key": "A", "text": "【M】原=1.100101"}, {"key": "B", "text": "【M】原=0.000101"}, {"key": "C", "text": "【M】原=0.100101"}, {"key": "D", "text": "【M】原=1.000101"}, {"key": "E", "text": "【M】补=1.100101"}, {"key": "F", "text": "【M】补=0.000101"}, {"key": "G", "text": "【M】补=0.100101"}, {"key": "H", "text": "【M】补=1.000101"}]	{"answer": ["A", "C", "G", "H"]}	[]	【M】原=1.100101; 【M】原=0.100101; 【M】补=0.100101; 【M】补=1.000101;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/08-第3章作业-2nd.txt#8	第3章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
152	3	\N	\N	multiple_choice	medium	若下面的奇偶校验码均正确，请指出哪些是偶校验码。	[{"key": "A", "text": "10110110"}, {"key": "B", "text": "01111110"}, {"key": "C", "text": "11011000"}, {"key": "D", "text": "10100001"}]	{"answer": ["B", "C"]}	[]	01111110; 11011000;\n三. 填空题（共3题，22分）	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/08-第3章作业-2nd.txt#9	第3章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
294	1	\N	\N	true_false	easy	Flynn分类法是根据计算机运行时的指令流和数据流的并行性来对计算机进行分类的。	[]	{"answer": "TRUE"}	[]	根据知识块[ch01-s003-01]，Flynn分类法根据计算机运行时的两类信息流进行划分：指令流和数据流。这里的“划分”隐含了基于指令流和数据流的并行性（SISD、SIMD等）进行分类的含义。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-01 14:57:21.438814+00	2026-06-01 14:57:21.438814+00	f	verified	0	0	0	0	0	0
595	7	\N	\N	question_group	medium	假设某计算机最复杂指令执行需要5个阶段，时间为：取指令（IF）50ns、指令译码及读寄存器（ID）20ns、执行运算（EX）15ns、访存（MEM）50ns、写回（WB）20ns。	[]	{}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/01-第7章作业-1st.txt#22	第7章作业-1st 已完成 智能分析 剩余148小时13分钟	f	t	2026-06-02 03:00:20.17898+00	2026-06-02 03:00:20.17898+00	f	\N	0	0	0	0	0	0
154	3	\N	\N	fill_blank	medium	在一个应用系统中，需要构造一个包含了100个汉字的汉字库，假设采用16×16的汉字字形，问：\n该汉字库所占存储容量是 （1） 字节；\n一篇由50个汉字构成的短文，需要占用（2）字节的存储容量来存储其纯文本。	[]	{"blanks": [{"index": 1, "answer": "3200", "acceptable_answers": ["3200字节", "3200B"]}, {"index": 2, "answer": "100", "acceptable_answers": ["100字节", "100B"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/08-第3章作业-2nd.txt#11	第3章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
155	3	\N	\N	fill_blank	medium	在一个计算机系统中，一段C语言程序如下，其中sizeof(int)和sizeof(short)分别为4和2。则写出程序执行完成后，变量i、j、k的16进制机器码和对应的十进制真值。\nint i = 65533; // i的16进制编码=（1）H；对应的十进制真值=（2）\nshort j = (short) i; // j的16进制编码=（3）H；对应的十进制真值=（4）\nint k = j; // k的16进制编码=（4）H；对应的十进制真值=（5）；	[]	{"blanks": [{"index": 1, "answer": "0000 FFFD", "acceptable_answers": ["0000 FFFDH"]}, {"index": 2, "answer": "65533", "acceptable_answers": ["+65533"]}, {"index": 3, "answer": "FFFD", "acceptable_answers": ["FFFDH", "0FFFD", "0 FFFDH"]}, {"index": 4, "answer": "-3", "acceptable_answers": []}, {"index": 5, "answer": "FFFF FFFD", "acceptable_answers": ["FFFF FFFDH", "0FFFF FFFD", "0FFFF FFFDH"]}, {"index": 6, "answer": "-3\\n四. 计算题（共3题，38分）", "acceptable_answers": []}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/08-第3章作业-2nd.txt#12	第3章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
156	3	\N	\N	calculation	medium	设某浮点数格式为：字长12位，阶码6位，用移码表示，尾数6位，用原码表示，阶码在前，尾数（包括数符）在后，则按照该格式：\n（1） 已知X=-25/64，Y=2.875，求数据X、Y的规格化的浮点数形式。\n（2） 已知Z的浮点数以十六进制表示为9F4H，则求Z的十进制真值。	[]	{"reference_answer": "（1） 已知X=-25/64，Y=2.875，求数据X、Y的规格化的浮点数形式。\\n（20分）\\n参考答案： X=－0.011001 X=－0.11001×2－1 EX=－00001 MX=－0.11001\\n[EX]移=0，11111 [MX]原=1.11001 所以[X]浮=0,11111 1.11001\\nY=10.111 Y=0.10111×210 EY=00010 MY=0.10111\\n[EY]移=1，00010 [MY]原=0.10111 所以[Y]浮=1,00010 0.10111\\n（2） 已知Z的浮点数以十六进制表示为9F4H，则求Z的十进制真值。\\n（6分）\\n参考答案：[Z]浮=1,00111 1.10100 [EZ]移=1，00111 [MY]原=1.10100\\nEZ=00111 MZ=－0.10100\\nZ=－0.10100×2+7 Z=－1010000 Z＝－80"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/08-第3章作业-2nd.txt#13	第3章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
157	3	\N	\N	calculation	medium	将十进制数＋36．75转换为IEEE754 单精度浮点数格式。	[]	{"reference_answer": "（＋36．75）10＝（100100．11）2＝（1．0010011）2×2＋5\\n＝（－1）0×（1．0010011）2×2132－127\\n所以：Ms＝0，E＝（127+5）10＝（132）10＝（10000100）2，M＝001 0011 0000 0000 0000 0000 ；单精度浮点数表示形式为0 10000100 001 0011 0000 0000 0000 0000B＝42130000H"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/08-第3章作业-2nd.txt#14	第3章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
158	3	\N	\N	calculation	medium	求IEEE754 单精度浮点数 43990000H 对应的十进制真值。	[]	{"reference_answer": "43990000H＝0100 0011 1001 1001 0000 0000 0000 0000B\\nMs＝0；E＝1000 0111B＝135D；M＝1. 001 1001 0000 0000 0000 0000\\nN＝（－1）0×1. 001 1001 0000 0000 0000 0000×2135－127\\n＝1. 001 1001×28＝100110010B＝306\\n五. 阅读理解（共1题，10分）"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/08-第3章作业-2nd.txt#15	第3章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
689	1	\N	\N	single_choice	medium	在计算机软件系统中，处于系统软件核心地位，直接运行在裸机上并管理软硬件资源的是什么？	[{"key": "A", "text": "语言处理程序"}, {"key": "B", "text": "数据库管理系统"}, {"key": "C", "text": "操作系统"}, {"key": "D", "text": "应用软件"}]	{"answer": "C"}	[]	根据知识块 [ch01-s005-01]，软件系统分为系统软件和应用软件。系统软件中，操作系统是直接运行在裸机上的最基本系统软件，是系统软件的核心，负责管理计算机软硬件资源。语言处理程序、数据库管理系统等都是系统软件的一部分，但并非核心和最底层。应用软件不是系统软件。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI巩固练习	t	t	2026-06-02 09:53:59.810803+00	2026-06-02 09:53:59.810803+00	f	temporary	2	0	1	0	0	0
691	1	\N	\N	single_choice	medium	根据冯·诺依曼体系结构，以下哪项是其核心思想之一？	[{"key": "A", "text": "程序和数据在逻辑上分离存储"}, {"key": "B", "text": "采用十进制表示和处理数据"}, {"key": "C", "text": "程序和数据预先存入主存，计算机自动取指执行"}, {"key": "D", "text": "指令必须严格按照物理顺序执行，不可改变"}]	{"answer": "C"}	[]	冯·诺依曼体系结构的核心思想包括存储程序，即程序和数据预先存入主存，CPU按照指令序列自动执行。选项A错误，因为冯·诺依曼结构将程序和数据存储在同一存储器中，并未强调逻辑分离。选项B错误，因为现代计算机采用二进制。选项D错误，因为指令一般按顺序执行，但遇到分支、跳转等指令时执行顺序可以改变。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI新题练习	t	t	2026-06-02 10:14:18.039435+00	2026-06-02 10:14:18.039435+00	f	temporary	0	1	0	0	0	0
692	1	\N	\N	multiple_choice	medium	在计算机系统层次结构中，操作系统层属于系统软件，其主要功能包括哪些？	[{"key": "A", "text": "直接控制物理电路层"}, {"key": "B", "text": "管理计算机软硬件资源"}, {"key": "C", "text": "为用户和计算机之间提供接口"}, {"key": "D", "text": "将高级语言直接翻译成机器语言"}, {"key": "E", "text": "提高资源利用率"}]	{"answer": ["B", "C", "E"]}	[]	根据知识块，操作系统是直接运行在裸机上的最基本系统软件，它管理计算机软硬件资源，提高资源利用率，并为用户和计算机之间提供接口。选项A错误，操作系统通过硬件抽象层间接控制硬件，而非直接控制物理电路。选项D错误，将高级语言翻译成机器语言是语言处理程序（如编译器）的功能。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI新题练习	t	t	2026-06-02 10:14:18.039435+00	2026-06-02 10:14:18.039435+00	f	temporary	0	1	0	0	0	0
696	1	\N	\N	single_choice	medium	根据冯·诺依曼体系结构的基本原理，以下关于计算机工作方式的描述，哪一项是正确的？	[{"key": "A", "text": "指令和数据以十进制形式存储在存储器中。"}, {"key": "B", "text": "计算机工作时，由控制器按地址从存储器中顺序取出指令并执行，除非遇到跳转指令。"}, {"key": "C", "text": "输入设备和输出设备直接与CPU交换数据，不经过存储器。"}, {"key": "D", "text": "运算器是计算机系统的中心，负责协调所有部件的工作。"}]	{"answer": "B"}	[]	冯·诺依曼体系结构的核心思想包括：1. 采用二进制（A错）；2. 存储程序，指令和数据预先存入存储器，CPU按指令序列自动执行（B对）；3. 现代计算机以存储器为中心，I/O设备通过存储器与CPU交换信息（C错）；4. 硬件由五大部件组成，存储器是中心，而非运算器（D错）。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI新题练习	t	t	2026-06-02 10:20:44.24814+00	2026-06-02 10:20:44.24814+00	f	temporary	0	1	0	0	0	0
697	1	\N	\N	true_false	medium	根据Flynn分类法，本课程主要讨论的SISD计算机是指单指令流、单数据流的计算机体系结构。	[]	{"answer": "TRUE"}	[]	Flynn分类法根据指令流和数据流对计算机进行分类。SISD（Single Instruction stream, Single Data stream）代表单指令流、单数据流，这是传统顺序执行计算机的模型。知识块明确指出“本课程主要讨论对象：电子数字计算机、SISD计算机、冯·诺依曼体系结构计算机”，因此该描述正确。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI新题练习	t	t	2026-06-02 10:20:44.24814+00	2026-06-02 10:20:44.24814+00	f	temporary	0	1	0	0	0	0
295	1	\N	\N	fill_blank	medium	冯·诺依曼体系结构的核心思想是采用______和______。其中，______是指程序和数据预先存入主存，计算机工作时自动从存储器取指令并执行。	[]	{"blanks": [{"index": 1, "answer": "二进制", "acceptable_answers": ["采用二进制"]}, {"index": 2, "answer": "存储程序", "acceptable_answers": ["存储程序思想"]}, {"index": 3, "answer": "存储程序", "acceptable_answers": ["存储程序思想", "存储程序原则"]}]}	[]	根据知识块[ch01-s002-01]和[ch01-s006-01]，冯·诺依曼体系结构的核心思想包括：1. 采用二进制表示数据和指令；2. 采用存储程序思想，即程序和数据预先存入主存，计算机按指令序列自动执行。题目中的描述直接对应了这两个核心点。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-01 14:57:21.438814+00	2026-06-01 14:57:21.438814+00	f	verified	0	1	0	0	0	0
176	3	\N	\N	fill_blank	medium	写出下列各机器数的二进制真值：X=？（请直接写出二进制真值，负数带-，正数不带+；小数正常带小数点，整数不带“，”，例如：-0010；0010；0.0010；-0.0010）\n（1）[X]补=0.1001\n（2）[X]补=1.1001\n（3）[X]原=0.1101\n（4）[X]原=1.1101\n（5）[X]反=0.1011\n（6）[X]反=1.1011\n（7）[X]移=0,1001\n（8）[X]移=1,1001\n（9）[X]补=1,0000000\n（10）[X]反=1,0000000\n（11）[X]原=1,0000000\n（12）[X]移=1,0000000	[]	{"blanks": [{"index": 1, "answer": "0.1001", "acceptable_answers": []}, {"index": 2, "answer": "-0.0111", "acceptable_answers": []}, {"index": 3, "answer": "0.1101", "acceptable_answers": []}, {"index": 4, "answer": "-0.1101", "acceptable_answers": []}, {"index": 5, "answer": "0.1011", "acceptable_answers": []}, {"index": 6, "answer": "-0.0100", "acceptable_answers": []}, {"index": 7, "answer": "-0111", "acceptable_answers": []}, {"index": 8, "answer": "1001", "acceptable_answers": []}, {"index": 9, "answer": "-10000000", "acceptable_answers": []}, {"index": 10, "answer": "-1111111", "acceptable_answers": ["-01111111"]}, {"index": 11, "answer": "-0000000", "acceptable_answers": ["-0"]}, {"index": 12, "answer": "0000000", "acceptable_answers": ["0"]}]}	[]		/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/09-第3章作业-1st.txt#3	第3章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
177	3	\N	\N	fill_blank	medium	（-282．75）10=（ ）2=（ ）8=（ ）16	[]	{"blanks": [{"index": 1, "answer": "-100011010.11", "acceptable_answers": []}, {"index": 2, "answer": "-432.6", "acceptable_answers": []}, {"index": 3, "answer": "-11A.C", "acceptable_answers": ["-11a.c"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/09-第3章作业-1st.txt#4	第3章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
179	1	\N	\N	single_choice	medium	下面关于冯·诺依曼体系结构计算机基本思想中的叙述中，错误的是：	[{"key": "A", "text": "程序的功能都通过中央处理器执行指令实现"}, {"key": "B", "text": "指令和数据都用二进制表示，形式上无差别"}, {"key": "C", "text": "指令按地址访问，数据都在指令中直接给出"}, {"key": "D", "text": "程序执行前，指令和数据需预先存放在存储器中"}]	{"answer": "C"}	[]	指令按地址访问，数据都在指令中直接给出;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/10-第1章作业.txt#1	第1章作业 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
180	1	\N	\N	single_choice	medium	冯·诺依曼体系结构计算机中，采用二进制表示指令和数据，其主要原因是：\nI.二进制运算规则简单 II.制造两个稳定的物理器件较为容易\nIII.便于逻辑门电路实现算术运算	[{"key": "A", "text": "仅I、II"}, {"key": "B", "text": "仅I、III"}, {"key": "C", "text": "仅II、III"}, {"key": "D", "text": "I、II、III"}]	{"answer": "D"}	[]	I、II、III;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/10-第1章作业.txt#2	第1章作业 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
181	1	\N	\N	single_choice	medium	计算机A和B具有相同的指令集体系架构（ISA），主频分别是1.5GHz和1.2GHz，在A和B上运行某基准程序P，平均CPI分别为2和1，则程序P在A和B上运行时间的比值是：	[{"key": "A", "text": "0.4"}, {"key": "B", "text": "0.625"}, {"key": "C", "text": "1.6"}, {"key": "D", "text": "2.5"}]	{"answer": "C"}	[]	1.6;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/10-第1章作业.txt#3	第1章作业 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
182	1	\N	\N	single_choice	medium	将高级语言源程序转换为机器目标代码文件的程序称为：	[{"key": "A", "text": "汇编程序"}, {"key": "B", "text": "链接程序"}, {"key": "C", "text": "编译程序"}, {"key": "D", "text": "解释程序"}]	{"answer": "C"}	[]	编译程序;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/10-第1章作业.txt#4	第1章作业 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
183	1	\N	\N	single_choice	medium	计算机硬件能够直接执行的是：\nI.机器语言程序 II.汇编语言程序 III.硬件描述语言程序	[{"key": "A", "text": "仅I"}, {"key": "B", "text": "仅I、II"}, {"key": "C", "text": "仅I、III"}, {"key": "D", "text": "I、II、III"}]	{"answer": "A"}	[]	仅I;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/10-第1章作业.txt#5	第1章作业 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
184	1	\N	\N	single_choice	medium	程序P在机器M上的执行时间是20秒，编译优化后，P执行的指令条数减少到原来的70%，而CPI增加到原来的1.2倍，则P在M上的执行时间是：	[{"key": "A", "text": "8.4秒"}, {"key": "B", "text": "11.7秒"}, {"key": "C", "text": "14.0秒"}, {"key": "D", "text": "16.8秒"}]	{"answer": "D"}	[]	16.8秒;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/10-第1章作业.txt#6	第1章作业 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
185	1	\N	\N	single_choice	medium	某计算机主频为1.2GHz，其指令分为A、B、C、D共4类，它们在基准程序中所占比例分别为50%、20%、10%及20%；对应CPI分别为2、3、4、5。该机的MIPS数是：	[{"key": "A", "text": "100"}, {"key": "B", "text": "200"}, {"key": "C", "text": "400"}, {"key": "D", "text": "600"}]	{"answer": "C"}	[]	400;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/10-第1章作业.txt#7	第1章作业 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
186	1	\N	\N	single_choice	medium	假定基准程序A在某计算机上的运行时间为100秒，其中90秒为CPU时间，其余为I/O时间。若CPU速度提高50%，I/O速度不变，则运行基准程序A所耗费的时间是：	[{"key": "A", "text": "55秒"}, {"key": "B", "text": "60秒"}, {"key": "C", "text": "65秒"}, {"key": "D", "text": "70秒"}]	{"answer": "D"}	[]	70秒;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/10-第1章作业.txt#8	第1章作业 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
187	1	\N	\N	single_choice	medium	下列选项中，描述浮点数操作速度指标的是：	[{"key": "A", "text": "MIPS"}, {"key": "B", "text": "CPI"}, {"key": "C", "text": "IPC"}, {"key": "D", "text": "MFLOPS"}]	{"answer": "D"}	[]	MFLOPS;	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/10-第1章作业.txt#9	第1章作业 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
188	1	\N	\N	single_choice	medium	下列选项中，能缩短程序执行时间的措施是：\nI.提高CPU时钟频率 II.优化数据通路结构 III.对程序进行编译优化	[{"key": "A", "text": "仅I和II"}, {"key": "B", "text": "仅I、III"}, {"key": "C", "text": "仅II、III"}, {"key": "D", "text": "I、II、III"}]	{"answer": "D"}	[]	I、II、III;\n二. 判断题（共5题，10分）	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/10-第1章作业.txt#10	第1章作业 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
189	1	\N	\N	true_false	medium	计算机系统由控制器、运算器、存储器、输入设备和输出设备5大部件组成。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "FALSE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/10-第1章作业.txt#11	第1章作业 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
190	1	\N	\N	true_false	medium	现代计算机绝大多数属于冯·诺依曼体系结构计算机，以运算器为中心进行数据处理与交换。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "FALSE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/10-第1章作业.txt#12	第1章作业 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
191	1	\N	\N	true_false	medium	现代计算机之所以能自动高速地运行，是因为采用了存储程序和程序控制的方式。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "TRUE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/10-第1章作业.txt#13	第1章作业 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
192	1	\N	\N	true_false	medium	机器字长是指存储器中一个存储单元的位数。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "FALSE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/10-第1章作业.txt#14	第1章作业 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
193	1	\N	\N	true_false	medium	编译程序将高级语言源程序全部翻译成机器语言程序后执行，而解释程序则每翻译一条语句，执行一条语句。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "TRUE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/10-第1章作业.txt#15	第1章作业 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
693	1	\N	\N	single_choice	medium	以C语言程序为例，在GCC典型的翻译过程中，将汇编语言翻译成机器语言目标文件的步骤是？	[{"key": "A", "text": "预处理"}, {"key": "B", "text": "编译"}, {"key": "C", "text": "汇编"}, {"key": "D", "text": "链接"}]	{"answer": "C"}	[]	根据知识块，GCC的翻译过程为：预处理（生成.i文件）、编译（将高级语言翻译成汇编语言，生成.s文件）、汇编（将汇编语言翻译成机器语言目标文件，生成.o文件）、链接（将目标文件和库函数组合成可执行程序）。因此，将汇编语言翻译成机器语言目标文件的步骤是汇编。选项A预处理是处理宏定义等；选项B编译是生成汇编语言；选项D链接是生成可执行程序。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI新题练习	t	t	2026-06-02 10:14:18.039435+00	2026-06-02 10:14:18.039435+00	f	temporary	0	1	0	0	0	0
694	1	\N	\N	single_choice	medium	Flynn分类法根据指令流和数据流对计算机进行分类。本课程主要讨论的SISD计算机属于以下哪一类？	[{"key": "A", "text": "单指令流单数据流"}, {"key": "B", "text": "单指令流多数据流"}, {"key": "C", "text": "多指令流单数据流"}, {"key": "D", "text": "多指令流多数据流"}]	{"answer": "A"}	[]	根据知识块，Flynn分类法将计算机分为SISD、SIMD、MISD、MIMD。SISD代表单指令流单数据流，是传统冯·诺依曼体系结构计算机的典型模型，也是本课程的主要讨论对象。选项B、C、D分别代表其他类型，不符合题意。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI新题练习	t	t	2026-06-02 10:14:18.039435+00	2026-06-02 10:14:18.039435+00	f	temporary	0	1	0	0	0	0
695	1	\N	\N	multiple_choice	medium	在计算机系统层次结构中，层次划分的主要作用是什么？	[{"key": "A", "text": "隐藏底层复杂细节，简化上层模型"}, {"key": "B", "text": "强制所有层次使用相同编程语言"}, {"key": "C", "text": "提供不同层次之间的连接界面"}, {"key": "D", "text": "确保硬件层不需要任何软件支持"}, {"key": "E", "text": "使得应用软件可以直接操作物理电路"}]	{"answer": ["A", "C"]}	[]	根据知识块，计算机系统分层的作用是隐藏底层复杂细节，让上层只面对更简单的模型（即抽象），同时通过界面连接不同层次。选项A和C正确。选项B错误，层次划分不要求使用相同编程语言。选项D错误，硬件层需要软件（如操作系统）支持。选项E错误，应用软件通过操作系统等中间层与硬件交互，不能直接操作物理电路。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI新题练习	t	t	2026-06-02 10:14:18.039435+00	2026-06-02 10:14:18.039435+00	f	temporary	0	1	0	0	0	0
698	1	\N	\N	calculation	medium	假设某程序在一台计算机上运行，共包含100,000条指令。已知该计算机的主频为1 GHz（10^9 Hz），程序的平均CPI（每条指令的平均时钟周期数）为2.5。请计算：\n（1）该程序的总执行时间（以秒为单位）。\n（2）该计算机的MIPS值（百万条指令每秒）。	[]	{"reference_answer": "（1）总时钟周期数 = CPI × 指令条数 = 2.5 × 100,000 = 250,000 个周期。\\n    时钟周期时间 = 1 / 主频 = 1 / (10^9 Hz) = 10^-9 秒/周期。\\n    总执行时间 = 总时钟周期数 × 时钟周期时间 = 250,000 × 10^-9 秒 = 2.5 × 10^-4 秒 = 0.00025 秒。\\n（2）MIPS = (指令条数 / 执行时间) / 10^6 = (100,000 / 0.00025) / 10^6 = (4 × 10^8) / 10^6 = 400 MIPS。"}	["正确列出总时钟周期数的计算公式（CPI × 指令数）并计算正确。", "正确列出时钟周期时间的计算公式（1/主频）并计算正确。", "正确计算总执行时间（周期数 × 周期时间）。", "正确列出MIPS的计算公式（(指令数/执行时间)/10^6）并计算正确。"]	本题检验对计算机性能指标CPI、主频和MIPS的理解与计算能力。总执行时间取决于总时钟周期数和每个时钟周期的时间。MIPS是衡量指令执行速度的常用指标，其定义是每秒执行的百万条指令数。计算过程需严格使用知识块中提到的性能指标定义。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI新题练习	t	t	2026-06-02 10:20:44.24814+00	2026-06-02 10:20:44.24814+00	f	temporary	0	1	0	0	0	0
312	1	\N	\N	true_false	easy	操作系统是直接运行在裸机上的最基本系统软件，是系统软件的核心。	[]	{"answer": "TRUE"}	[]	根据知识块[01-s005-01]，操作系统是直接运行在裸机上的最基本系统软件，是系统软件的核心。该陈述与知识块内容一致。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-01 14:57:21.438814+00	2026-06-01 14:57:21.438814+00	f	verified	0	1	0	0	0	0
301	1	\N	\N	multiple_choice	medium	下列哪些是评价计算机性能的常用指标？	[{"key": "A", "text": "CPI（每条指令周期数）"}, {"key": "B", "text": "MIPS（每秒百万条指令）"}, {"key": "C", "text": "FLOPS（每秒浮点运算次数）"}, {"key": "D", "text": "存储容量"}, {"key": "E", "text": "指令流和数据流的数量"}]	{"answer": ["A", "B", "C", "D"]}	[]	根据知识块，计算机性能指标包括机器字长、存储容量、CPI、MIPS、FLOPS等。因此A、B、C、D都是正确的性能指标。E选项“指令流和数据流的数量”是Flynn分类法的依据，用于计算机分类，而非直接的性能评价指标。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-01 14:57:21.438814+00	2026-06-01 14:57:21.438814+00	f	verified	0	1	0	0	0	0
296	1	\N	\N	short_answer	medium	请简述计算机系统层次结构中“抽象”这一概念的作用。	[]	{"reference_answer": "抽象的作用是隐藏底层复杂细节，让上层只面对更简单的模型。例如，操作系统层抽象了硬件细节，为应用软件提供了统一的接口。"}	["答出“隐藏底层复杂细节”。", "答出“让上层面对更简单的模型”。", "能举出至少一个层次间抽象的具体例子（如操作系统对硬件的抽象）。"]	根据知识块[ch01-s008-01]，计算机系统分层结构的核心关键词是“抽象”和“界面”，其作用明确为“隐藏底层复杂细节，让上层只面对更简单的模型”。答案需包含这一核心含义，并鼓励结合实例说明。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-01 14:57:21.438814+00	2026-06-01 14:57:21.438814+00	f	verified	0	0	0	0	0	0
153	3	\N	\N	fill_blank	medium	计算机中，中文有以下几种编码：\nA. 汉字输入码 B. 汉字内码 C. 汉字字形码\n请填写ABC。\n（1）对某个汉字而言，编码唯一的是 ；\n（2）汉字字库中存放的是 ；\n（3）汉字输入法中，输入的是 ；\n（4）文本文件中保存的是 。	[]	{"blanks": [{"index": 1, "answer": "B", "acceptable_answers": ["b"]}, {"index": 2, "answer": "C", "acceptable_answers": ["c"]}, {"index": 3, "answer": "A", "acceptable_answers": ["a"]}, {"index": 4, "answer": "B", "acceptable_answers": ["b"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/08-第3章作业-2nd.txt#10	第3章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
202	1	\N	\N	fill_blank	medium	假设一个嵌入式CPU主频500MHz，每秒钟能执行1亿条指令，则该CPU的运算速度是 （1） MIPS，CPI= （2） 。	[]	{"blanks": [{"index": 1, "answer": "100", "acceptable_answers": ["100MIPS"]}, {"index": 2, "answer": "5", "acceptable_answers": []}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/10-第1章作业.txt#20	第1章作业 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
315	2	\N	\N	single_choice	easy	在总线分类中，用于传送CPU的读写命令、中断请求等控制信号的总线类型是？	[{"key": "A", "text": "地址总线(AB)"}, {"key": "B", "text": "数据总线(DB)"}, {"key": "C", "text": "控制总线(CB)"}, {"key": "D", "text": "片内总线"}]	{"answer": "C"}	[]	根据知识块[ch02-s003-01]和[ch02-s008-01]，总线按功能分为地址总线(AB)、数据总线(DB)和控制总线(CB)。控制总线专门用于传送读写、中断、总线请求/响应等控制信号。地址总线用于传送地址信息，数据总线用于传送数据，片内总线是按位置和层次分类的，与信号功能无关。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
72	6	\N	\N	fill_blank	medium	设某8位计算机指令格式如下：\n指令助记符\n功能\nOP\nMOV1 DR,DATA\nDATA→DR\n0000\nMOV2 [Addr],SR\n（SR）→Addr\n0001\nMOV3 DR，SR\n（SR）→DR\n0010\nADD1 DR，SR\n（SR）+（DR）→DR\n0011\nADD2 DR,[SR]\n((SR))+（DR） →DR\n0100\nADD3 DR,[[Addr]]\n(DR)＋((Addr))→DR\n1000\nSUB DR, [SI+A]\n(DR)－((SI)+Addr)→DR\n1001\nJMP DISP\n(PC)＋DISP→PC\n1100\n……\n……\n……\nHALT\n停机\n1111\n其中， SR为源寄存器号， DR为目的寄存器号，指令第二字为地址、数据或偏移量；HALT、MOV3、ADD1、ADD2指令为单字指令外，其他指令均为双字指令。\n内存地址的部分单元内容如下：\n单元地址\n内容\n单元地址\n内容\n单元地址\n内容\n10H\n80H\n20H\n01H\n24H\n91H\n11H\n90H\n21H\n23H\n25H\n01H\n12H\n10H\n22H\n81H\n26H\nF0H\n13H\n11H\n23H\n12H\n27H\n20H\n①若（PC）＝20H，变址寄存器（SI）＝10H，则此时启动程序执行，写出前三条指令的助记符、寻址方式、EA、操作数和执行结果填入下表。\n助记符只写3字母或者4字母符号；其他请以 16进制书写，譬如**H 。\n指令序号\n指令助记符\n源操作数寻址方式\n源操作数\n运行结果\n1\n（1）\n（2）\n（3）\n（R1）=（4）\n2\n（5）\n（6）\n（7）\n（R1）=（8）\n3\n（9）\n（10）\n（11）\n（R1）=（12）\n②写出下列程序的指令码填入下表；假设放在内存00H的地方开始。\nMOV R0,#0\nMOV R1,#80H\nMOV R2,#1\nL: ADD R0,[R1]\nADD R1,R2\nJMP L\n内存地址\n十六进制代码\n00H\n（13）\n01H\n（14）\n02H\n（15）\n03H\n（16）\n04H\n（17）\n05H\n（18）\n06H\n（19）\n07H\n（20）\n08H\n（21）\n09H\n（22）	[]	{"blanks": [{"index": 1, "answer": "MOV1", "acceptable_answers": ["mov1", "MOV1 R1,23H"]}, {"index": 2, "answer": "立即数", "acceptable_answers": ["立即数寻址", "立即寻址", "立即"]}, {"index": 3, "answer": "23H", "acceptable_answers": ["23h"]}, {"index": 4, "answer": "23H", "acceptable_answers": ["23h"]}, {"index": 5, "answer": "ADD3", "acceptable_answers": ["add3", "ADD3 R1,[[12H]]"]}, {"index": 6, "answer": "间接寻址", "acceptable_answers": ["间接", "存储器间接寻址", "存储器间接"]}, {"index": 7, "answer": "80H", "acceptable_answers": ["80h", "Mem[Mem[12H]]=80H"]}, {"index": 8, "answer": "A3H", "acceptable_answers": ["a3h"]}, {"index": 9, "answer": "SUB", "acceptable_answers": ["sub", "SUB R1,[SI+01H]", "SUB R1,[SI+1H]"]}, {"index": 10, "answer": "变址寻址", "acceptable_answers": ["变址"]}, {"index": 11, "answer": "90H", "acceptable_answers": ["90h", "Mem[SI+1H]=Mem[11H]=90H"]}, {"index": 12, "answer": "13H", "acceptable_answers": ["13h"]}, {"index": 13, "answer": "0", "acceptable_answers": ["00H", "00h"]}, {"index": 14, "answer": "0", "acceptable_answers": ["00H", "00h"]}, {"index": 15, "answer": "01H", "acceptable_answers": ["01h"]}, {"index": 16, "answer": "80H", "acceptable_answers": ["80h"]}, {"index": 17, "answer": "02H", "acceptable_answers": ["02h"]}, {"index": 18, "answer": "01H", "acceptable_answers": ["01h"]}, {"index": 19, "answer": "44H", "acceptable_answers": ["44h"]}, {"index": 20, "answer": "39H", "acceptable_answers": ["39h"]}, {"index": 21, "answer": "C0H", "acceptable_answers": ["c0h"]}, {"index": 22, "answer": "FCH", "acceptable_answers": ["fch"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/03-第6章作业-1st.txt#21	第6章作业-1st 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
120	5	\N	\N	fill_blank	medium	以下ROM中，必须使用紫外线擦除的是（ 1 ）；支持单字节改写的是（ 2 ）；只能改写一次的是（ 3 ）；能在线改写且可以做大容量辅存的是（ 4 ）。\n请直接填写ABCDE。\nA. MROM B. PROM C. EPROM D. EEPROM E. Flash Memory	[]	{"blanks": [{"index": 1, "answer": "C", "acceptable_answers": ["c"]}, {"index": 2, "answer": "D", "acceptable_answers": ["d"]}, {"index": 3, "answer": "B", "acceptable_answers": ["b"]}, {"index": 4, "answer": "E", "acceptable_answers": ["e"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/06-第5章作业-1st.txt#30	第5章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
297	1	\N	\N	short_answer	medium	在计算机软件系统中，操作系统处于什么地位？它主要完成哪些核心功能？	[]	{"reference_answer": "操作系统是直接运行在裸机上的最基本系统软件，是系统软件的核心。它的主要功能是管理计算机软硬件资源，提高资源利用率，并为用户和计算机之间提供接口。"}	["答出操作系统是“最基本系统软件”和“系统软件的核心”。", "答出核心功能包括“管理软硬件资源”。", "答出核心功能包括“为用户和计算机之间提供接口”。", "答出“提高资源利用率”。"]	根据知识块[ch01-s005-01]，软件系统的结构图中明确指出“操作系统是直接运行在裸机上的最基本系统软件，是系统软件的核心”，并描述了其主要功能。答案需直接来源于此知识块的描述。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-01 14:57:21.438814+00	2026-06-01 14:57:21.438814+00	f	verified	0	0	0	0	0	0
178	3	\N	\N	fill_blank	medium	设某机器数字长16位，请选择下列各机器数的表示范围（直接填写字母）：\n（1） 无符号整数：（ ）\n（2） 原码表示的定点整数：（ ）\n（3） 原码表示的定点小数：（ ）\n（4） 补码表示的定点整数：（ ）\n（5） 补码表示的定点小数：（ ）\n（6） 移码表示的定点整数：（ ）\nA. 0～216－1 B. 0～215－1 C. －（216－1）～216－1\nD.－（215－1）～215－1 E.－216～216－1 F.－215～215－1\nG.－215～215 H.－1～1－2-15 I. －1～1－2-16\nJ. －(1－2-16)~1－2-16 K.－（1－2-15）～1－2-15 L. －1～1	[]	{"blanks": [{"index": 1, "answer": "A", "acceptable_answers": []}, {"index": 2, "answer": "D", "acceptable_answers": []}, {"index": 3, "answer": "K", "acceptable_answers": []}, {"index": 4, "answer": "F", "acceptable_answers": []}, {"index": 5, "answer": "H", "acceptable_answers": []}, {"index": 6, "answer": "F", "acceptable_answers": []}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/09-第3章作业-1st.txt#5	第3章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:52:55.579312+00	f	\N	0	0	0	0	0	0
365	3	\N	\N	true_false	easy	一个8位补码整数，其能表示的最大正数是255。	[]	{"answer": "FALSE"}	[]	根据知识块[ch03-s004-01]，n位补码整数的表示范围通常为 -2^(n-1) 到 2^(n-1)-1。对于8位补码，最大正数是2^(8-1)-1 = 127，而不是255。255是无符号8位整数的最大值。	ai:model-draft;chunks=ch03-s001-01,ch03-s002-01,ch03-s003-01,ch03-s004-01,ch03-s005-01,ch03-s006-01,ch03-s007-01,ch03-s008-01	AI题目生成	t	t	2026-06-01 15:03:21.100805+00	2026-06-01 15:03:21.100805+00	f	verified	0	0	0	0	0	0
298	1	\N	\N	fill_blank	medium	以C语言为例，一个典型的编译型语言源程序（如hello.c）经过预处理、______、______、链接等阶段后，最终生成可执行的机器语言程序。在GCC中，预处理后的文件后缀通常为______。	[]	{"blanks": [{"index": 1, "answer": "编译", "acceptable_answers": []}, {"index": 2, "answer": "汇编", "acceptable_answers": []}, {"index": 3, "answer": ".i", "acceptable_answers": ["i"]}]}	[]	根据知识块[ch01-s007-01]，C语言等编译型语言的运行过程包括预处理、编译、汇编、链接等阶段。GCC的典型翻译过程明确列出为：hello.c → hello.i → hello.s → hello.o → 可执行文件。因此，预处理后的文件后缀是.i。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-01 14:57:21.438814+00	2026-06-01 14:57:21.438814+00	f	verified	0	0	0	0	0	0
299	1	\N	\N	calculation	medium	根据Flynn分类法，计算机依据指令流和数据流的多倍性被分为四类。本课程主要讨论的冯·诺依曼体系结构计算机属于哪一类？请写出其类别名称及英文缩写。	[]	{"reference_answer": "单指令流单数据流，SISD。"}	["答出“单指令流单数据流”。", "答出英文缩写“SISD”。"]	根据知识块[ch01-s003-01]，Flynn分类法根据指令流和数据流划分计算机。并明确指出“本课程主要讨论对象：电子数字计算机、SISD计算机、冯·诺依曼体系结构计算机”，因此冯·诺依曼体系结构计算机属于SISD（单指令流单数据流）类别。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-01 14:57:21.438814+00	2026-06-01 14:57:21.438814+00	f	verified	0	0	0	0	0	0
300	1	\N	\N	single_choice	medium	根据冯·诺依曼体系结构的核心思想，以下哪一项是其基本组织原则？	[{"key": "A", "text": "采用十进制表示数据和指令"}, {"key": "B", "text": "程序和数据分开存放在不同的存储器中"}, {"key": "C", "text": "指令按顺序执行，且硬件由五大部件组成"}, {"key": "D", "text": "计算机工作时，控制器通过布线直接控制运算器"}]	{"answer": "C"}	[]	冯·诺依曼体系结构的核心原则包括：采用二进制表示数据和指令（排除A），程序和数据预先存入同一主存（排除B），指令一般按顺序执行（遇分支等会改变），硬件由运算器、存储器、控制器、输入设备、输出设备五大部件组成。C选项准确概括了这些要点。D选项描述的是早期计算机如ENIAC的控制方式，不符合冯·诺依曼的存储程序思想。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-01 14:57:21.438814+00	2026-06-01 14:57:21.438814+00	f	verified	0	0	0	0	0	0
302	1	\N	\N	true_false	medium	在计算机系统层次结构中，越往下越接近用户任务，越往上越接近硬件细节。	[]	{"answer": "FALSE"}	[]	根据知识块，计算机系统层次结构是：应用软件层在最上，物理电路层在最下。因此，越往上越接近用户任务，越往下越接近硬件细节。题目中的描述正好相反。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-01 14:57:21.438814+00	2026-06-01 14:57:21.438814+00	f	verified	0	0	0	0	0	0
303	1	\N	\N	single_choice	medium	以下关于软件系统的描述，哪一项是正确的？	[{"key": "A", "text": "应用软件是直接运行在裸机上的最基本系统软件"}, {"key": "B", "text": "操作系统是系统软件的核心，负责管理计算机软硬件资源"}, {"key": "C", "text": "语言处理程序不属于系统软件"}, {"key": "D", "text": "软件系统仅包括应用软件"}]	{"answer": "B"}	[]	根据知识块，软件系统分为系统软件和应用软件。操作系统是直接运行在裸机上的最基本系统软件，是系统软件的核心，负责管理计算机软硬件资源，提高资源利用率，并提供用户接口。因此B正确。A错误，因为应用软件不是系统软件；C错误，语言处理程序属于系统软件；D错误，软件系统包括系统软件和应用软件。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-01 14:57:21.438814+00	2026-06-01 14:57:21.438814+00	f	verified	0	0	0	0	0	0
304	1	\N	\N	single_choice	medium	对于典型的编译型语言（如C语言），将高级语言源程序转换为可执行机器语言程序的正确顺序是？	[{"key": "A", "text": "源程序 → 预处理 → 汇编 → 编译 → 链接 → 可执行程序"}, {"key": "B", "text": "源程序 → 编译 → 预处理 → 汇编 → 链接 → 可执行程序"}, {"key": "C", "text": "源程序 → 预处理 → 编译 → 汇编 → 链接 → 可执行程序"}, {"key": "D", "text": "源程序 → 汇编 → 预处理 → 编译 → 链接 → 可执行程序"}]	{"answer": "C"}	[]	根据知识块，以C程序为例，典型的翻译过程是：预处理（处理include、宏定义等）→ 编译（高级语言翻译成汇编语言）→ 汇编（汇编语言翻译成机器语言目标文件）→ 链接（目标文件和库函数组合成可执行程序）。因此正确顺序是C选项。A、B、D的顺序均不符合此流程。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-01 14:57:21.438814+00	2026-06-01 14:57:21.438814+00	f	verified	0	0	0	0	0	0
305	1	\N	\N	fill_blank	hard	冯·诺依曼体系结构的核心思想之一是______，即程序和数据预先存入存储器，计算机工作时自动从存储器中取指令并执行。	[]	{"blanks": [{"index": 1, "answer": "存储程序", "acceptable_answers": ["存储程序思想", "存储程序原理"]}]}	[]	根据知识块[ch01-s006-01]，冯·诺依曼体系结构的核心思想包括采用存储程序思想，即程序和数据预先存入主存，计算机工作时自动从存储器取指令并执行。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-01 14:57:21.438814+00	2026-06-01 14:57:21.438814+00	f	verified	0	0	0	0	0	0
306	1	\N	\N	short_answer	hard	在评价计算机性能时，CPI、MIPS和FLOPS分别衡量什么？请简要解释它们的含义。	[]	{"reference_answer": "CPI（Cycles Per Instruction）表示执行一条指令平均需要的时钟周期数。MIPS（Million Instructions Per Second）表示每秒执行百万条指令数，是一个单位时间内执行指令数量的指标。FLOPS（Floating-Point Operations Per Second）表示每秒执行的浮点操作次数，常用于衡量科学计算性能。"}	["正确解释CPI是执行一条指令平均需要的时钟周期数", "正确解释MIPS是每秒执行百万条指令数", "正确解释FLOPS是每秒执行的浮点操作次数"]	根据知识块[ch01-s001-01]，计算机性能指标包括CPI、MIPS、FLOPS等。CPI衡量指令执行效率，MIPS衡量整数指令处理速度，FLOPS衡量浮点运算能力。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-01 14:57:21.438814+00	2026-06-01 14:57:21.438814+00	f	verified	0	0	0	0	0	0
307	1	\N	\N	short_answer	hard	Flynn分类法依据哪两种信息流对计算机进行分类？本课程主要讨论的SISD计算机属于其中哪一类？	[]	{"reference_answer": "Flynn分类法依据指令流和数据流进行分类。SISD（Single Instruction stream, Single Data stream）计算机属于单指令流单数据流计算机。"}	["正确指出分类依据是指令流和数据流", "正确指出SISD是单指令流单数据流计算机"]	根据知识块[ch01-s003-01]，Flynn分类法根据指令流和数据流划分。本课程主要讨论SISD计算机，即单指令流单数据流计算机。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-01 14:57:21.438814+00	2026-06-01 14:57:21.438814+00	f	verified	0	0	0	0	0	0
308	1	\N	\N	calculation	hard	假设某程序在一台计算机上运行，其总指令数为1.0×10^9条，平均CPI为2.5，计算机主频为2.0 GHz。请计算：(1) 执行该程序需要的总时钟周期数；(2) 程序的实际执行时间（以秒为单位，保留两位小数）。	[]	{"reference_answer": "(1) 总时钟周期数 = 指令数 × CPI = 1.0×10^9 × 2.5 = 2.5×10^9 个周期。\\n(2) 主频为2.0 GHz，即时钟周期 T = 1 / (2.0×10^9) 秒。执行时间 = 总时钟周期数 × 时钟周期 = 2.5×10^9 × (1 / 2.0×10^9) = 1.25 秒。"}	["正确应用公式：总时钟周期数 = 指令数 × CPI", "正确计算总时钟周期数为 2.5×10^9", "正确应用公式：执行时间 = 总时钟周期数 / 主频", "正确计算执行时间为 1.25 秒"]	根据知识块[ch01-s001-01]，CPI是执行一条指令平均需要的时钟周期数。总时钟周期数 = 指令数 × CPI。执行时间 = 总时钟周期数 × 时钟周期 = 总时钟周期数 / 主频。主频为2.0 GHz = 2.0×10^9 Hz。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-01 14:57:21.438814+00	2026-06-01 14:57:21.438814+00	f	verified	0	0	0	0	0	0
309	1	\N	\N	fill_blank	hard	以C语言为例，使用GCC编译器进行编译时，源文件hello.c经过预处理、编译、汇编、链接后生成可执行文件。请依次写出预处理后、编译后、汇编后、链接后的文件扩展名（按顺序，用逗号分隔）。	[]	{"blanks": [{"index": 1, "answer": ".i, .s, .o, （无特定扩展名或不填）", "acceptable_answers": [".i, .s, .o, (可执行文件)", ".i, .s, .o, 可执行文件", ".i, .s, .o, (无)"]}]}	[]	根据知识块[ch01-s007-01]，GCC的典型翻译过程为：hello.c → hello.i → hello.s → hello.o → 可执行文件。预处理后文件扩展名为.i，编译后为.s，汇编后为.o，链接后生成的可执行文件通常没有特定扩展名（在Linux下可能没有扩展名）。题目要求按顺序写出，因此答案应为.i, .s, .o, （可执行文件）。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-01 14:57:21.438814+00	2026-06-01 14:57:21.438814+00	f	verified	0	0	0	0	0	0
310	1	\N	\N	single_choice	easy	冯·诺依曼体系结构的核心思想之一是（ ）。	[{"key": "A", "text": "采用二进制表示数据和指令"}, {"key": "B", "text": "采用十进制表示数据和指令"}, {"key": "C", "text": "程序和数据分开存储"}, {"key": "D", "text": "指令和数据只能通过布线和拨动开关输入"}]	{"answer": "A"}	[]	根据知识块[01-s006-01]，冯·诺依曼体系结构的核心思想包括“采用二进制表示数据和指令”。选项B错误，因为现代计算机采用二进制；选项C错误，因为冯·诺依曼思想是程序和数据一起存入主存；选项D描述的是早期ENIAC的控制方式，不是冯·诺依曼思想。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-01 14:57:21.438814+00	2026-06-01 14:57:21.438814+00	f	verified	0	0	0	0	0	0
311	1	\N	\N	multiple_choice	easy	冯·诺依曼体系结构中，计算机硬件系统由以下哪些部件组成？（ ）	[{"key": "A", "text": "运算器"}, {"key": "B", "text": "控制器"}, {"key": "C", "text": "存储器"}, {"key": "D", "text": "输入设备"}, {"key": "E", "text": "输出设备"}]	{"answer": ["A", "B", "C", "D", "E"]}	[]	根据知识块[01-s006-01]和[01-s004-01]，冯·诺依曼体系结构的硬件由五大部件组成：运算器、存储器、控制器、输入设备、输出设备。因此所有选项都是正确的。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-01 14:57:21.438814+00	2026-06-01 14:57:21.438814+00	f	verified	0	0	0	0	0	0
313	1	\N	\N	single_choice	easy	在典型的编译型语言（如C语言）运行过程中，将汇编语言翻译成机器语言目标文件的是（ ）。	[{"key": "A", "text": "预处理"}, {"key": "B", "text": "编译"}, {"key": "C", "text": "汇编"}, {"key": "D", "text": "链接"}]	{"answer": "C"}	[]	根据知识块[01-s007-01]，编译型语言的运行过程是：预处理、编译、汇编、链接。其中，汇编步骤是把汇编语言翻译成机器语言目标文件。选项A预处理处理宏定义等；选项B编译是将高级语言翻译成汇编语言；选项D链接是将目标文件和库函数组合成可执行程序。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-01 14:57:21.438814+00	2026-06-01 14:57:21.438814+00	f	verified	0	0	0	0	0	0
317	2	\N	\N	true_false	easy	计算总线带宽时，公式为：总线带宽 = 总线宽度(bit) × 总线频率 × 每周期传送次数。	[]	{"answer": "FALSE"}	[]	根据知识块[ch02-s005-01]和[ch02-s008-01]，正确的总线带宽计算公式是：总线带宽 = 总线宽度(bit)/8 × 总线频率 × 每周期传送次数。题目中的公式缺少了除以8（将bit转换为Byte）的关键步骤，因此是错误的。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
319	2	\N	\N	single_choice	easy	总线标准的核心作用是什么？	[{"key": "A", "text": "提高总线的电气性能"}, {"key": "B", "text": "规定信号、电气、机械、协议和时序，使不同厂商设备可以互联"}, {"key": "C", "text": "增加总线的宽度以提高带宽"}, {"key": "D", "text": "简化总线控制的判优逻辑"}]	{"answer": "B"}	[]	根据知识块[ch02-s007-01]，总线标准的核心定义是“规定信号、电气、机械、协议和时序，使不同厂商设备可以互联”。选项A、C、D虽然可能与总线设计或性能相关，但都不是总线标准的核心定义和直接目的。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
321	2	\N	\N	short_answer	medium	集中式总线判优主要有哪三种方式？请简要说明链式查询方式的特点。	[]	{"reference_answer": "三种方式为：链式查询、计数器定时查询、独立请求方式。链式查询方式的特点是：各设备共用一根总线请求线，总线同意信号像链条一样串行连接到各设备。优先级固定，离总线仲裁器越近的设备优先级越高。结构简单，但对电路故障敏感，且优先级固定不灵活。"}	["正确列出三种方式（2分）", "简要说明链式查询方式的特点（如连接方式、优先级确定方式、优缺点）（3分）"]	本题考察对集中式判优基本方式的掌握以及对链式查询方式原理的理解。答案需包含三种方式的名称和链式查询方式的核心特点，这些内容在知识块中均有明确提及。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
322	2	\N	\N	short_answer	medium	从功能和位置层次两个角度，分别对总线进行分类。	[]	{"reference_answer": "按功能分类：地址总线（AB）、数据总线（DB）、控制总线（CB）。按位置和层次分类：片内总线、系统总线、通信总线等。"}	["按功能分类正确（2分）", "按位置和层次分类正确（3分）"]	本题直接考察知识块中关于总线分类的两个重要维度。答案必须严格依据知识块中给出的分类名称，不应自行添加或修改。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
324	2	\N	\N	short_answer	medium	请简述同步通信和异步通信在时序协调上的主要区别。	[]	{"reference_answer": "同步通信依靠系统统一的公共时钟信号来协调通信双方，所有操作都在固定的时钟节拍下进行。异步通信没有统一的时钟，依靠请求/应答（握手）信号进行联络，通过“就绪-应答”机制协调数据传输。"}	["指出同步通信依赖统一时钟（2分）", "指出异步通信依赖请求/应答握手（2分）", "表述清晰（1分）"]	本题考察对两种主要通信定时方式核心差异的理解。知识块中明确说明“同步通信靠统一时钟，异步通信靠请求/应答握手”，答案需基于此进行对比阐述。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
325	2	\N	\N	multiple_choice	medium	根据总线的功能分类，以下哪些属于总线的主要组成部分？	[{"key": "A", "text": "地址总线"}, {"key": "B", "text": "时钟总线"}, {"key": "C", "text": "数据总线"}, {"key": "D", "text": "控制总线"}]	{"answer": ["A", "C", "D"]}	[]	根据知识块，总线按功能可分为地址总线（AB）、数据总线（DB）和控制总线（CB）。地址总线用于寻址，数据总线传送数据，控制总线传送控制信号。选项B“时钟总线”在给定的分类中未作为独立的总线功能类别提及，总线时钟是时序特性的一部分，但并非按功能划分的主要总线类型。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
327	2	\N	\N	true_false	medium	总线带宽的计算公式为：总线带宽 = 总线宽度(bit) / 8 × 总线频率 × 每周期传送次数。该公式中，总线宽度通常是指一次并行传送的字节数。	[]	{"answer": "FALSE"}	[]	根据知识块，总线带宽的公式是：总线带宽 = 总线宽度(bit) / 8 × 总线频率 × 每周期传送次数。公式中明确指出总线宽度的单位是比特（bit），而总线宽度的定义是“一次并行传送的二进制位数”。因此，题干中“总线宽度通常是指一次并行传送的字节数”的说法是错误的，它混淆了位（bit）和字节（Byte）。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
328	2	\N	\N	short_answer	medium	请简述单总线结构的主要优点和缺点。	[]	{"reference_answer": "优点：结构简单、成本低。缺点：所有部件（CPU、存储器、I/O设备）共享一条总线，当多个部件需要通信时会产生冲突，容易形成瓶颈，影响系统性能。"}	["答出“结构简单、成本低”得1分。", "答出“所有部件共享一条通路”得1分。", "答出“容易形成瓶颈或影响性能”得1分。"]	根据知识块关于总线系统结构的描述，单总线结构被明确指出“简单、成本低”，但“所有部件共享一条通路，容易形成瓶颈”。答案需涵盖这两方面的核心点。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
329	2	\N	\N	single_choice	medium	总线通信中，依靠统一的公共时钟信号来协调数据传送双方动作的方式称为：	[{"key": "A", "text": "异步通信"}, {"key": "B", "text": "同步通信"}, {"key": "C", "text": "半同步通信"}, {"key": "D", "text": "链式查询通信"}]	{"answer": "B"}	[]	根据知识块关于通信定时的定义，同步通信靠统一时钟。异步通信靠请求/应答握手。半同步通信是同步与异步的结合。链式查询是总线判优方式，而非通信定时方式。因此，描述符合同步通信的定义。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
330	2	\N	\N	fill_blank	hard	总线带宽的计算公式为：总线带宽 = ________ × 总线频率 × 每周期传送次数。	[]	{"blanks": [{"index": 1, "answer": "总线宽度(bit)/8", "acceptable_answers": ["总线宽度(bit)/8", "总线宽度(bit) / 8"]}]}	[]	根据总线带宽的典型估算公式，总线带宽 = 总线宽度(bit)/8 × 总线频率 × 每周期传送次数。其中，总线宽度(bit)/8 将位宽转换为字节数，是计算带宽的基础。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
331	2	\N	\N	short_answer	hard	在集中式总线判优的三种常见方式中，若需要优先级固定且易于扩展，通常采用哪种方式？请说明其工作原理及主要优缺点。	[]	{"reference_answer": "通常采用链式查询方式。其工作原理是：总线授权信号（BG）串行地从一个设备传递到下一个设备，离仲裁器最近的设备优先级最高。如果设备有总线请求，则截获授权信号，获得总线使用权，并停止传递授权信号。主要优点是：结构简单，优先级固定（离仲裁器近的优先级高），易于扩展设备。主要缺点是：对硬件电路的故障敏感，优先级固定不灵活，离仲裁器远的设备可能长时间无法获得总线。"}	["正确指出链式查询方式。", "描述其工作原理（BG信号串行传递，近优先）。", "列出至少一个主要优点和缺点。"]	链式查询是集中式判优中优先级固定且易于扩展的典型方式。其核心是授权信号串行传递，优先级由物理位置决定。优点在于结构简单和可扩展性，缺点在于可靠性和公平性问题。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
339	2	\N	\N	single_choice	easy	计算总线带宽时，以下公式正确的是？	[{"key": "A", "text": "总线带宽 = 总线宽度(bit) × 总线频率"}, {"key": "B", "text": "总线带宽 = 总线宽度(bit) / 8 × 总线频率 × 每周期传送次数"}, {"key": "C", "text": "总线带宽 = 总线宽度(byte) × 总线频率"}, {"key": "D", "text": "总线带宽 = 总线频率 / 总线宽度(bit)"}]	{"answer": "B"}	[]	根据知识块中给出的总线带宽典型估算公式，总线带宽 = 总线宽度(bit) / 8 × 总线频率 × 每周期传送次数。选项A、C、D均不符合该公式。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
332	2	\N	\N	short_answer	hard	同步通信和异步通信在时序控制上有何本质区别？请从时钟依赖性、适用场景和潜在问题三个方面进行对比。	[]	{"reference_answer": "本质区别在于时钟依赖性：同步通信依赖全局统一的时钟信号来协调所有操作；异步通信不依赖全局时钟，使用请求/应答（握手）信号来协调。适用场景：同步通信适合速度固定、距离较短的模块间通信，时序简单，传输速率高；异步通信适合速度差异较大或距离可能变化的模块间通信，灵活性高。潜在问题：同步通信中时钟偏移（skew）和时钟抖动（jitter）会影响高频传输的可靠性；异步通信中握手信号延迟可能降低总线利用率，控制逻辑更复杂。"}	["指出时钟依赖性的区别（统一时钟 vs. 握手信号）。", "说明适用场景的典型差异。", "指出各自潜在的主要问题。"]	同步与异步是总线通信的两种基本定时方式。核心区别在于协调机制：同步靠共享时钟，异步靠握手信号。这直接导致了它们在适用场景和固有优缺点上的不同。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
333	2	\N	\N	calculation	hard	某系统总线宽度为64位，总线频率为800MHz。若采用突发传输模式，一次突发传输包含4个时钟周期，其中1个周期用于地址和命令，3个周期用于数据传输。请计算该总线在突发传输模式下的最大数据传输率（带宽）。	[]	{"reference_answer": "计算步骤如下：\\n1. 计算单周期数据传输量：总线宽度 = 64位 = 8字节（64/8）。\\n2. 计算突发传输中每周期的有效数据传送次数：虽然突发传输共4个周期，但只有3个周期用于数据传输，因此每周期有效传送次数为 3次/4周期 = 0.75次/周期。\\n3. 代入总线带宽公式：总线带宽 = (总线宽度(bit)/8) × 总线频率 × 每周期传送次数 = 8字节 × 800×10^6次/秒 × 0.75次/周期 = 8 × 800×10^6 × 0.75 字节/秒。\\n4. 计算结果：8 × 800×10^6 × 0.75 = 4800×10^6 字节/秒 = 4.8 GB/s。\\n因此，最大数据传输率为4.8 GB/s。"}	["正确计算总线宽度为8字节。", "正确理解突发传输模式并计算出每周期有效传送次数（0.75次）。", "正确应用公式并计算出最终结果（4.8 GB/s）。"]	本题考察对总线带宽公式的灵活应用。关键在于理解“每周期传送次数”在突发传输模式下的含义：它不是简单地看总线频率，而是要看在完整的突发传输周期中，用于有效数据传输的周期占比。本例中，4个总线周期中有3个用于数据传输，因此每周期平均有效传送次数为3/4=0.75次。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
334	2	\N	\N	short_answer	hard	现代计算机系统常采用多总线结构（如CPU-内存总线、I/O总线等）而非单总线结构。请从系统性能的角度，解释这种结构如何缓解单总线的瓶颈问题。	[]	{"reference_answer": "单总线结构中，CPU、内存和所有I/O设备共享同一条总线，当CPU与内存高速交换数据时，I/O设备的访问必须等待，反之亦然，形成带宽争用，成为系统性能瓶颈。多总线结构通过分层和分离总线缓解此问题：1. 设置独立的CPU-内存高速总线，使CPU与内存之间的数据交换不受I/O干扰，保证了核心部件的高速通信。2. 将I/O设备连接到独立的I/O总线上，并通过桥接器或控制器与CPU-内存总线相连。这样，I/O总线上的数据传输可以与CPU-内存总线上的操作并行进行（当不访问同一资源时），提高了系统整体的并发性和I/O吞吐能力。3. 不同速度的设备可以连接在不同层次的总线上，便于扩展和优化性能。"}	["指出单总线的瓶颈是带宽争用。", "解释多总线如何分离高速（CPU-内存）和低速（I/O）通路。", "说明这种分离如何提高并发性或减少争用。"]	多总线结构的核心思想是“分层”与“并行”。通过将高速、高频访问的CPU-内存通信与相对低速、突发性强的I/O通信在物理通路上分离，减少了总线争用，使得不同性质的数据传输可以并行操作，从而有效缓解了单总线结构下的性能瓶颈。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
336	2	\N	\N	multiple_choice	easy	总线按功能分类，通常包括以下哪些类型？	[{"key": "A", "text": "地址总线"}, {"key": "B", "text": "数据总线"}, {"key": "C", "text": "控制总线"}, {"key": "D", "text": "通信总线"}]	{"answer": ["A", "B", "C"]}	[]	根据知识块，总线按功能可分为地址总线AB、数据总线DB、控制总线CB。选项D“通信总线”是按位置和层次分类的一种（如片内总线、系统总线、通信总线），不属于按功能分类。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
337	2	\N	\N	true_false	easy	单总线结构因其所有部件共享一条通路，容易形成性能瓶颈。	[]	{"answer": "TRUE"}	[]	根据知识块关于总线系统结构的描述，单总线结构简单、成本低，但所有部件共享一条通路，容易形成瓶颈。因此该陈述正确。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
341	2	\N	\N	short_answer	medium	请列举三种集中式总线判优方式。	[]	{"reference_answer": "链式查询方式、计数器定时查询方式、独立请求方式。"}	["答出链式查询", "答出计数器定时查询", "答出独立请求方式"]	根据知识块[ch02-s006-01]和[ch02-s008-01]，集中式判优的三种常见方式是链式查询、计数器定时查询和独立请求。这是本章总线控制部分的核心知识点。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
342	2	\N	\N	calculation	medium	某系统总线宽度为64位，总线频率为100MHz，每个总线周期传送1次数据。请计算该总线的带宽（单位：MB/s）。	[]	{"reference_answer": "总线带宽 = (64 / 8) × 100,000,000 × 1 = 8 × 100,000,000 = 800,000,000 B/s = 800 MB/s (或 762.94 MiB/s，但通常按1MB=1000KB计算)。"}	["正确写出公式：总线带宽 = 总线宽度(bit)/8 × 总线频率 × 每周期传送次数", "正确代入数值进行计算", "得出正确结果并注明单位"]	根据知识块[ch02-s005-01]和[ch02-s008-01]，总线带宽的计算公式为：总线带宽 = 总线宽度(bit)/8 × 总线频率 × 每周期传送次数。代入本题数据：(64/8) × 100MHz × 1 = 8B × 100,000,000次/s = 800,000,000 B/s。1MB = 1000KB = 1,000,000 B，故结果为800 MB/s。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
343	2	\N	\N	fill_blank	medium	总线特性包括电气特性、机械特性、功能特性和______。	[]	{"blanks": [{"index": 1, "answer": "时间特性", "acceptable_answers": ["时间特性"]}]}	[]	根据知识块[ch02-s002-01]和[ch02-s008-01]，总线特性明确分为电气、机械、功能和时间四种，这是理解总线作为通信通道的基础。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
344	2	\N	\N	short_answer	medium	与单总线结构相比，多总线结构的主要优点是什么？	[]	{"reference_answer": "多总线结构的主要优点是提高了系统并发性和扩展性。它将高速通路（如CPU-存储器总线）与低速I/O通路分开，减少了总线冲突和瓶颈，使不同部件能更高效地并行工作。"}	["指出提高并发性", "指出提高扩展性", "解释分开通路可减少瓶颈"]	根据知识块[ch02-s004-01]，单总线结构简单但所有部件共享一条通路，容易形成瓶颈。多总线结构通过将不同层次或用途的总线分离，可以提高并发操作的能力和系统可扩展性，这是其核心优势。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
345	2	\N	\N	single_choice	medium	在总线分类中，地址总线、数据总线和控制总线是根据什么进行划分的？	[{"key": "A", "text": "按传送方式"}, {"key": "B", "text": "按位置和层次"}, {"key": "C", "text": "按功能"}, {"key": "D", "text": "按电气特性"}]	{"answer": "C"}	[]	根据知识块[ch02-s003-01]，总线按功能可分为地址总线AB、数据总线DB、控制总线CB。选项A（按传送方式）是并行总线与串行总线的划分依据；选项B（按位置和层次）是片内总线、系统总线等的划分依据；选项D（按电气特性）是总线四类特性之一，但不是这三类总线的划分依据。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
346	2	\N	\N	multiple_choice	medium	下列哪些属于集中式总线判优的方式？	[{"key": "A", "text": "链式查询"}, {"key": "B", "text": "计数器定时查询"}, {"key": "C", "text": "独立请求"}, {"key": "D", "text": "分布式判优"}]	{"answer": ["A", "B", "C"]}	[]	根据知识块[ch02-s006-01]和[ch02-s008-01]，集中式判优常见有链式查询、计数器定时查询、独立请求方式。选项D“分布式判优”是另一种判优方式，与集中式并列，不属于集中式判优。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
347	2	\N	\N	true_false	medium	总线带宽的计算公式是：总线带宽 = 总线宽度(bit) × 总线频率。	[]	{"answer": "FALSE"}	[]	根据知识块[ch02-s005-01]和[ch02-s008-01]，总线带宽的典型估算公式是：总线带宽 = 总线宽度(bit) / 8 × 总线频率 × 每周期传送次数。题目中的公式缺少了“/ 8”和“每周期传送次数”这两个关键要素，因此是错误的。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
348	2	\N	\N	single_choice	medium	关于单总线结构，以下描述正确的是？	[{"key": "A", "text": "结构复杂，成本高"}, {"key": "B", "text": "所有部件共享一条通路，容易形成瓶颈"}, {"key": "C", "text": "具有很高的并发性和扩展性"}, {"key": "D", "text": "通常通过桥接器连接不同层次总线"}]	{"answer": "B"}	[]	根据知识块[ch02-s004-01]，单总线结构的特点是“简单、成本低，但所有部件共享一条通路，容易形成瓶颈”。选项A描述了其反面；选项C是多总线结构的优点；选项D描述的是现代多总线系统通过桥接器连接的结构，不属于单总线结构的特点。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
350	2	\N	\N	fill_blank	hard	若总线宽度为64位，总线频率为200MHz，且采用双边沿传输（即每个时钟周期可传送2次），则该总线的理论最大带宽为______GB/s。	[]	{"blanks": [{"index": 1, "answer": "3.2", "acceptable_answers": ["3.2GB/s", "3.2 GB/s"]}]}	[]	根据总线带宽计算公式：总线带宽 = 总线宽度(bit)/8 × 总线频率 × 每周期传送次数。代入数据：64 / 8 = 8 字节，频率200MHz = 200 × 10^6 Hz，每周期传送2次。带宽 = 8 × (200 × 10^6) × 2 = 3.2 × 10^9 B/s = 3.2 GB/s。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
351	2	\N	\N	short_answer	hard	请对比总线集中式判优中的“链式查询”和“独立请求”两种方式，简述它们在“优先权确定方式”、“响应速度”和“可靠性”三方面的主要区别。	[]	{"reference_answer": "1. 优先权确定方式：链式查询的优先权由设备在查询链中的物理位置固定，靠近总线控制器的优先级高；独立请求的优先级由总线控制器通过软件或硬件灵活设定和改变。2. 响应速度：链式查询需要沿链逐个查询，响应速度较慢，且取决于链长；独立请求由控制器直接裁决，响应速度快。3. 可靠性：链式查询中任一设备故障或链路断开会影响后续所有设备，可靠性较低；独立请求采用独立请求线，单个设备故障不影响其他设备，可靠性较高。"}	["正确说明优先权确定方式的区别（固定物理位置 vs 灵活设定）", "正确说明响应速度的区别（慢/逐级查询 vs 快/直接裁决）", "正确说明可靠性的区别（受链路影响大 vs 故障隔离性好）"]	该题考察对两种核心集中式判优方式原理性差异的理解。链式查询的特点是结构简单、优先级固定，但响应慢、可靠性低；独立请求的特点是优先级灵活、响应快、可靠性高，但所需控制线多。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
352	2	\N	\N	calculation	hard	一个采用同步通信方式的系统总线，总线时钟频率为100MHz。在一个总线周期内，地址阶段占用1个时钟周期，数据阶段占用3个时钟周期（即每个数据传输需要4个时钟周期）。如果总线宽度为32位，请计算该总线的最大数据传输率（单位：MB/s）。	[]	{"reference_answer": "计算步骤：\\n1. 一个完整的数据传输周期 = 1（地址） + 3（数据） = 4 个时钟周期。\\n2. 每个传输周期的时间 = 4 / (100 × 10^6) 秒 = 4 × 10^-8 秒。\\n3. 每个周期传输的数据量 = 32位 = 4字节。\\n4. 最大数据传输率 = 4 字节 / (4 × 10^-8 秒) = 10^8 字节/秒 = 100 × 10^6 B/s = 100 MB/s。\\n答案：100 MB/s"}	["正确计算出总线周期为4个时钟周期", "正确计算出每个周期传输的数据量（4字节）", "最终结果正确（100 MB/s）"]	本题考察对总线带宽公式在具体时序场景下的应用。关键在于理解“每周期传送次数”在此上下文中的含义：由于地址和数据阶段分离，完成一次有效数据传送需要占用多个时钟周期（4个）。因此，有效传送速率 = (总线宽度/8) / 完成一次传送所需的总时钟周期时间。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
353	2	\N	\N	short_answer	hard	为什么现代计算机系统通常不采用单一的“单总线”结构，而是采用“多总线”或“分层总线”结构？请结合总线性能和系统需求进行简要说明。	[]	{"reference_answer": "因为单总线结构将所有部件（CPU、内存、高速I/O、低速I/O）都挂在同一条总线上，会导致两个主要问题：1. 性能瓶颈：所有设备共享带宽，高速CPU与慢速外设的速度差异会拖慢整个系统，CPU访问内存的速度也会受I/O操作干扰。2. 扩展性差：增加设备会加重总线负担，且难以满足不同设备对带宽和延迟的差异化需求。\\n采用多总线/分层结构（如CPU-内存高速总线、I/O总线、低速外设总线）可以通过桥接器隔离不同速度的设备，让高速通路（如CPU-内存）保持高速，同时通过专用总线连接特定速度的设备，提高了系统的并发性、整体性能和扩展性。"}	["指出单总线结构的性能瓶颈问题（共享带宽、速度匹配问题）", "指出单总线结构的扩展性问题", "说明多总线结构如何通过分层隔离解决上述问题（如分离高速与低速通路）"]	此题旨在检验对不同总线结构优缺点及其设计初衷的理解。单总线结构简单但存在根本性的性能限制，而多总线结构是平衡成本、性能和复杂性的工程解决方案。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
354	2	\N	\N	fill_blank	hard	总线特性中，______特性规定了总线信号的电平、传输速率和驱动能力；______特性规定了总线每一根传输线的功能定义；______特性则规定了总线操作过程中各信号有效的时序关系。	[]	{"blanks": [{"index": 1, "answer": "电气", "acceptable_answers": []}, {"index": 2, "answer": "功能", "acceptable_answers": []}, {"index": 3, "answer": "时间", "acceptable_answers": ["时序"]}]}	[]	根据知识块，总线特性包括电气、机械、功能、时间四类。电气特性对应信号电气参数；功能特性对应每根线的功能定义；时间特性（或时序特性）对应信号的时序关系。机械特性则对应物理连接器和尺寸，题目中未涉及。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
357	2	\N	\N	true_false	easy	在总线判优的集中式方式中，链式查询、计数器定时查询和独立请求方式都属于集中式判优的常见类型。	[]	{"answer": "TRUE"}	[]	根据知识块，在总线判优中，集中式判优常见有链式查询、计数器定时查询、独立请求方式。分布式判优则把判优逻辑分散到各模块。因此，题干描述是正确的。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
358	2	\N	\N	single_choice	easy	总线带宽是衡量总线性能的重要指标。若一条总线的宽度为32位，总线频率为100MHz，且每个时钟周期可传送1次数据，则该总线的理论带宽约为多少？	[{"key": "A", "text": "100 MB/s"}, {"key": "B", "text": "200 MB/s"}, {"key": "C", "text": "400 MB/s"}, {"key": "D", "text": "800 MB/s"}]	{"answer": "C"}	[]	根据总线带宽计算公式：总线带宽 = 总线宽度(bit)/8 × 总线频率 × 每周期传送次数。代入数据：总线宽度=32位，总线频率=100MHz，每周期传送次数=1。计算得：32/8 × 100M × 1 = 4 × 100MB/s = 400 MB/s。因此选项C正确。选项A、B、D的计算结果均不正确。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
361	2	\N	\N	short_answer	medium	请简述单总线结构和多总线结构的主要区别及各自优缺点。	[]	{"reference_answer": "单总线结构将CPU、存储器、I/O设备等所有模块都连接到一条公共总线上。其优点是结构简单、成本低；缺点是所有部件共享同一通路，当多个部件同时通信时会形成瓶颈，降低系统并发性。多总线结构将不同速度或用途的通路分开，例如设立CPU-存储器高速总线和独立的I/O总线。其优点是提高了并发性和扩展性，允许CPU与存储器高速通信的同时进行I/O操作；缺点是结构更复杂，成本更高。"}	["正确说明单总线结构特点（共享一条通路、简单、成本低、易瓶颈）", "正确说明多总线结构特点（分层/分离、提高并发性和扩展性、结构复杂）"]	答案基于知识块中关于单总线和多总线结构的描述。单总线简单但共享带宽易成瓶颈，多总线通过分层提高并发性，这是两者的核心区别。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
362	2	\N	\N	calculation	medium	某总线宽度为64位，总线时钟频率为800MHz，每个时钟周期传送1次数据。请计算该总线的带宽，并以MB/s为单位表示（1MB=10^6 B）。	[]	{"reference_answer": "总线带宽 = (64 bit / 8) × 800,000,000 Hz × 1 = 8 B × 800,000,000 /s = 6,400,000,000 B/s = 6400 MB/s。"}	["正确列出总线带宽公式：带宽 = (总线宽度(bit)/8) × 总线频率 × 每周期传送次数", "正确代入数值并计算结果，注意单位换算正确（1MB=10^6 B）"]	根据知识块中的总线带宽公式：总线带宽 = 总线宽度(bit)/8 × 总线频率 × 每周期传送次数。本题宽度64位、频率800MHz（即800,000,000 Hz）、每周期1次。计算过程为 (64/8) × 800,000,000 × 1 = 6,400,000,000 B/s。再换算为MB/s时，除以10^6，得到6400 MB/s。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	0	0	0	0	0
364	3	\N	\N	single_choice	easy	计算机内部采用二进制表示数据，其主要原因不包括下列哪一项？	[{"key": "A", "text": "物理实现简单"}, {"key": "B", "text": "抗干扰能力强"}, {"key": "C", "text": "运算规则复杂，便于加密"}, {"key": "D", "text": "逻辑表达自然"}]	{"answer": "C"}	[]	根据知识块[ch03-s002-01]，计算机采用二进制的原因是物理实现简单、抗干扰强、运算规则简单、逻辑表达自然。选项C描述“运算规则复杂，便于加密”与事实相反，二进制运算规则简单，并非为了加密，因此C不合适。	ai:model-draft;chunks=ch03-s001-01,ch03-s002-01,ch03-s003-01,ch03-s004-01,ch03-s005-01,ch03-s006-01,ch03-s007-01,ch03-s008-01	AI题目生成	t	t	2026-06-01 15:03:21.100805+00	2026-06-01 15:03:21.100805+00	f	verified	0	0	0	0	0	0
366	3	\N	\N	multiple_choice	easy	根据知识块描述，IEEE 754单精度浮点数格式通常包含哪些组成部分？	[{"key": "A", "text": "1位符号位"}, {"key": "B", "text": "8位阶码"}, {"key": "C", "text": "23位尾数"}, {"key": "D", "text": "16位校验码"}]	{"answer": ["A", "B", "C"]}	[]	根据知识块[ch03-s006-01]，IEEE 754单精度浮点数通常由1位符号位、8位阶码、23位尾数组成。选项D“16位校验码”不属于IEEE 754单精度浮点数的基本组成部分，因此不合适。	ai:model-draft;chunks=ch03-s001-01,ch03-s002-01,ch03-s003-01,ch03-s004-01,ch03-s005-01,ch03-s006-01,ch03-s007-01,ch03-s008-01	AI题目生成	t	t	2026-06-01 15:03:21.100805+00	2026-06-01 15:03:21.100805+00	f	verified	0	0	0	0	0	0
367	3	\N	\N	single_choice	easy	关于奇偶校验，以下描述正确的是？	[{"key": "A", "text": "能发现并纠正所有单比特错误"}, {"key": "B", "text": "能发现奇数位错误，但不能纠正错误"}, {"key": "C", "text": "能发现偶数位错误，并纠正单比特错误"}, {"key": "D", "text": "能发现所有错误并定位错误位置"}]	{"answer": "B"}	[]	根据知识块[ch03-s008-01]，奇偶校验能发现奇数位错误，但不能定位和纠正错误。选项A、C、D均描述了奇偶校验不具备的纠正能力或过于强大的检错能力，因此不合适。	ai:model-draft;chunks=ch03-s001-01,ch03-s002-01,ch03-s003-01,ch03-s004-01,ch03-s005-01,ch03-s006-01,ch03-s007-01,ch03-s008-01	AI题目生成	t	t	2026-06-01 15:03:21.100805+00	2026-06-01 15:03:21.100805+00	f	verified	0	0	0	0	0	0
368	3	\N	\N	true_false	easy	定点数表示法的小数点位置固定，硬件实现简单、速度快，适合表示任意范围的实数。	[]	{"answer": "FALSE"}	[]	根据知识块[ch03-s003-01]和[ch03-s005-01]，定点数的小数点位置固定，硬件简单、速度快，但表示范围受限，适合表示绝对值小于1的数或整数，而非“任意范围的实数”。浮点数才适合扩大数值范围。	ai:model-draft;chunks=ch03-s001-01,ch03-s002-01,ch03-s003-01,ch03-s004-01,ch03-s005-01,ch03-s006-01,ch03-s007-01,ch03-s008-01	AI题目生成	t	t	2026-06-01 15:03:21.100805+00	2026-06-01 15:03:21.100805+00	f	verified	0	0	0	0	0	0
369	3	\N	\N	fill_blank	medium	一个8位补码整数，其表示范围是______到______。	[]	{"blanks": [{"index": 1, "answer": "-128", "acceptable_answers": ["-2^7", "-2^{7}", "-128"]}, {"index": 2, "answer": "127", "acceptable_answers": ["2^7-1", "2^{7}-1", "127"]}]}	[]	根据知识块，n位补码整数的表示范围通常为 -2^(n-1) 到 2^(n-1)-1。对于8位（n=8），范围是 -2^7 (-128) 到 2^7-1 (127)。	ai:model-draft;chunks=ch03-s001-01,ch03-s002-01,ch03-s003-01,ch03-s004-01,ch03-s005-01,ch03-s006-01,ch03-s007-01,ch03-s008-01	AI题目生成	t	t	2026-06-01 15:03:21.100805+00	2026-06-01 15:03:21.100805+00	f	verified	0	0	0	0	0	0
370	3	\N	\N	short_answer	medium	简述奇偶校验码的主要功能和局限性。	[]	{"reference_answer": "奇偶校验码能发现数据传输或存储中发生的奇数个比特错误，但不能定位错误发生的具体位置，也无法纠正任何错误。"}	["答出“发现奇数位错误”得一半分", "答出“不能定位和纠正错误”得另一半分"]	根据知识块，奇偶校验能发现奇数位错误，但不能定位和纠正错误。题目要求简述功能和局限性，此答案涵盖了核心内容。	ai:model-draft;chunks=ch03-s001-01,ch03-s002-01,ch03-s003-01,ch03-s004-01,ch03-s005-01,ch03-s006-01,ch03-s007-01,ch03-s008-01	AI题目生成	t	t	2026-06-01 15:03:21.100805+00	2026-06-01 15:03:21.100805+00	f	verified	0	0	0	0	0	0
371	3	\N	\N	calculation	medium	将十六进制数 1A3.F 转换为二进制数。	[]	{"reference_answer": "0001 1010 0011.1111"}	["整数部分转换正确", "小数部分转换正确", "位数完整或格式清晰"]	根据知识块，4位二进制对应1位十六进制。整数部分：1 (0001)，A (1010)，3 (0011)。小数部分：F (1111)。组合即得结果。	ai:model-draft;chunks=ch03-s001-01,ch03-s002-01,ch03-s003-01,ch03-s004-01,ch03-s005-01,ch03-s006-01,ch03-s007-01,ch03-s008-01	AI题目生成	t	t	2026-06-01 15:03:21.100805+00	2026-06-01 15:03:21.100805+00	f	verified	0	0	0	0	0	0
372	3	\N	\N	fill_blank	medium	IEEE 754单精度浮点数由1位符号位、______位阶码和______位尾数（隐含前导1）组成。	[]	{"blanks": [{"index": 1, "answer": "8", "acceptable_answers": ["8"]}, {"index": 2, "answer": "23", "acceptable_answers": ["23"]}]}	[]	根据知识块，IEEE 754单精度通常由1位符号位、8位阶码、23位尾数组成。此处直接考查对标准格式的记忆。	ai:model-draft;chunks=ch03-s001-01,ch03-s002-01,ch03-s003-01,ch03-s004-01,ch03-s005-01,ch03-s006-01,ch03-s007-01,ch03-s008-01	AI题目生成	t	t	2026-06-01 15:03:21.100805+00	2026-06-01 15:03:21.100805+00	f	verified	0	0	0	0	0	0
373	3	\N	\N	short_answer	medium	补码运算中，什么情况下会发生溢出？为什么说“异号相加一般不会溢出”？	[]	{"reference_answer": "当两个同号数相加，其运算结果的符号与两个操作数的符号不同时，通常表示发生了溢出。因为异号数相加，其结果的绝对值必然小于或等于两个操作数中绝对值较大的那个，所以其结果一定在可表示的范围内，一般不会溢出。"}	["正确描述溢出条件：同号相加结果变号", "解释异号相加不溢出的原因"]	根据知识块，“同号相加结果变异号通常表示溢出；异号相加一般不会溢出”。解析需解释这两个判断的逻辑依据，即结果的范围限制。	ai:model-draft;chunks=ch03-s001-01,ch03-s002-01,ch03-s003-01,ch03-s004-01,ch03-s005-01,ch03-s006-01,ch03-s007-01,ch03-s008-01	AI题目生成	t	t	2026-06-01 15:03:21.100805+00	2026-06-01 15:03:21.100805+00	f	verified	0	0	0	0	0	0
374	3	\N	\N	single_choice	medium	计算机内部采用二进制的主要原因不包括以下哪一项？	[{"key": "A", "text": "物理实现简单"}, {"key": "B", "text": "运算规则简单"}, {"key": "C", "text": "表示范围最大"}, {"key": "D", "text": "逻辑表达自然"}]	{"answer": "C"}	[]	计算机采用二进制的原因包括物理实现简单、抗干扰强、运算规则简单、逻辑表达自然。二进制并非在所有进制中表示范围最大，其主要优势在于硬件实现和运算的便利性。	ai:model-draft;chunks=ch03-s001-01,ch03-s002-01,ch03-s003-01,ch03-s004-01,ch03-s005-01,ch03-s006-01,ch03-s007-01,ch03-s008-01	AI题目生成	t	t	2026-06-01 15:03:21.100805+00	2026-06-01 15:03:21.100805+00	f	verified	0	0	0	0	0	0
375	3	\N	\N	true_false	medium	在补码表示中，两个异号数相加一定不会发生溢出。	[]	{"answer": "TRUE"}	[]	根据知识块描述，溢出通常发生在同号数相加结果符号改变时，而异号数相加一般不会溢出。	ai:model-draft;chunks=ch03-s001-01,ch03-s002-01,ch03-s003-01,ch03-s004-01,ch03-s005-01,ch03-s006-01,ch03-s007-01,ch03-s008-01	AI题目生成	t	t	2026-06-01 15:03:21.100805+00	2026-06-01 15:03:21.100805+00	f	verified	0	0	0	0	0	0
408	6	\N	\N	true_false	easy	RISC指令系统的特点之一是采用Load/Store结构，即只有Load和Store指令才能访问内存，其他指令操作的数据都在寄存器中。	[]	{"answer": "TRUE"}	[]	根据知识块，RISC指令系统具有Load/Store结构明显的特点，这意味着运算指令的操作数主要来自寄存器，内存访问由专门的Load和Store指令完成。	ai:model-draft;chunks=ch06-s001-01,ch06-s002-01,ch06-s003-01,ch06-s004-01,ch06-s005-01,ch06-s006-01,ch06-s007-01,ch06-s008-01	AI题目生成	t	t	2026-06-01 15:06:49.164868+00	2026-06-01 15:06:49.164868+00	f	verified	0	0	0	0	0	0
376	3	\N	\N	multiple_choice	medium	关于IEEE 754单精度浮点数的构成，以下哪些描述是正确的？	[{"key": "A", "text": "包含1位符号位"}, {"key": "B", "text": "包含8位阶码"}, {"key": "C", "text": "包含23位尾数"}, {"key": "D", "text": "包含10位阶码"}]	{"answer": ["A", "B", "C"]}	[]	根据知识块描述，IEEE 754单精度浮点数由1位符号位、8位阶码和23位尾数组成。选项D描述的10位阶码是双精度浮点数的阶码位数（知识块中未明确说明单精度为10位），因此不正确。	ai:model-draft;chunks=ch03-s001-01,ch03-s002-01,ch03-s003-01,ch03-s004-01,ch03-s005-01,ch03-s006-01,ch03-s007-01,ch03-s008-01	AI题目生成	t	t	2026-06-01 15:03:21.100805+00	2026-06-01 15:03:21.100805+00	f	verified	0	0	0	0	0	0
377	3	\N	\N	single_choice	medium	以下关于奇偶校验的描述，哪一项是正确的？	[{"key": "A", "text": "能发现并纠正一位错误"}, {"key": "B", "text": "能发现奇数位错误"}, {"key": "C", "text": "能定位错误发生的位置"}, {"key": "D", "text": "能检测出所有可能的错误"}]	{"answer": "B"}	[]	根据知识块，奇偶校验能发现奇数位错误，但不能定位和纠正错误。选项A和C描述的是海明码的功能；选项D过于绝对，奇偶校验无法检测偶数位错误。	ai:model-draft;chunks=ch03-s001-01,ch03-s002-01,ch03-s003-01,ch03-s004-01,ch03-s005-01,ch03-s006-01,ch03-s007-01,ch03-s008-01	AI题目生成	t	t	2026-06-01 15:03:21.100805+00	2026-06-01 15:03:21.100805+00	f	verified	0	0	0	0	0	0
378	4	\N	\N	single_choice	easy	在补码加法运算中，判断溢出的一种方法是观察符号位进位与最高数值位进位的关系。当两者满足什么关系时，表示发生了溢出？	[{"key": "A", "text": "两者相同"}, {"key": "B", "text": "两者不同（异或结果为1）"}, {"key": "C", "text": "符号位进位为1"}, {"key": "D", "text": "最高数值位进位为0"}]	{"answer": "B"}	[]	根据知识块，溢出判断可采用符号位进位与最高数值位进位异或的方法。异或结果为1（即两者不同）时表示溢出。选项A错误，相同表示无溢出；选项C和D描述不准确，进位值本身不能单独决定溢出，需要两者的关系。	ai:model-draft;chunks=ch04-s001-01,ch04-s002-01,ch04-s003-01,ch04-s004-01,ch04-s005-01,ch04-s006-01,ch04-s007-01,ch04-s008-01	AI题目生成	t	t	2026-06-01 15:04:16.016449+00	2026-06-01 15:04:16.016449+00	f	verified	0	0	0	0	0	0
379	4	\N	\N	true_false	easy	补码乘法中的Booth算法，是根据乘数相邻两位的变化来决定对部分积执行加法、减法还是只移位的操作。	[]	{"answer": "TRUE"}	[]	知识块明确指出，补码乘法常见思想是Booth算法，其核心正是根据相邻位变化决定加、减或只移位。	ai:model-draft;chunks=ch04-s001-01,ch04-s002-01,ch04-s003-01,ch04-s004-01,ch04-s005-01,ch04-s006-01,ch04-s007-01,ch04-s008-01	AI题目生成	t	t	2026-06-01 15:04:16.016449+00	2026-06-01 15:04:16.016449+00	f	verified	0	0	0	0	0	0
380	4	\N	\N	multiple_choice	easy	浮点数加减运算的标准流程包含多个步骤。以下哪些是其中必需的基本步骤？（多选）	[{"key": "A", "text": "对阶"}, {"key": "B", "text": "尾数加减"}, {"key": "C", "text": "规格化"}, {"key": "D", "text": "舍入"}, {"key": "E", "text": "溢出判断"}]	{"answer": ["A", "B", "C", "D", "E"]}	[]	根据知识块，浮点加减五步流程为：对阶、尾数运算、规格化、舍入、溢出判断。五个选项均包含在内，因此都是必需的基本步骤。	ai:model-draft;chunks=ch04-s001-01,ch04-s002-01,ch04-s003-01,ch04-s004-01,ch04-s005-01,ch04-s006-01,ch04-s007-01,ch04-s008-01	AI题目生成	t	t	2026-06-01 15:04:16.016449+00	2026-06-01 15:04:16.016449+00	f	verified	0	0	0	0	0	0
381	4	\N	\N	true_false	easy	在运算器组成中，ALU（算术逻辑单元）主要负责执行算术运算和逻辑运算，并产生运算结果的各种状态标志。	[]	{"answer": "TRUE"}	[]	知识块指出，ALU完成算术和逻辑运算，而标志位（如进位、溢出、零、符号等状态）通常由运算结果产生并记录。因此该陈述正确。	ai:model-draft;chunks=ch04-s001-01,ch04-s002-01,ch04-s003-01,ch04-s004-01,ch04-s005-01,ch04-s006-01,ch04-s007-01,ch04-s008-01	AI题目生成	t	t	2026-06-01 15:04:16.016449+00	2026-06-01 15:04:16.016449+00	f	verified	0	0	0	0	0	0
382	4	\N	\N	single_choice	easy	在补码表示的机器中，减法运算通常是如何被实现的？	[{"key": "A", "text": "使用独立的减法器电路"}, {"key": "B", "text": "转化为加法，即加上减数的补码"}, {"key": "C", "text": "转化为加法，即加上减数的原码"}, {"key": "D", "text": "先取反再相加"}]	{"answer": "B"}	[]	知识块明确指出，减法可以转化为加法：X - Y = X + (-Y)。在补码系统中，-Y 的补码是 Y 的补码各位取反末位加1，因此是加上减数的补码（的相反数）。选项A错误，因为补码统一了加减法，可以用同一个加法器；选项C错误，不是原码；选项D描述不准确，取反末位加1才是求负操作。	ai:model-draft;chunks=ch04-s001-01,ch04-s002-01,ch04-s003-01,ch04-s004-01,ch04-s005-01,ch04-s006-01,ch04-s007-01,ch04-s008-01	AI题目生成	t	t	2026-06-01 15:04:16.016449+00	2026-06-01 15:04:16.016449+00	f	verified	0	0	0	0	0	0
383	4	\N	\N	fill_blank	medium	在补码加减运算中，判断溢出的一种常用方法是：两个同号数相加，结果符号与加数符号不同，则溢出；或者判断______与______是否相同，若不同则溢出。	[]	{"blanks": [{"index": 1, "answer": "符号位进位", "acceptable_answers": ["符号位进位", "符号位进位值"]}, {"index": 2, "answer": "最高数值位进位", "acceptable_answers": ["最高数值位进位", "最高有效位进位", "最高数值位进位值"]}]}	[]	根据知识块[03]，溢出判断的两种方法：1）两个同号数相加，结果符号与加数符号不同；2）符号位进位与最高数值位进位异或（即不同）。第二种方法直接通过比较这两个进位位的值来判断溢出。	ai:model-draft;chunks=ch04-s001-01,ch04-s002-01,ch04-s003-01,ch04-s004-01,ch04-s005-01,ch04-s006-01,ch04-s007-01,ch04-s008-01	AI题目生成	t	t	2026-06-01 15:04:16.016449+00	2026-06-01 15:04:16.016449+00	f	verified	0	0	0	0	0	0
384	4	\N	\N	short_answer	medium	简述浮点加减法运算的基本流程，并说明对阶时通常采用什么规则。	[]	{"reference_answer": "浮点加减运算的基本流程为：1.对阶；2.尾数加减；3.规格化；4.舍入；5.溢出判断。对阶时，通常采用小阶向大阶对齐的规则，即将阶码较小的数的尾数右移，每右移一位，阶码加1，直到两个数的阶码相等。"}	["答出五个步骤，顺序正确", "答出对阶规则（小阶向大阶对齐）及尾数右移方向"]	根据知识块[06]，浮点加减流程明确为五步，且对阶规则是小阶向大阶对齐，尾数右移。此答案完整涵盖了核心要点。	ai:model-draft;chunks=ch04-s001-01,ch04-s002-01,ch04-s003-01,ch04-s004-01,ch04-s005-01,ch04-s006-01,ch04-s007-01,ch04-s008-01	AI题目生成	t	t	2026-06-01 15:04:16.016449+00	2026-06-01 15:04:16.016449+00	f	verified	0	0	0	0	0	0
385	4	\N	\N	calculation	medium	假设机器字长为8位（含1位符号位），使用补码运算。已知 X = +101101B, Y = -010011B，请计算 X + Y 的补码结果，并判断运算是否溢出。	[]	{"reference_answer": "X的补码为 0,1011010（假设为8位，需补全，但知识块未明确位数细节，此处按思路计算），Y的补码为 1,101101。计算过程：... 结果为 0,011010，无溢出。具体计算：X=+45, Y=-19, X+Y=26, 补码为 0,0011010。溢出判断：两个正数相加（X为正），结果符号位为0（正），与加数符号相同，故无溢出。"}	["正确写出X和Y的补码表示", "正确进行补码加法运算", "正确运用溢出判断方法（同号相加结果符号）得出无溢出的结论"]	根据知识块[03]，补码加法是符号位参与运算，减法转化为加法。本题需先将Y（-19）转为补码，再与X（+45）的补码相加。最后用同号相加结果符号是否变化判断溢出。由于X和Y异号，相加不会溢出。	ai:model-draft;chunks=ch04-s001-01,ch04-s002-01,ch04-s003-01,ch04-s004-01,ch04-s005-01,ch04-s006-01,ch04-s007-01,ch04-s008-01	AI题目生成	t	t	2026-06-01 15:04:16.016449+00	2026-06-01 15:04:16.016449+00	f	verified	0	0	0	0	0	0
386	4	\N	\N	fill_blank	medium	在定点除法运算中，恢复余数法的基本思想是：试减后如果余数为负，则需要进行______操作，然后再继续下一次试商。而______法则通过后续的加减规则来避免这种恢复操作，从而提高硬件效率。	[]	{"blanks": [{"index": 1, "answer": "恢复", "acceptable_answers": ["恢复", "恢复原余数", "加上除数"]}, {"index": 2, "answer": "不恢复余数", "acceptable_answers": ["不恢复余数", "加减交替"]}]}	[]	根据知识块[05]，恢复余数法在余数为负时需要恢复（即加回除数），而不恢复余数法（或加减交替法）则通过规则避免恢复步骤，提高效率。	ai:model-draft;chunks=ch04-s001-01,ch04-s002-01,ch04-s003-01,ch04-s004-01,ch04-s005-01,ch04-s006-01,ch04-s007-01,ch04-s008-01	AI题目生成	t	t	2026-06-01 15:04:16.016449+00	2026-06-01 15:04:16.016449+00	f	verified	0	0	0	0	0	0
387	4	\N	\N	short_answer	medium	简述一个典型的定点运算器由哪些主要部件组成，并说明ALU的作用以及状态标志位通常记录哪些信息。	[]	{"reference_answer": "典型的定点运算器由ALU（算术逻辑单元）、通用寄存器、移位器、状态标志和内部数据通路组成。ALU的核心作用是完成算术运算（如加、减）和逻辑运算（如与、或）。状态标志位通常记录运算结果的进位、溢出、零和符号等状态信息。"}	["列出运算器的五个主要组成部分", "说明ALU的核心功能（算术和逻辑运算）", "列举至少两种状态标志信息（如进位、溢出、零、符号）"]	根据知识块[07]，运算器组成包括ALU、寄存器、移位器、状态标志和数据通路。ALU功能和标志位记录的信息也直接对应知识块描述。此答案完整覆盖了要求。	ai:model-draft;chunks=ch04-s001-01,ch04-s002-01,ch04-s003-01,ch04-s004-01,ch04-s005-01,ch04-s006-01,ch04-s007-01,ch04-s008-01	AI题目生成	t	t	2026-06-01 15:04:16.016449+00	2026-06-01 15:04:16.016449+00	f	verified	0	0	0	0	0	0
388	4	\N	\N	single_choice	medium	在补码表示的定点加减运算中，以下哪种方法不能用于判断运算结果是否溢出？	[{"key": "A", "text": "两个同号数相加，结果符号与加数符号不同"}, {"key": "B", "text": "符号位进位与最高数值位进位异或结果为1"}, {"key": "C", "text": "运算结果的绝对值超过了补码能表示的最大正数"}, {"key": "D", "text": "两个异号数相减，结果符号与减数符号相同"}]	{"answer": "C"}	[]	根据知识块，补码溢出判断的两种标准方法是：1) 两个同号数相加，结果符号与加数符号不同（选项A）；2) 符号位进位与最高数值位进位异或（选项B）。选项D描述的情况（两个异号数相减，结果符号与减数符号相同）本质上等同于同号相加变异号，因为减法被转化为加法。选项C描述的是基于绝对值概念的溢出定义，但补码系统中的溢出是针对带符号数运算而言的，与无符号数的溢出（进位/借位）不同，且该描述不精确，不能直接作为硬件判断溢出的可靠依据。	ai:model-draft;chunks=ch04-s001-01,ch04-s002-01,ch04-s003-01,ch04-s004-01,ch04-s005-01,ch04-s006-01,ch04-s007-01,ch04-s008-01	AI题目生成	t	t	2026-06-01 15:04:16.016449+00	2026-06-01 15:04:16.016449+00	f	verified	0	0	0	0	0	0
389	4	\N	\N	multiple_choice	medium	关于定点乘法和浮点乘法运算，以下描述正确的有哪些？	[{"key": "A", "text": "原码乘法通常先单独处理符号位，再对数值位进行移位加法操作"}, {"key": "B", "text": "补码乘法的Booth算法通过比较相邻乘数位来决定加、减或只移位"}, {"key": "C", "text": "浮点数乘法的流程是先将两个浮点数的尾数对齐，再进行尾数乘法和阶码相加"}, {"key": "D", "text": "浮点乘法中的舍入操作是在规格化之前完成的"}]	{"answer": ["A", "B"]}	[]	根据知识块：选项A正确，原码乘法通常先处理符号位（同号为正，异号为负），然后对数值位执行移位加法。选项B正确，Booth算法是补码乘法的常见方法，根据乘数相邻两位的差异决定是加、减还是只移位。选项C错误，浮点数乘法不需要对阶，其标准流程是：阶码相加，尾数相乘，然后进行规格化、舍入和溢出判断。选项D错误，舍入操作是在规格化之后进行的，因为规格化过程可能会产生需要舍入的位。	ai:model-draft;chunks=ch04-s001-01,ch04-s002-01,ch04-s003-01,ch04-s004-01,ch04-s005-01,ch04-s006-01,ch04-s007-01,ch04-s008-01	AI题目生成	t	t	2026-06-01 15:04:16.016449+00	2026-06-01 15:04:16.016449+00	f	verified	0	0	0	0	0	0
390	4	\N	\N	true_false	medium	在定点除法的恢复余数法中，当试商减法的结果（余数）为负时，需要先加上除数恢复余数，再进行下一步操作。	[]	{"answer": "TRUE"}	[]	根据知识块，恢复余数法的基本步骤是：进行试减（即被除数/当前余数减去除数），如果结果为负（不够减），则商上0，并需要将除数加回去恢复原来的余数，然后才能进行下一步的移位和试商。这确保了下一步操作基于正确的余数。	ai:model-draft;chunks=ch04-s001-01,ch04-s002-01,ch04-s003-01,ch04-s004-01,ch04-s005-01,ch04-s006-01,ch04-s007-01,ch04-s008-01	AI题目生成	t	t	2026-06-01 15:04:16.016449+00	2026-06-01 15:04:16.016449+00	f	verified	0	0	0	0	0	0
391	4	\N	\N	single_choice	medium	执行浮点数加法运算时，以下哪个步骤通常最先进行？	[{"key": "A", "text": "尾数相加"}, {"key": "B", "text": "对阶（小阶向大阶看齐）"}, {"key": "C", "text": "规格化"}, {"key": "D", "text": "溢出判断"}]	{"answer": "B"}	[]	根据知识块，浮点加减的标准流程是：对阶 -> 尾数加减 -> 规格化 -> 舍入 -> 溢出判断。因此，最先进行的步骤是对阶，其目的是使两个操作数的阶码相同，从而可以直接对尾数进行加减运算。选项A、C、D都是在后续步骤中完成的。	ai:model-draft;chunks=ch04-s001-01,ch04-s002-01,ch04-s003-01,ch04-s004-01,ch04-s005-01,ch04-s006-01,ch04-s007-01,ch04-s008-01	AI题目生成	t	t	2026-06-01 15:04:16.016449+00	2026-06-01 15:04:16.016449+00	f	verified	0	0	0	0	0	0
392	4	\N	\N	multiple_choice	medium	根据知识块，一个典型的定点运算器通常包含以下哪些组成部分？	[{"key": "A", "text": "算术逻辑单元（ALU）"}, {"key": "B", "text": "通用寄存器组"}, {"key": "C", "text": "移位器"}, {"key": "D", "text": "浮点运算单元（FPU）"}]	{"answer": ["A", "B", "C"]}	[]	根据知识块，定点运算器通常由ALU、通用寄存器、移位器、状态标志和内部数据通路组成。因此选项A、B、C都是其典型组成部分。选项D（浮点运算单元）虽然也是现代处理器的重要部件，但它属于浮点运算部件，不属于题目限定的“定点运算器”的典型组成部分。	ai:model-draft;chunks=ch04-s001-01,ch04-s002-01,ch04-s003-01,ch04-s004-01,ch04-s005-01,ch04-s006-01,ch04-s007-01,ch04-s008-01	AI题目生成	t	t	2026-06-01 15:04:16.016449+00	2026-06-01 15:04:16.016449+00	f	verified	0	0	0	0	0	0
393	4	\N	\N	fill_blank	hard	在补码加减运算中，判断溢出的一种硬件实现方法是：让符号位产生的进位与最高数值位产生的进位进行______运算，若结果为1则表示溢出。	[]	{"blanks": [{"index": 1, "answer": "异或", "acceptable_answers": ["XOR", "异或"]}]}	[]	根据知识块[08]和[03]，补码溢出判断方法之一是符号位进位与最高数值位进位进行异或运算，结果为1则表示溢出。这是硬件实现中常用的一种精确判断方法。	ai:model-draft;chunks=ch04-s001-01,ch04-s002-01,ch04-s003-01,ch04-s004-01,ch04-s005-01,ch04-s006-01,ch04-s007-01,ch04-s008-01	AI题目生成	t	t	2026-06-01 15:04:16.016449+00	2026-06-01 15:04:16.016449+00	f	verified	0	0	0	0	0	0
394	4	\N	\N	short_answer	hard	简述浮点数加减法中“对阶”的目的、通常采用的方法及其原因。	[]	{"reference_answer": "1. 目的：对阶是为了使两个浮点数的指数部分（阶码）相等，从而能够对尾数进行直接加减运算。2. 方法：通常采用小阶向大阶看齐的方法，即小阶数的尾数右移，阶码增大，直至与大阶相等。3. 原因：小阶尾数右移只会丢失低位精度，损失相对较小；若采用大阶向小阶看齐（尾数左移），则可能丢失高位有效数字，造成更大的精度损失甚至错误。"}	["答出对阶目的：使阶码相等以便进行尾数运算。", "答出对阶方法：小阶向大阶对齐，尾数右移，阶码增大。", "答出原因：小阶尾数右移精度损失较小，而大阶尾数左移可能丢失高位有效数字。"]	根据知识块[06]，浮点加减流程的第一步是“对阶”，并指出“对阶通常把小阶向大阶对齐，小阶尾数右移”。需要考生理解对阶的目的和选择这种规则的原因，以检验对浮点运算流程及其背后原理的掌握。	ai:model-draft;chunks=ch04-s001-01,ch04-s002-01,ch04-s003-01,ch04-s004-01,ch04-s005-01,ch04-s006-01,ch04-s007-01,ch04-s008-01	AI题目生成	t	t	2026-06-01 15:04:16.016449+00	2026-06-01 15:04:16.016449+00	f	verified	0	0	0	0	0	0
395	4	\N	\N	calculation	hard	已知 [X]补 = 01101, [Y]补 = 01011，采用双符号位补码进行运算，求 [X - Y]补，并判断运算结果是否溢出？如溢出，是何种溢出？	[]	{"reference_answer": "1. 转换：求[-Y]补。已知[Y]补 = 0 01011（假设6位，含1位符号位，这里用双符号位需扩展），首先找到[Y]补的机器数形式。题目给出的[Y]补=01011，应为5位补码（1位符号位，4位数值位）。为进行双符号位计算，先扩展为6位（2位符号位+4位数值位）：[Y]补 = 00 1011。则[-Y]补 = [Y]补连同符号位取反末位加1，即对00 1011求补：11 0101。\\n2. 计算： [X]补 = 00 1101 （扩展为6位） + [-Y]补 = 11 0101 ---------------------- 结果为 100 0010 (其中最高位1是溢出位，可丢弃，但双符号位模式下需保留分析)。在双符号位表示下，结果为 10 0010。\\n3. 判断溢出：双符号位不一致（高位符号为1，低位符号为0），表明结果溢出。由于两个操作数（X和Y）的原符号位均为0（正数），相减后结果符号位（取双符号位的高位）为1（负数），而正确结果（X-Y=01101-01011=00010）应为正数，故为“正溢出”。"}	["正确写出[X]补和[-Y]补的双符号位形式。", "完成补码加法运算，得到正确结果。", "根据双符号位不一致正确判断出溢出。", "根据操作数和结果符号正确指出是正溢出。"]	根据知识块[03]，减法转化为加负数。溢出判断可使用双符号位法：若双符号位不同则溢出。本题中，X和Y均为正数（单符号位为0），X-Y结果应为正数，但计算得到的双符号位为10（负），说明是正溢出（上溢）。此题综合考察了补码减法、溢出判断方法及理解。	ai:model-draft;chunks=ch04-s001-01,ch04-s002-01,ch04-s003-01,ch04-s004-01,ch04-s005-01,ch04-s006-01,ch04-s007-01,ch04-s008-01	AI题目生成	t	t	2026-06-01 15:04:16.016449+00	2026-06-01 15:04:16.016449+00	f	verified	0	0	0	0	0	0
396	4	\N	\N	short_answer	hard	Booth算法的核心思想是什么？它相比原码乘法算法有何优势？	[]	{"reference_answer": "1. 核心思想：Booth算法是一种补码乘法算法。它通过观察乘数相邻两位（当前位与低位）的编码组合（00, 01, 10, 11）来决定对部分积（累加器）进行加被乘数、减被乘数还是只进行移位操作，从而完成乘法。2. 优势：直接对补码数进行运算，无需先将负数转换为原码再运算，简化了硬件电路；其规则（加、减、只移位）在硬件实现上便于流水线化，可能提高效率。"}	["指出Booth算法是用于补码乘法的算法。", "说明其通过相邻位编码决定加、减或移位操作。", "指出优势：无需原码转换，直接处理补码数；硬件实现可能更高效。"]	根据知识块[04]，补码乘法常见思想是Booth算法，根据相邻位变化决定加、减或只移位。其优势体现在直接处理补码，简化了处理负数的步骤，是硬件实现补码乘法的有效方法。	ai:model-draft;chunks=ch04-s001-01,ch04-s002-01,ch04-s003-01,ch04-s004-01,ch04-s005-01,ch04-s006-01,ch04-s007-01,ch04-s008-01	AI题目生成	t	t	2026-06-01 15:04:16.016449+00	2026-06-01 15:04:16.016449+00	f	verified	0	0	0	0	0	0
397	4	\N	\N	fill_blank	hard	定点除法中，不恢复余数法（也称加减交替法）的核心改进在于：当某次试商减法后余数为负时，不再恢复余数，而是在下一步操作中通过______操作来补偿。	[]	{"blanks": [{"index": 1, "answer": "加除数", "acceptable_answers": ["加除数", "加上除数"]}]}	[]	根据知识块[05]，不恢复余数法用后续加减规则避免每次恢复，提高效率。具体来说，当试减后余数为负时，商0，并在下一步将余数左移后加上除数（而不是先恢复再减），从而“补偿”了之前的操作，避免了显式的恢复步骤。	ai:model-draft;chunks=ch04-s001-01,ch04-s002-01,ch04-s003-01,ch04-s004-01,ch04-s005-01,ch04-s006-01,ch04-s007-01,ch04-s008-01	AI题目生成	t	t	2026-06-01 15:04:16.016449+00	2026-06-01 15:04:16.016449+00	f	verified	0	0	0	0	0	0
398	4	\N	\N	true_false	easy	在补码加法运算中，如果两个正数相加结果为负数，则发生了溢出。	[]	{"answer": "TRUE"}	[]	根据知识块 ch04-s003-01，溢出判断的一个重点是“两个同号数相加，结果符号与加数符号不同，则溢出”。两个正数（同号）相加，结果符号为负，与加数符号（正）不同，因此属于溢出。该描述正确。	ai:model-draft;chunks=ch04-s001-01,ch04-s002-01,ch04-s003-01,ch04-s004-01,ch04-s005-01,ch04-s006-01,ch04-s007-01,ch04-s008-01	AI题目生成	t	t	2026-06-01 15:04:16.016449+00	2026-06-01 15:04:16.016449+00	f	verified	0	0	0	0	0	0
399	4	\N	\N	single_choice	easy	浮点数加减运算的第一步通常是（）。	[{"key": "A", "text": "尾数加减"}, {"key": "B", "text": "对阶"}, {"key": "C", "text": "规格化"}, {"key": "D", "text": "舍入"}]	{"answer": "B"}	[]	根据知识块 ch04-s006-01，浮点加减流程的明确步骤是“对阶 -> 尾数加减 -> 规格化 -> 舍入 -> 溢出判断”。因此第一步是对阶，选项B正确。选项A、C、D分别是后续步骤。	ai:model-draft;chunks=ch04-s001-01,ch04-s002-01,ch04-s003-01,ch04-s004-01,ch04-s005-01,ch04-s006-01,ch04-s007-01,ch04-s008-01	AI题目生成	t	t	2026-06-01 15:04:16.016449+00	2026-06-01 15:04:16.016449+00	f	verified	0	0	0	0	0	0
400	4	\N	\N	multiple_choice	easy	下列关于补码加法溢出判断的说法中，正确的有（）。	[{"key": "A", "text": "两个正数相加，结果为负数则溢出"}, {"key": "B", "text": "两个负数相加，结果为正数则溢出"}, {"key": "C", "text": "一正一负相加，结果必然不会溢出"}, {"key": "D", "text": "可以通过符号位进位与最高数值位进位异或来判断溢出"}]	{"answer": ["A", "B", "C", "D"]}	[]	根据知识块 ch04-s003-01和ch04-s008-01，溢出判断的重点包括：1) 两个同号数相加，结果符号与加数符号不同则溢出。因此，两个正数相加结果为负数（A正确），两个负数相加结果为正数（B正确）都属于溢出。2) 两个异号数相加，结果的绝对值不会超过任一加数的绝对值，因此不会溢出（C正确）。3) 溢出也可用符号位进位与最高数值位进位异或判断（D正确）。所有选项均符合知识块描述。	ai:model-draft;chunks=ch04-s001-01,ch04-s002-01,ch04-s003-01,ch04-s004-01,ch04-s005-01,ch04-s006-01,ch04-s007-01,ch04-s008-01	AI题目生成	t	t	2026-06-01 15:04:16.016449+00	2026-06-01 15:04:16.016449+00	f	verified	0	0	0	0	0	0
401	4	\N	\N	true_false	easy	算术右移和逻辑右移在移入位上不同，算术右移补符号位，逻辑右移补0。	[]	{"answer": "TRUE"}	[]	根据知识块 ch04-s008-01，明确说明“算术右移补符号位，逻辑右移补0”。该描述正确。	ai:model-draft;chunks=ch04-s001-01,ch04-s002-01,ch04-s003-01,ch04-s004-01,ch04-s005-01,ch04-s006-01,ch04-s007-01,ch04-s008-01	AI题目生成	t	t	2026-06-01 15:04:16.016449+00	2026-06-01 15:04:16.016449+00	f	verified	0	0	0	0	0	0
402	4	\N	\N	single_choice	easy	下列关于定点除法运算的描述，错误的是（）。	[{"key": "A", "text": "除法本质是“试商 + 减法/恢复 + 移位”"}, {"key": "B", "text": "恢复余数法在试减后余数为负时需要恢复"}, {"key": "C", "text": "不恢复余数法（加减交替法）通过后续加减规则避免每次恢复，提高效率"}, {"key": "D", "text": "除法运算的硬件实现比加法和乘法更简单"}]	{"answer": "D"}	[]	根据知识块 ch04-s005-01，除法本质、恢复余数法、不恢复余数法的描述与选项A、B、C相符。但知识块明确指出“除法比加法和乘法更复杂，硬件实现代价更高”，因此选项D“除法运算的硬件实现比加法和乘法更简单”是错误的。	ai:model-draft;chunks=ch04-s001-01,ch04-s002-01,ch04-s003-01,ch04-s004-01,ch04-s005-01,ch04-s006-01,ch04-s007-01,ch04-s008-01	AI题目生成	t	t	2026-06-01 15:04:16.016449+00	2026-06-01 15:04:16.016449+00	f	verified	0	0	0	0	0	0
403	4	\N	\N	fill_blank	medium	在浮点加减运算中，对阶阶段通常将________的尾数向________方向移动，使两数阶码相等。	[]	{"blanks": [{"index": 1, "answer": "小阶数", "acceptable_answers": ["小阶", "阶码小的数"]}, {"index": 2, "answer": "右", "acceptable_answers": []}]}	[]	根据知识块[ch04-s006-01]，浮点加减流程中，对阶通常把小阶向大阶对齐，小阶尾数右移。因此，第一个空应填“小阶数”或类似表述，第二个空应填“右”。	ai:model-draft;chunks=ch04-s001-01,ch04-s002-01,ch04-s003-01,ch04-s004-01,ch04-s005-01,ch04-s006-01,ch04-s007-01,ch04-s008-01	AI题目生成	t	t	2026-06-01 15:04:16.016449+00	2026-06-01 15:04:16.016449+00	f	verified	0	0	0	0	0	0
404	5	\N	\N	single_choice	easy	在存储体系中，通常用于构建高速缓冲存储器（Cache）的存储器类型是？	[{"key": "A", "text": "SRAM"}, {"key": "B", "text": "DRAM"}, {"key": "C", "text": "磁盘"}, {"key": "D", "text": "光盘"}]	{"answer": "A"}	[]	根据知识块内容，SRAM速度快、成本高、集成度低，常用于Cache；DRAM集成度高、成本低、需刷新，常用于主存。磁盘和光盘属于外存，速度较慢，不用于Cache。	ai:model-draft;chunks=ch05-s001-01,ch05-s002-01,ch05-s003-01,ch05-s004-01,ch05-s005-01,ch05-s006-01,ch05-s007-01,ch05-s008-01	AI题目生成	t	t	2026-06-01 15:06:43.431808+00	2026-06-01 15:06:43.431808+00	f	verified	0	0	0	0	0	0
405	6	\N	\N	single_choice	easy	以下哪一项最准确地描述了指令系统（Instruction Set System）？	[{"key": "A", "text": "CPU能够执行的指令集合，是软件和硬件之间的接口"}, {"key": "B", "text": "CPU内部的寄存器集合"}, {"key": "C", "text": "操作系统内核提供的系统调用集合"}, {"key": "D", "text": "编译器支持的高级语言关键字集合"}]	{"answer": "A"}	[]	根据知识块，指令系统是一台计算机所有机器指令的集合，是程序员/编译器与硬件设计者之间的接口。选项B描述的是寄存器，选项C描述的是操作系统层，选项D描述的是编程语言层，均不符合指令系统的定义。	ai:model-draft;chunks=ch06-s001-01,ch06-s002-01,ch06-s003-01,ch06-s004-01,ch06-s005-01,ch06-s006-01,ch06-s007-01,ch06-s008-01	AI题目生成	t	t	2026-06-01 15:06:49.164868+00	2026-06-01 15:06:49.164868+00	f	verified	0	0	0	0	0	0
406	6	\N	\N	single_choice	easy	一条机器指令通常包含以下哪些基本组成部分？	[{"key": "A", "text": "操作码、源操作数、目的操作数、下一条指令地址"}, {"key": "B", "text": "源程序行号、变量名、注释"}, {"key": "C", "text": "内存地址、硬盘扇区号、网络端口号"}, {"key": "D", "text": "CPU型号、主频、缓存大小"}]	{"answer": "A"}	[]	根据知识块，一条指令通常包含操作码、源操作数、目的操作数、下一条指令地址或隐含的PC更新规则。选项B是源代码的组成部分，选项C是系统资源地址，选项D是硬件参数，都不是指令本身的组成部分。	ai:model-draft;chunks=ch06-s001-01,ch06-s002-01,ch06-s003-01,ch06-s004-01,ch06-s005-01,ch06-s006-01,ch06-s007-01,ch06-s008-01	AI题目生成	t	t	2026-06-01 15:06:49.164868+00	2026-06-01 15:06:49.164868+00	f	verified	0	0	0	0	0	0
407	6	\N	\N	multiple_choice	easy	下列寻址方式中，操作数通常在指令中或直接由指令字段给出有效地址的是哪些？（多选）	[{"key": "A", "text": "立即寻址"}, {"key": "B", "text": "直接寻址"}, {"key": "C", "text": "寄存器寻址"}, {"key": "D", "text": "间接寻址"}]	{"answer": ["A", "B"]}	[]	根据知识块，立即寻址是操作数直接在指令中；直接寻址是地址字段给出有效地址。寄存器寻址的操作数在寄存器中，地址字段给出寄存器编号；间接寻址的地址字段指向存放有效地址的单元，有效地址不在指令本身。	ai:model-draft;chunks=ch06-s001-01,ch06-s002-01,ch06-s003-01,ch06-s004-01,ch06-s005-01,ch06-s006-01,ch06-s007-01,ch06-s008-01	AI题目生成	t	t	2026-06-01 15:06:49.164868+00	2026-06-01 15:06:49.164868+00	f	verified	0	0	0	0	0	0
409	6	\N	\N	single_choice	easy	以下关于ISA（指令集体系结构）的描述，哪一项是正确的？	[{"key": "A", "text": "ISA规定了处理器支持的指令集合、寄存器、数据类型、寻址方式等程序可见部分"}, {"key": "B", "text": "ISA规定了CPU内部的电路设计，如ALU的位数和流水线级数"}, {"key": "C", "text": "不同的ISA必须对应不同的微体系结构实现"}, {"key": "D", "text": "ISA只包含指令操作码的二进制编码规则"}]	{"answer": "A"}	[]	根据知识块，ISA规定处理器支持的指令集合、寄存器、数据类型、寻址方式、存储空间等程序可见部分。它不规定内部电路设计（B错误）；同一ISA可以有不同微体系结构实现（C错误）；ISA的内容远不止操作码编码（D错误）。	ai:model-draft;chunks=ch06-s001-01,ch06-s002-01,ch06-s003-01,ch06-s004-01,ch06-s005-01,ch06-s006-01,ch06-s007-01,ch06-s008-01	AI题目生成	t	t	2026-06-01 15:06:49.164868+00	2026-06-01 15:06:49.164868+00	f	verified	0	0	0	0	0	0
410	6	\N	\N	fill_blank	medium	某台计算机所有机器指令的集合称为______，它是软件和硬件之间的接口。而______规定了处理器支持的指令集合、寄存器、数据类型、寻址方式等程序可见部分。	[]	{"blanks": [{"index": 1, "answer": "指令系统", "acceptable_answers": ["指令集"]}, {"index": 2, "answer": "ISA", "acceptable_answers": ["指令集体系结构", "指令系统结构"]}]}	[]	根据知识块[ch06-s002-01]和[ch06-s004-01]，指令系统是某台计算机所有机器指令的集合，是软硬件交界面。ISA（指令集体系结构）则规定了处理器支持的指令集合、寄存器、数据类型、寻址方式等程序可见部分，是更抽象的规范。	ai:model-draft;chunks=ch06-s001-01,ch06-s002-01,ch06-s003-01,ch06-s004-01,ch06-s005-01,ch06-s006-01,ch06-s007-01,ch06-s008-01	AI题目生成	t	t	2026-06-01 15:06:49.164868+00	2026-06-01 15:06:49.164868+00	f	verified	0	0	0	0	0	0
411	6	\N	\N	short_answer	medium	一条机器指令通常包含哪些基本信息？请根据指令信息的核心内容简述。	[]	{"reference_answer": "一条机器指令通常包含以下基本信息：1. 操作码，用于说明指令要执行的操作；2. 源操作数，说明操作数的来源；3. 目的操作数，说明操作结果的存放位置；4. 下一条指令地址或隐含的PC更新规则，用于控制程序执行流程。"}	["答出操作码及其作用", "答出源操作数和目的操作数", "答出下一条指令地址或PC更新规则"]	根据知识块[ch06-s003-01]，指令信息的核心是操作码（做什么）、地址码或寄存器字段（对谁做），以及隐含或显式的下一条指令地址信息。此题覆盖了指令信息的基本组成部分。	ai:model-draft;chunks=ch06-s001-01,ch06-s002-01,ch06-s003-01,ch06-s004-01,ch06-s005-01,ch06-s006-01,ch06-s007-01,ch06-s008-01	AI题目生成	t	t	2026-06-01 15:06:49.164868+00	2026-06-01 15:06:49.164868+00	f	verified	0	0	0	0	0	0
412	6	\N	\N	short_answer	medium	从指令设计、格式、译码复杂度、与流水线的关系等方面，简述RISC指令系统的典型特点。	[]	{"reference_answer": "RISC指令系统的典型特点包括：1. 指令设计简单，功能单一；2. 指令格式规整，长度固定；3. 采用Load/Store结构，只有Load和Store指令访问内存；4. 寻址方式较少；5. 译码相对简单；6. 适合流水线实现，有利于提高主频。"}	["答出指令简单、格式规整", "答出Load/Store结构", "答出译码简单、适合流水线"]	根据知识块[ch06-s006-01]，RISC指令简单、格式规整、Load/Store结构明显，适合流水线和高频实现。这些特点与CISC形成对比，是RISC设计哲学的核心。	ai:model-draft;chunks=ch06-s001-01,ch06-s002-01,ch06-s003-01,ch06-s004-01,ch06-s005-01,ch06-s006-01,ch06-s007-01,ch06-s008-01	AI题目生成	t	t	2026-06-01 15:06:49.164868+00	2026-06-01 15:06:49.164868+00	f	verified	0	0	0	0	0	0
413	6	\N	\N	fill_blank	medium	______寻址方式下，操作数直接包含在指令中，其优点是速度快，但操作数范围受指令格式中的地址字段限制。常用于数组访问和程序重定位的寻址方式是______寻址。	[]	{"blanks": [{"index": 1, "answer": "立即", "acceptable_answers": ["立即数"]}, {"index": 2, "answer": "基址", "acceptable_answers": ["变址", "基址或变址"]}]}	[]	根据知识块[ch06-s005-01]，立即寻址的操作数直接在指令中，速度快但范围受字段限制。基址/变址/相对寻址常用于数组、程序重定位和分支跳转。此处第二空填写“基址”或“变址”均符合知识点描述。	ai:model-draft;chunks=ch06-s001-01,ch06-s002-01,ch06-s003-01,ch06-s004-01,ch06-s005-01,ch06-s006-01,ch06-s007-01,ch06-s008-01	AI题目生成	t	t	2026-06-01 15:06:49.164868+00	2026-06-01 15:06:49.164868+00	f	verified	0	0	0	0	0	0
414	6	\N	\N	short_answer	medium	指令集体系结构（ISA）在计算机系统中扮演什么角色？请解释其作为“软硬件接口”的具体含义。	[]	{"reference_answer": "ISA在计算机系统中扮演着定义处理器可见状态和行为的核心规范角色。作为“软硬件接口”，具体含义是：对软件设计者（程序员/编译器），ISA提供了一个抽象的机器模型，他们只需依据ISA规定来生成指令，无需关心底层硬件具体如何实现；对硬件设计者，ISA规定了必须实现的目标，即他们必须设计出能够正确执行ISA所定义的所有指令的硬件电路。同一ISA可以有不同的微体系结构实现（如单周期、流水线等）。"}	["答出ISA是定义处理器可见部分的规范", "解释对软件设计者的意义（抽象机器）", "解释对硬件设计者的意义（实现目标）", "提及同一ISA可有不同微体系结构实现（可选但加分）"]	根据知识块[ch06-s004-01]，ISA规定处理器支持的指令集合、寄存器、数据类型、寻址方式、存储空间、异常和中断等程序可见部分。它给软件设计者提供抽象机器，也给硬件设计者规定实现目标。同一ISA可以有不同微体系结构实现，这正是其作为接口的具体体现。	ai:model-draft;chunks=ch06-s001-01,ch06-s002-01,ch06-s003-01,ch06-s004-01,ch06-s005-01,ch06-s006-01,ch06-s007-01,ch06-s008-01	AI题目生成	t	t	2026-06-01 15:06:49.164868+00	2026-06-01 15:06:49.164868+00	f	verified	0	0	0	0	0	0
415	7	\N	\N	single_choice	easy	下列哪一项不属于CPU的基本功能？	[{"key": "A", "text": "指令控制"}, {"key": "B", "text": "操作控制"}, {"key": "C", "text": "数据加工"}, {"key": "D", "text": "电源管理"}]	{"answer": "D"}	[]	根据知识块[ch07-s002-01]，CPU的基本功能包括指令控制、操作控制、时间控制和数据加工。电源管理不属于CPU的基本功能范畴，因此D选项不合适。	ai:model-draft;chunks=ch07-s001-01,ch07-s002-01,ch07-s003-01,ch07-s004-01,ch07-s005-01,ch07-s006-01,ch07-s007-01,ch07-s008-01	AI题目生成	t	t	2026-06-01 15:07:36.151489+00	2026-06-01 15:07:36.151489+00	f	verified	0	0	0	0	0	0
416	7	\N	\N	true_false	easy	硬布线控制器的主要优点是结构规整、易于修改，适合复杂指令系统。	[]	{"answer": "FALSE"}	[]	根据知识块[ch07-s006-01]和[ch07-s007-01]，硬布线控制器的优点是速度快，缺点是设计和修改困难；而微程序控制器的优点才是结构规整、易修改，适合复杂指令。因此该说法错误。	ai:model-draft;chunks=ch07-s001-01,ch07-s002-01,ch07-s003-01,ch07-s004-01,ch07-s005-01,ch07-s006-01,ch07-s007-01,ch07-s008-01	AI题目生成	t	t	2026-06-01 15:07:36.151489+00	2026-06-01 15:07:36.151489+00	f	verified	0	0	0	0	0	0
417	7	\N	\N	multiple_choice	easy	在指令执行过程中，以下哪些阶段是常见的？	[{"key": "A", "text": "取指阶段"}, {"key": "B", "text": "译码阶段"}, {"key": "C", "text": "执行阶段"}, {"key": "D", "text": "冷却阶段"}]	{"answer": ["A", "B", "C"]}	[]	根据知识块[ch07-s003-01]，指令执行过程包括取指阶段、译码阶段和执行阶段。冷却阶段不是指令执行的标准阶段，因此D选项不合适。	ai:model-draft;chunks=ch07-s001-01,ch07-s002-01,ch07-s003-01,ch07-s004-01,ch07-s005-01,ch07-s006-01,ch07-s007-01,ch07-s008-01	AI题目生成	t	t	2026-06-01 15:07:36.151489+00	2026-06-01 15:07:36.151489+00	f	verified	0	0	0	0	0	0
418	7	\N	\N	single_choice	easy	数据通路主要回答的问题是？	[{"key": "A", "text": "什么时候打开哪条通路"}, {"key": "B", "text": "数据从哪里来，到哪里去，中间经过什么部件"}, {"key": "C", "text": "指令的执行顺序"}, {"key": "D", "text": "微程序的编写规则"}]	{"answer": "B"}	[]	根据知识块[ch07-s004-01]，数据通路回答“数据从哪里来，到哪里去，中间经过什么部件”，而控制器回答“什么时候打开哪条通路，哪个部件执行什么操作”。A选项描述的是控制器的功能；C、D选项与数据通路的直接定义无关。	ai:model-draft;chunks=ch07-s001-01,ch07-s002-01,ch07-s003-01,ch07-s004-01,ch07-s005-01,ch07-s006-01,ch07-s007-01,ch07-s008-01	AI题目生成	t	t	2026-06-01 15:07:36.151489+00	2026-06-01 15:07:36.151489+00	f	verified	0	0	0	0	0	0
419	7	\N	\N	true_false	easy	在时序系统中，指令周期通常由多个机器周期组成，而每个机器周期又包含多个时钟周期。	[]	{"answer": "TRUE"}	[]	根据知识块[ch07-s005-01]，指令周期、机器周期、时钟周期存在层次关系：指令周期是完成一条指令的时间，通常由若干机器周期组成；机器周期对应一次相对完整的基本操作，通常由多个时钟周期组成。因此该说法正确。	ai:model-draft;chunks=ch07-s001-01,ch07-s002-01,ch07-s003-01,ch07-s004-01,ch07-s005-01,ch07-s006-01,ch07-s007-01,ch07-s008-01	AI题目生成	t	t	2026-06-01 15:07:36.151489+00	2026-06-01 15:07:36.151489+00	f	verified	0	0	0	0	0	0
420	7	\N	\N	fill_blank	medium	CPU的基本功能包括指令控制、操作控制、时间控制和______。其中，______负责产生完成各微操作所需的控制信号。	[]	{"blanks": [{"index": 1, "answer": "数据加工", "acceptable_answers": ["数据加工"]}, {"index": 2, "answer": "操作控制", "acceptable_answers": ["操作控制"]}]}	[]	根据知识块[ch07-s002-01]，CPU的四类基本控制是：指令控制、操作控制、时间控制和数据加工。其中，操作控制的功能是产生完成各微操作所需的控制信号。	ai:model-draft;chunks=ch07-s001-01,ch07-s002-01,ch07-s003-01,ch07-s004-01,ch07-s005-01,ch07-s006-01,ch07-s007-01,ch07-s008-01	AI题目生成	t	t	2026-06-01 15:07:36.151489+00	2026-06-01 15:07:36.151489+00	f	verified	0	0	0	0	0	0
421	7	\N	\N	short_answer	medium	请简述单周期CPU、多周期CPU和流水线CPU在指令执行方式上的主要区别。	[]	{"reference_answer": "单周期CPU：一条指令在一个较长的时钟周期内完成所有操作阶段（取指、译码、执行等）。\\n多周期CPU：将一条指令的执行过程拆分为多个较短的机器周期，每个周期完成一部分操作，指令需要多个时钟周期才能完成。\\n流水线CPU：将指令执行过程拆分为多个阶段（如IF, ID, EX, MEM, WB），并让多条指令的不同阶段重叠执行，从而提高整体吞吐率。"}	["正确说明单周期CPU的特点（一条指令一个长周期）。", "正确说明多周期CPU的特点（指令拆分为多个短周期）。", "正确说明流水线CPU的特点（指令执行阶段重叠）。", "对比清晰，概念准确。"]	根据知识块[ch07-s005-01]，指令执行的三种主要时序控制方式的区别在于如何处理指令周期和时钟周期的关系。单周期是一条指令一个周期；多周期是拆分为多个周期；流水线是让多条指令的阶段重叠执行。	ai:model-draft;chunks=ch07-s001-01,ch07-s002-01,ch07-s003-01,ch07-s004-01,ch07-s005-01,ch07-s006-01,ch07-s007-01,ch07-s008-01	AI题目生成	t	t	2026-06-01 15:07:36.151489+00	2026-06-01 15:07:36.151489+00	f	verified	0	0	0	0	0	0
422	7	\N	\N	short_answer	medium	对比硬布线控制器和微程序控制器的主要优缺点。	[]	{"reference_answer": "硬布线控制器：\\n优点：速度快，适合RISC和指令格式规整的处理器。\\n缺点：设计和修改困难，当指令系统复杂时，逻辑电路会非常庞大。\\n\\n微程序控制器：\\n优点：结构规整，容易修改和扩展指令集，适合复杂指令系统（CISC）。\\n缺点：速度通常慢于硬布线控制器，因为需要从控制存储器中读取微指令。"}	["正确列出硬布线控制器的优点（速度快）和缺点（设计修改难）。", "正确列出微程序控制器的优点（易修改、规整）和缺点（速度较慢）。", "能够指出各自的典型适用场景（RISC/CISC）。"]	根据知识块[ch07-s006-01]和[ch07-s007-01]，硬布线控制器由组合逻辑直接产生控制信号，因此速度快但不易修改；微程序控制器通过微程序产生控制信号，结构规整易于修改但速度相对较慢。	ai:model-draft;chunks=ch07-s001-01,ch07-s002-01,ch07-s003-01,ch07-s004-01,ch07-s005-01,ch07-s006-01,ch07-s007-01,ch07-s008-01	AI题目生成	t	t	2026-06-01 15:07:36.151489+00	2026-06-01 15:07:36.151489+00	f	verified	0	0	0	0	0	0
423	7	\N	\N	fill_blank	medium	数据通路由寄存器组、ALU、总线、多路选择器等部件组成，它负责解决“数据从哪里来、到哪里去、经过什么部件”的问题。而控制器负责解决“什么时候打开哪条通路、哪个部件执行什么操作”的问题。二者共同构成______的核心。	[]	{"blanks": [{"index": 1, "answer": "CPU", "acceptable_answers": ["CPU", "中央处理器", "中央处理单元"]}]}	[]	根据知识块[ch07-s004-01]和[ch07-s008-01]，数据通路和控制器是CPU的两大组成部分，它们共同构成CPU的核心。数据通路提供数据路径和功能部件，控制器产生控制信号来协调操作。	ai:model-draft;chunks=ch07-s001-01,ch07-s002-01,ch07-s003-01,ch07-s004-01,ch07-s005-01,ch07-s006-01,ch07-s007-01,ch07-s008-01	AI题目生成	t	t	2026-06-01 15:07:36.151489+00	2026-06-01 15:07:36.151489+00	f	verified	0	0	0	0	0	0
424	7	\N	\N	short_answer	medium	在一条指令的取指阶段（IF），哪些主要部件参与工作？请简述它们的作用。	[]	{"reference_answer": "在取指阶段，主要参与的部件及其作用如下：\\n1. 程序计数器（PC）：提供当前要执行指令的内存地址。\\n2. 存储器接口/地址总线：将PC中的地址送到存储器。\\n3. 存储器：根据地址取出指令内容。\\n4. 指令寄存器（IR）：暂存从存储器中取出的指令。\\n5. PC更新逻辑：在指令取出后，将PC更新为下一条指令的地址（通常是PC+1或PC+指令长度）。"}	["指出PC提供指令地址。", "指出指令从存储器取出并送入IR。", "指出PC需要更新。", "涉及存储器接口或总线（数据通路的一部分）。"]	根据知识块[ch07-s003-01]，取指阶段是PC给出地址、从存储器取出指令送入IR并更新PC的过程。这描述了数据在CPU内部和存储器之间的流动，体现了数据通路和控制器的协作。	ai:model-draft;chunks=ch07-s001-01,ch07-s002-01,ch07-s003-01,ch07-s004-01,ch07-s005-01,ch07-s006-01,ch07-s007-01,ch07-s008-01	AI题目生成	t	t	2026-06-01 15:07:36.151489+00	2026-06-01 15:07:36.151489+00	f	verified	0	0	0	0	0	0
425	7	\N	\N	single_choice	medium	根据知识块，关于控制器的主要职责，以下描述最准确的是？	[{"key": "A", "text": "执行算术和逻辑运算"}, {"key": "B", "text": "根据指令、状态和时序产生控制信号，驱动CPU各阶段工作"}, {"key": "C", "text": "存储当前正在执行的指令"}, {"key": "D", "text": "决定程序中下一条要执行的指令地址"}]	{"answer": "B"}	[]	根据知识块，控制器的主要功能是根据指令、状态和时序产生控制信号，驱动取指、译码、执行、访存、写回等操作，而不是直接执行运算（A）、存储指令（C，这是IR的功能）或决定下一条指令地址（D，这是PC的功能，但属于指令控制的一部分）。	ai:model-draft;chunks=ch07-s001-01,ch07-s002-01,ch07-s003-01,ch07-s004-01,ch07-s005-01,ch07-s006-01,ch07-s007-01,ch07-s008-01	AI题目生成	t	t	2026-06-01 15:07:36.151489+00	2026-06-01 15:07:36.151489+00	f	verified	0	0	0	0	0	0
426	7	\N	\N	multiple_choice	medium	CPU的四类基本控制功能包括哪些？	[{"key": "A", "text": "指令控制"}, {"key": "B", "text": "操作控制"}, {"key": "C", "text": "时间控制"}, {"key": "D", "text": "数据加工"}]	{"answer": ["A", "B", "C", "D"]}	[]	根据知识块“CPU四类基本控制：指令控制、操作控制、时间控制、数据加工”，这四项是CPU的基本功能。A、B、C、D均正确，缺少任何一项都不完整。	ai:model-draft;chunks=ch07-s001-01,ch07-s002-01,ch07-s003-01,ch07-s004-01,ch07-s005-01,ch07-s006-01,ch07-s007-01,ch07-s008-01	AI题目生成	t	t	2026-06-01 15:07:36.151489+00	2026-06-01 15:07:36.151489+00	f	verified	0	0	0	0	0	0
427	7	\N	\N	true_false	medium	在流水线CPU中，指令执行阶段通常被进一步拆分为IF、ID、EX、MEM、WB等阶段。	[]	{"answer": "TRUE"}	[]	根据知识块“在流水线中，执行阶段可进一步拆分为IF、ID、EX、MEM、WB等阶段”，该描述准确反映了流水线技术对指令执行过程的细分。	ai:model-draft;chunks=ch07-s001-01,ch07-s002-01,ch07-s003-01,ch07-s004-01,ch07-s005-01,ch07-s006-01,ch07-s007-01,ch07-s008-01	AI题目生成	t	t	2026-06-01 15:07:36.151489+00	2026-06-01 15:07:36.151489+00	f	verified	0	0	0	0	0	0
428	7	\N	\N	single_choice	medium	关于硬布线控制器和微程序控制器的对比，以下说法正确的是？	[{"key": "A", "text": "硬布线控制器速度慢，但易于修改和扩展指令集"}, {"key": "B", "text": "微程序控制器速度快，设计简单，适合复杂指令集"}, {"key": "C", "text": "硬布线控制器由组合逻辑和时序逻辑直接产生控制信号，速度快但修改困难"}, {"key": "D", "text": "微程序控制器将控制信号编码成微指令，速度通常快于硬布线控制"}]	{"answer": "C"}	[]	根据知识块，硬布线控制器由组合逻辑和时序逻辑直接产生控制信号，优点是速度快，缺点是设计和修改困难（C正确）。A错误，因为硬布线速度快但不易修改。B错误，因为微程序控制器速度通常慢于硬布线。D错误，因为知识块指出微程序控制器缺点是速度通常慢于硬布线控制。	ai:model-draft;chunks=ch07-s001-01,ch07-s002-01,ch07-s003-01,ch07-s004-01,ch07-s005-01,ch07-s006-01,ch07-s007-01,ch07-s008-01	AI题目生成	t	t	2026-06-01 15:07:36.151489+00	2026-06-01 15:07:36.151489+00	f	verified	0	0	0	0	0	0
429	7	\N	\N	single_choice	medium	在时序系统中，通常将一次相对完整的基本操作（如取指、访存）对应的时间单位称为？	[{"key": "A", "text": "时钟周期"}, {"key": "B", "text": "机器周期"}, {"key": "C", "text": "指令周期"}, {"key": "D", "text": "CPU周期"}]	{"answer": "B"}	[]	根据知识块“机器周期通常对应一次相对完整的基本操作，如取指、访存等”，B正确。时钟周期是控制动作的基本节拍（A），是指令周期的更小单位。指令周期是一条指令从取指到执行完成所需时间（C），包含多个机器周期。CPU周期是机器周期的另一种称呼，但根据知识块明确表述，应选机器周期（B）。	ai:model-draft;chunks=ch07-s001-01,ch07-s002-01,ch07-s003-01,ch07-s004-01,ch07-s005-01,ch07-s006-01,ch07-s007-01,ch07-s008-01	AI题目生成	t	t	2026-06-01 15:07:36.151489+00	2026-06-01 15:07:36.151489+00	f	verified	0	0	0	0	0	0
430	7	\N	\N	fill_blank	hard	CPU的本质可被视为一个复杂的________。控制器与________共同构成CPU的核心，其中控制器负责产生控制信号，而________负责回答数据如何流动。	[]	{"blanks": [{"index": 1, "answer": "有限状态机", "acceptable_answers": ["状态机", "有限自动机"]}, {"index": 2, "answer": "数据通路", "acceptable_answers": []}, {"index": 3, "answer": "数据通路", "acceptable_answers": []}]}	[]	根据知识块[ch07-s002-01]，CPU本质是复杂的有限状态机。根据[ch07-s004-01]和[ch07-s008-01]，控制器+数据通路共同构成CPU核心，数据通路负责数据流动，控制器负责控制信号。	ai:model-draft;chunks=ch07-s001-01,ch07-s002-01,ch07-s003-01,ch07-s004-01,ch07-s005-01,ch07-s006-01,ch07-s007-01,ch07-s008-01	AI题目生成	t	t	2026-06-01 15:07:36.151489+00	2026-06-01 15:07:36.151489+00	f	verified	0	0	0	0	0	0
431	7	\N	\N	short_answer	hard	在指令周期的层次结构中，指令周期、机器周期和时钟周期有何区别与联系？请结合硬布线控制器和微程序控制器的特点，说明多周期CPU设计时，选择哪种控制器类型通常更易于实现指令执行阶段的划分。	[]	{"reference_answer": "指令周期是执行一条指令的全部时间，由若干机器周期组成。机器周期是CPU完成一个基本操作（如取指、访存）的时间，通常等于一个总线周期。时钟周期是CPU操作的最基本时间单位，一个机器周期包含若干时钟周期。多周期CPU将指令执行划分为多个机器周期，每个周期完成一个基本操作。\\n硬布线控制器由组合逻辑直接产生控制信号，速度快但设计复杂，修改困难，适合指令格式规整的RISC。微程序控制器将控制信号编码为微指令，存于控制存储器，一条机器指令对应一段微程序，结构规整、易于修改。\\n在多周期CPU设计中，选择微程序控制器通常更易于实现指令执行阶段的划分。因为微程序控制器通过顺序执行微指令来完成一条机器指令，而每条微指令对应一个时钟周期（或机器周期）内的一组微操作，这天然地支持将指令执行过程分解为多个顺序的微操作步骤，即多个机器周期，从而便于实现多周期设计。硬布线控制器虽也可实现，但其逻辑网络需精确对应各阶段，设计复杂度更高。"}	["正确解释指令周期、机器周期、时钟周期的定义与层次关系（包含关系）。", "正确说明硬布线控制器（速度快、难修改）和微程序控制器（规整、易修改）的核心特点。", "明确回答“微程序控制器更易于实现”，并给出理由（微指令顺序执行与多阶段划分的对应性）。"]	本题综合考查时序系统的层次和两种控制器的特点。根据知识块[ch07-s005-01]和[ch07-s008-01]，指令周期包含机器周期，机器周期包含时钟周期。根据[ch07-s006-01]和[ch07-s007-01]，硬布线控制器难改，微程序控制器易修改且通过微程序实现指令。微程序控制方式下，一条机器指令的执行过程就是顺序执行一段微程序，每条微指令在一个时钟周期内执行，这与多周期CPU将指令执行分解为多个步骤（机器周期）的思路一致，因此更易于实现划分。	ai:model-draft;chunks=ch07-s001-01,ch07-s002-01,ch07-s003-01,ch07-s004-01,ch07-s005-01,ch07-s006-01,ch07-s007-01,ch07-s008-01	AI题目生成	t	t	2026-06-01 15:07:36.151489+00	2026-06-01 15:07:36.151489+00	f	verified	0	0	0	0	0	0
439	7	\N	\N	single_choice	easy	与硬布线控制器相比，微程序控制器的主要优点是什么？	[{"key": "A", "text": "速度更快"}, {"key": "B", "text": "结构规整、易于修改"}, {"key": "C", "text": "设计更简单"}, {"key": "D", "text": "硬件逻辑更少"}]	{"answer": "B"}	[]	知识块 [ch07-s007-01] 指出微程序控制器的优点是‘结构规整、易修改、适合复杂指令’。而 [ch07-s006-01] 指出硬布线控制器的优点是速度快，但缺点是设计和修改困难。因此，选项A是硬布线控制器的优点，选项C和D不是知识块中提到的微程序控制器的主要优点。	ai:model-draft;chunks=ch07-s001-01,ch07-s002-01,ch07-s003-01,ch07-s004-01,ch07-s005-01,ch07-s006-01,ch07-s007-01,ch07-s008-01	AI题目生成	t	t	2026-06-01 15:07:36.151489+00	2026-06-01 15:07:36.151489+00	f	verified	0	0	0	0	0	0
432	7	\N	\N	fill_blank	hard	在CPU的指令执行过程中，取指阶段需要由________提供地址，从存储器取出指令送入________，同时________会更新。在流水线CPU中，执行阶段常被进一步拆分为IF、ID、EX、MEM和________五个阶段。	[]	{"blanks": [{"index": 1, "answer": "程序计数器", "acceptable_answers": ["PC", "程序计数器（PC）"]}, {"index": 2, "answer": "指令寄存器", "acceptable_answers": ["IR", "指令寄存器（IR）"]}, {"index": 3, "answer": "程序计数器", "acceptable_answers": ["PC", "程序计数器（PC）"]}, {"index": 4, "answer": "WB", "acceptable_answers": ["写回"]}]}	[]	根据知识块[ch07-s003-01]，取指阶段PC给出地址，取出指令送入IR，PC更新。流水线常拆分为IF（取指）、ID（译码）、EX（执行）、MEM（访存）、WB（写回）五个阶段。	ai:model-draft;chunks=ch07-s001-01,ch07-s002-01,ch07-s003-01,ch07-s004-01,ch07-s005-01,ch07-s006-01,ch07-s007-01,ch07-s008-01	AI题目生成	t	t	2026-06-01 15:07:36.151489+00	2026-06-01 15:07:36.151489+00	f	verified	0	0	0	0	0	0
433	7	\N	\N	short_answer	hard	请解释CPU的“操作控制”功能与“数据通路”和“硬布线控制器”之间的关系。	[]	{"reference_answer": "CPU的“操作控制”功能是指产生完成各微操作所需的控制信号。这些控制信号作用于“数据通路”，控制数据通路中的多路选择器、ALU、寄存器等部件的通断和操作，从而决定数据从哪里来、经过什么部件、到哪里去。而“硬布线控制器”是实现“操作控制”功能的一种具体物理结构，它由组合逻辑和时序逻辑电路直接生成这些控制信号。因此，“操作控制”是CPU的功能需求，“数据通路”是执行操作的对象，“硬布线控制器”是实现该功能的一种硬件设计方案。"}	["明确“操作控制”是产生控制信号的功能。", "说明控制信号的作用对象是数据通路（控制数据流动）。", "指出硬布线控制器是实现操作控制功能的一种具体硬件结构（产生控制信号）。"]	根据知识块，[ch07-s002-01]定义了CPU的“操作控制”功能是产生控制信号。[ch07-s004-01]指出数据通路回答“数据如何流动”，控制器（包括硬布线控制器）回答“什么时候打开哪条通路”。[ch07-s006-01]说明硬布线控制器直接产生控制信号。本题旨在考查对这三者功能角色的理解，而非孤立记忆。	ai:model-draft;chunks=ch07-s001-01,ch07-s002-01,ch07-s003-01,ch07-s004-01,ch07-s005-01,ch07-s006-01,ch07-s007-01,ch07-s008-01	AI题目生成	t	t	2026-06-01 15:07:36.151489+00	2026-06-01 15:07:36.151489+00	f	verified	0	0	0	0	0	0
434	7	\N	\N	fill_blank	hard	微程序控制器将控制信号编码成________，由多条这样的指令组成________，存储在________中。一条机器指令的执行对应一段这样的程序。	[]	{"blanks": [{"index": 1, "answer": "微指令", "acceptable_answers": []}, {"index": 2, "answer": "微程序", "acceptable_answers": []}, {"index": 3, "answer": "控制存储器", "acceptable_answers": ["控存"]}]}	[]	根据知识块[ch07-s007-01]，微程序控制把控制信号编码成微指令，微指令组成微程序，存储在控制存储器（控存）中。一条机器指令对应一段微程序。	ai:model-draft;chunks=ch07-s001-01,ch07-s002-01,ch07-s003-01,ch07-s004-01,ch07-s005-01,ch07-s006-01,ch07-s007-01,ch07-s008-01	AI题目生成	t	t	2026-06-01 15:07:36.151489+00	2026-06-01 15:07:36.151489+00	f	verified	0	0	0	0	0	0
435	7	\N	\N	single_choice	easy	根据知识块，CPU的本质被描述为什么？	[{"key": "A", "text": "一个复杂的算术逻辑单元"}, {"key": "B", "text": "一个复杂的有限状态机"}, {"key": "C", "text": "一个高速缓存控制器"}, {"key": "D", "text": "一个存储程序的部件"}]	{"answer": "B"}	[]	知识块 [ch07-s002-01] 明确指出‘CPU从本质上看是一个复杂的有限状态机’。选项A描述的是ALU，选项C描述的是缓存控制器，选项D描述的是存储器，这些都不是CPU的本质定义。	ai:model-draft;chunks=ch07-s001-01,ch07-s002-01,ch07-s003-01,ch07-s004-01,ch07-s005-01,ch07-s006-01,ch07-s007-01,ch07-s008-01	AI题目生成	t	t	2026-06-01 15:07:36.151489+00	2026-06-01 15:07:36.151489+00	f	verified	0	0	0	0	0	0
436	7	\N	\N	multiple_choice	easy	指令执行过程通常包括哪些基本阶段？（知识块中明确提到的）	[{"key": "A", "text": "取指阶段"}, {"key": "B", "text": "译码阶段"}, {"key": "C", "text": "执行阶段"}, {"key": "D", "text": "写回阶段"}]	{"answer": ["A", "B", "C"]}	[]	知识块 [ch07-s003-01] 明确指出‘指令执行过程：取指阶段、译码阶段、执行阶段’。虽然在流水线中执行阶段可进一步拆分为包括写回（WB）在内的阶段，但知识块在描述指令执行过程时，基本阶段是取指、译码、执行。因此D选项不属于知识块中列出的基本阶段。	ai:model-draft;chunks=ch07-s001-01,ch07-s002-01,ch07-s003-01,ch07-s004-01,ch07-s005-01,ch07-s006-01,ch07-s007-01,ch07-s008-01	AI题目生成	t	t	2026-06-01 15:07:36.151489+00	2026-06-01 15:07:36.151489+00	f	verified	0	0	0	0	0	0
437	7	\N	\N	true_false	easy	控制器的功能是决定数据通路中的数据从哪里来、到哪里去、中间经过什么部件。	[]	{"answer": "FALSE"}	[]	知识块 [ch07-s004-01] 明确指出：‘数据通路回答“数据从哪里来，到哪里去，中间经过什么部件”。控制器回答“什么时候打开哪条通路，哪个部件执行什么操作”’。题干描述的是数据通路的功能，而非控制器的功能。	ai:model-draft;chunks=ch07-s001-01,ch07-s002-01,ch07-s003-01,ch07-s004-01,ch07-s005-01,ch07-s006-01,ch07-s007-01,ch07-s008-01	AI题目生成	t	t	2026-06-01 15:07:36.151489+00	2026-06-01 15:07:36.151489+00	f	verified	0	0	0	0	0	0
438	7	\N	\N	single_choice	easy	关于指令周期、机器周期和时钟周期的层次关系，以下描述正确的是？	[{"key": "A", "text": "指令周期由若干机器周期组成，每个机器周期由若干时钟周期组成"}, {"key": "B", "text": "时钟周期由若干机器周期组成，每个机器周期由若干指令周期组成"}, {"key": "C", "text": "机器周期由若干指令周期组成，每个指令周期由若干时钟周期组成"}, {"key": "D", "text": "指令周期、机器周期和时钟周期是同一层次的概念"}]	{"answer": "A"}	[]	知识块 [ch07-s005-01] 明确指出：‘时钟周期是控制动作的基本节拍。机器周期通常对应一次相对完整的基本操作。指令周期是一条指令从取指到执行完成所需时间。’ 这隐含了指令周期最长，包含多个机器周期，而每个机器周期又包含多个时钟周期的层次关系。选项B、C、D颠倒或混淆了这种层次。	ai:model-draft;chunks=ch07-s001-01,ch07-s002-01,ch07-s003-01,ch07-s004-01,ch07-s005-01,ch07-s006-01,ch07-s007-01,ch07-s008-01	AI题目生成	t	t	2026-06-01 15:07:36.151489+00	2026-06-01 15:07:36.151489+00	f	verified	0	0	0	0	0	0
440	8	\N	\N	single_choice	easy	根据知识块，RISC-V模型机控制单元设计的主要依据是什么？	[{"key": "A", "text": "指令的操作码（opcode）、功能码（funct3, funct7）等字段"}, {"key": "B", "text": "程序计数器（PC）的值"}, {"key": "C", "text": "数据存储器的地址"}, {"key": "D", "text": "寄存器堆中读出的数据"}]	{"answer": "A"}	[]	根据知识块[ch08-s006-01]，控制单元根据opcode、funct3、funct7等字段产生控制信号。选项B、C、D是数据通路中的数据或地址信息，但不是控制单元产生控制信号的主要依据。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
441	8	\N	\N	true_false	easy	RISC-V的B型指令格式主要用于无条件跳转（jal）。	[]	{"answer": "FALSE"}	[]	根据知识块[ch08-s002-01]，B型指令用于条件分支，例如beq。J型指令才用于跳转（如jal）。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
442	8	\N	\N	multiple_choice	easy	在RISC-V模型机中，执行一条load指令（如lw）时，数据通路可能涉及哪些步骤？（多选）	[{"key": "A", "text": "读取rs1寄存器的值"}, {"key": "B", "text": "将立即数进行符号扩展"}, {"key": "C", "text": "ALU计算有效地址（rs1 + 符号扩展后的立即数）"}, {"key": "D", "text": "将计算得到的地址写回rd寄存器"}]	{"answer": ["A", "B", "C"]}	[]	根据知识块[ch08-s004-01]，load指令的数据通路是：rs1 + 符号扩展立即数得到有效地址 -> 读数据存储器 -> 写回rd。选项A、B、C是计算有效地址所必需的步骤。选项D错误，因为写回rd的是从数据存储器读出的数据，而不是地址本身。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
443	8	\N	\N	single_choice	easy	RISC-V中，条件分支指令（如beq）在条件满足时，如何更新程序计数器（PC）？	[{"key": "A", "text": "PC = PC + 4"}, {"key": "B", "text": "PC = PC + 分支偏移量"}, {"key": "C", "text": "PC = rs1 + offset"}, {"key": "D", "text": "PC = 目标地址（来自指令中的立即数）"}]	{"answer": "B"}	[]	根据知识块[ch08-s005-01]，条件分支如beq：若满足条件，则PC = PC + 分支偏移；否则PC = PC + 4。选项A是条件不满足时的更新方式。选项C是jalr指令更新PC的一种方式。选项D描述不准确，条件分支的偏移量来自指令编码，但计算方式是PC相对寻址。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
444	8	\N	\N	true_false	easy	RISC-V的Load/Store体系结构意味着所有指令都可以直接访问主存储器进行读写操作。	[]	{"answer": "FALSE"}	[]	根据知识块[ch08-s004-01]，访存类指令体现RISC的Load/Store思想：只有load/store直接访问存储器，普通运算在寄存器之间进行。因此，并非所有指令都能直接访问存储器。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
445	8	\N	\N	fill_blank	medium	RISC-V模型机的目标指令集通常选取RV32I的核心子集，其典型指令格式包括R型、I型、S型、____型、____型和J型。	[]	{"blanks": [{"index": 1, "answer": "B", "acceptable_answers": ["B型"]}, {"index": 2, "answer": "U", "acceptable_answers": ["U型"]}]}	[]	根据知识块[02]，RV32I核心指令子集的典型格式包括R型、I型、S型、B型、U型、J型。因此答案是B型和U型。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
446	8	\N	\N	short_answer	medium	简述在RISC-V模型机中，R型指令（如add）和I型立即数指令（如addi）在数据通路操作上的主要区别。	[]	{"reference_answer": "R型指令需要读取两个源寄存器（rs1和rs2），其操作数均来自寄存器堆；而I型立即数指令只读取一个源寄存器（rs1），另一个操作数是经过符号扩展的立即数。"}	["指出R型指令读取rs1和rs2两个寄存器", "指出I型立即数指令读取rs1和使用符号扩展的立即数", "明确两者操作数来源不同"]	根据知识块[03]，R型指令数据通路是读rs1和rs2，I型立即数指令数据通路是读rs1和立即数符号扩展。两者核心区别在于ALU第二个操作数的来源不同：一个来自寄存器，一个来自立即数。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
447	8	\N	\N	short_answer	medium	RISC架构强调Load/Store思想。结合RISC-V模型机的访存指令数据通路，解释这一思想的含义。	[]	{"reference_answer": "Load/Store思想是指只有load（加载）和store（存储）指令可以直接访问数据存储器，而所有算术逻辑运算指令的操作数都来自寄存器，结果也写回寄存器。在数据通路中，load指令通过计算地址并读取存储器数据，store指令通过计算地址将寄存器数据写入存储器，其他运算指令（如add、addi）则在寄存器之间或寄存器与立即数之间进行运算，不涉及对数据存储器的直接读写。"}	["明确只有load/store指令直接访存", "说明其他运算指令在寄存器间进行", "结合数据通路（如地址计算、读写存储器）进行说明"]	根据知识块[04]，load/store指令的数据通路体现了Load/Store思想：只有它们直接访问数据存储器（计算地址、读/写），而普通运算在寄存器之间进行。这简化了指令集和数据通路设计。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
457	8	\N	\N	true_false	easy	根据 RISC-V 的 Load/Store 体系结构思想，所有的算术逻辑运算指令（如 add, sub）都可以直接访问数据存储器进行读写操作。	[]	{"answer": "FALSE"}	[]	根据知识块 [ch08-s004-01]，访存类指令体现 RISC 的 Load/Store 思想：只有 load/store 指令直接访问存储器，而普通的算术逻辑运算在寄存器之间进行。因此，add、sub 等运算指令不能直接访问存储器。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
448	8	\N	\N	calculation	medium	在RISC-V模型机中，执行一条beq指令进行条件分支判断。已知：当前PC值为0x1000，rs1和rs2中的内容相等（满足分支条件），该beq指令的立即数字段经符号扩展后得到的偏移量为-40。计算分支跳转成功后的新PC值（用十六进制表示）。	[]	{"reference_answer": "0x0FD8"}	["正确应用公式：新PC = PC + 偏移量", "将十进制偏移量-40转换为十六进制（0xFFFFFFD8或直接计算）", "执行正确的加法运算（0x1000 + (-40)）", "结果正确且为十六进制"]	根据知识块[05]，条件分支指令beq，若条件满足，则PC = PC + 分支偏移量。当前PC=0x1000，偏移量=-40（即0xFFFFFFD8）。计算：0x1000 + (-40) = 0x1000 - 40。0x1000(十进制4096) - 40 = 4056。4056转换为十六进制：4056 ÷ 16 = 253余8 (0x8)，253 ÷ 16 = 15余13 (0xD)，15 ÷ 16 = 0余15 (0xF)，结果为0x0FD8。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
449	8	\N	\N	fill_blank	medium	在RISC-V模型机的硬布线控制单元中，控制信号主要由指令中的____、funct3和funct7等字段译码产生。	[]	{"blanks": [{"index": 1, "answer": "opcode", "acceptable_answers": ["操作码"]}]}	[]	根据知识块[06]，控制单元根据opcode、funct3、funct7等字段产生控制信号。opcode是区分不同指令类型（如R型、I型等）的关键字段，是译码的首要依据。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
450	8	\N	\N	single_choice	medium	在RISC-V模型机中，用于将一个12位立即数加到寄存器并写回结果的指令，其指令格式最可能是？	[{"key": "A", "text": "R型"}, {"key": "B", "text": "I型"}, {"key": "C", "text": "S型"}, {"key": "D", "text": "B型"}]	{"answer": "B"}	[]	根据知识块[ch08-s002-01]，I型格式常用于立即数运算，例如addi、ori等指令。题干描述的“将一个12位立即数加到寄存器并写回结果”正是I型立即数运算指令的典型操作。R型用于寄存器-寄存器运算，S型用于store，B型用于条件分支，均不符合描述。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
451	8	\N	\N	true_false	medium	RISC-V模型机中，load指令执行时，数据存储器读出的数据直接写回源寄存器rs1。	[]	{"answer": "FALSE"}	[]	根据知识块[ch08-s004-01]，load指令的执行流程是：rs1 + 符号扩展立即数得到有效地址 -> 读数据存储器 -> 写回rd（目的寄存器）。数据是写回rd，而不是源寄存器rs1。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
452	8	\N	\N	multiple_choice	medium	在RISC-V模型机的控制单元设计中，以下哪些是常见的控制信号？	[{"key": "A", "text": "寄存器写使能"}, {"key": "B", "text": "ALU操作选择"}, {"key": "C", "text": "程序计数器（PC）选择"}, {"key": "D", "text": "缓存替换策略"}]	{"answer": ["A", "B", "C"]}	[]	根据知识块[ch08-s006-01]，常见控制信号包括寄存器写使能、ALU操作选择、PC选择等。缓存替换策略是存储系统层面的概念，不属于本章模型机控制单元设计的核心控制信号。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
453	8	\N	\N	single_choice	medium	RISC-V指令`jal rd, offset`执行完成后，寄存器rd中保存的值是？	[{"key": "A", "text": "分支目标地址"}, {"key": "B", "text": "当前指令地址（PC）"}, {"key": "C", "text": "当前指令地址加4（PC+4）"}, {"key": "D", "text": "零寄存器的值"}]	{"answer": "C"}	[]	根据知识块[ch08-s005-01]，jal指令的功能是保存返回地址PC+4到rd，并跳转到目标地址。因此，执行完成后，rd中保存的是PC+4，作为返回地址。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
454	8	\N	\N	single_choice	medium	与RISC-V模型机对比，ARM模型机设计常强调的一个特点是什么？	[{"key": "A", "text": "指令格式极简，只有R型一种"}, {"key": "B", "text": "强调嵌入式应用和高效指令执行"}, {"key": "C", "text": "完全采用微程序控制方式"}, {"key": "D", "text": "不支持条件执行"}]	{"answer": "B"}	[]	根据知识块[ch08-s007-01]，ARM模型机设计强调嵌入式应用和高效指令执行，常具有条件执行、灵活移位寻址等特点。RISC-V指令格式多样（如R、I、S等），并非只有R型（A错误）。硬布线控制适合RISC-V，但ARM不一定完全采用微程序（C错误）。ARM的一个特点正是条件执行（D错误）。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
455	8	\N	\N	single_choice	easy	根据课件，在 RISC-V 模型机设计中，用于将一个 20 位的立即数高位装入寄存器的指令属于以下哪种格式？	[{"key": "A", "text": "R 型"}, {"key": "B", "text": "I 型"}, {"key": "C", "text": "S 型"}, {"key": "D", "text": "U 型"}]	{"answer": "D"}	[]	根据知识块 [ch08-s002-01]，U 型格式用于高位立即数操作。典型指令如 `lui`，其功能正是将 20 位的高位立即数装入寄存器。R 型用于寄存器-寄存器运算，I 型用于立即数运算、load 等，S 型用于 store，均不符合题意。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
456	8	\N	\N	multiple_choice	easy	在 RISC-V 模型机中，执行 R 型指令（如 `add`）和 I 型立即数指令（如 `addi`）时，以下哪些部件或操作是它们共有的？	[{"key": "A", "text": "读取寄存器 rs1 的内容"}, {"key": "B", "text": "读取寄存器 rs2 的内容"}, {"key": "C", "text": "对立即数进行符号扩展"}, {"key": "D", "text": "使用 ALU 进行运算"}, {"key": "E", "text": "将结果写回寄存器 rd"}]	{"answer": ["A", "D", "E"]}	[]	根据知识块 [ch08-s003-01]，R 型指令需要读取 rs1 和 rs2，I 型立即数指令需要读取 rs1 和处理立即数（符号扩展）。两者都需要使用 ALU 进行运算，并将结果写回 rd。因此，共有操作是读 rs1、ALU 运算和写回 rd。选项 B 仅适用于 R 型指令，选项 C 仅适用于 I 型立即数指令。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
458	8	\N	\N	true_false	easy	在 RISC-V 模型机中，执行条件分支指令（如 `beq`）时，若条件不满足，则程序计数器 PC 的值更新为 PC+4。	[]	{"answer": "TRUE"}	[]	根据知识块 [ch08-s005-01]，对于条件分支指令（如 beq），若条件满足，则 PC = PC + 分支偏移；若条件不满足，则 PC = PC + 4。因此该说法正确。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
459	8	\N	\N	single_choice	easy	在 RISC-V 模型机的控制单元设计中，产生“寄存器写使能”、“ALU操作选择”等控制信号的主要依据是指令的哪些字段？	[{"key": "A", "text": "立即数字段"}, {"key": "B", "text": "寄存器编号字段 (rs1, rs2, rd)"}, {"key": "C", "text": "操作码字段 (opcode) 及功能码字段 (funct3, funct7)"}, {"key": "D", "text": "偏移地址字段"}]	{"answer": "C"}	[]	根据知识块 [ch08-s006-01]，控制单元根据指令的 opcode、funct3、funct7 等字段译码来产生各种控制信号。选项 A、B、D 中的字段虽然参与指令的执行（如提供操作数或地址），但不是控制信号产生的主要译码依据。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
460	8	\N	\N	fill_blank	medium	在RISC-V模型机中，执行一条R型算术指令（如add）时，数据通路的基本步骤是：读寄存器rs1和rs2，经过_____运算，最后将结果写回寄存器rd。	[]	{"blanks": [{"index": 1, "answer": "ALU", "acceptable_answers": ["算术逻辑单元", "Arithmetic Logic Unit"]}]}	[]	根据知识块[03]，R型指令的数据通路明确包含“读rs1和rs2 -> ALU运算 -> 写回rd”。ALU是执行算术和逻辑运算的核心部件，负责完成add、sub等操作。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
461	8	\N	\N	short_answer	medium	RISC-V的Load/Store架构思想在访存指令数据通路中是如何体现的？	[]	{"reference_answer": "RISC-V的Load/Store架构思想体现在：只有load和store指令可以直接访问数据存储器。load指令用于将存储器中的数据读入寄存器，store指令用于将寄存器中的数据写入存储器。其他所有算术逻辑和传送指令（如add, sub, addi, lui等）的操作数和结果都只在寄存器之间传送，不直接访问数据存储器。"}	["答出只有load/store指令直接访问存储器。", "答出load指令功能（从存储器读入寄存器）。", "答出store指令功能（从寄存器写入存储器）。", "答出其他指令（运算/传送）不直接访问存储器，操作在寄存器间进行。"]	根据知识块[04]，访存类指令体现RISC的Load/Store思想：只有load/store直接访问存储器，普通运算在寄存器之间进行。回答需要分别说明load、store的功能以及与其他指令的区别。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
462	8	\N	\N	short_answer	medium	RISC-V模型机的控制单元需要根据指令中的哪些关键字段来产生控制信号？	[]	{"reference_answer": "控制单元需要根据指令中的opcode（操作码）、funct3（功能码3）和funct7（功能码7）等字段来产生控制信号。这些字段共同指明了要执行的具体操作（如add、addi、beq等），从而控制数据通路中各部件（如ALU、寄存器堆、存储器等）的工作方式。"}	["答出opcode（操作码）字段。", "答出funct3字段。", "答出funct7字段。", "说明这些字段的作用是译码产生控制信号，以控制数据通路部件。"]	根据知识块[06]，控制单元根据opcode、funct3、funct7等字段产生控制信号。这些是指令格式中用于区分不同操作的关键编码位。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
463	8	\N	\N	fill_blank	medium	在RISC-V模型机中，执行条件分支指令（如beq）时，如果比较结果满足分支条件，下一条指令的地址PC将更新为_____。	[]	{"blanks": [{"index": 1, "answer": "PC + 分支偏移", "acceptable_answers": ["PC+分支偏移量", "当前PC值加上符号扩展后的分支偏移量"]}]}	[]	根据知识块[05]，条件分支如beq：比较rs1和rs2，若满足条件，则PC = PC + 分支偏移；否则PC = PC + 4。分支偏移量是指令中编码的、经过符号扩展的值。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
464	8	\N	\N	short_answer	medium	与RISC-V模型机相比，ARM模型机在指令格式和控制逻辑方面通常具有哪些可能影响数据通路复杂度的特点？（根据知识块内容回答）	[]	{"reference_answer": "根据知识块，ARM模型机具有强调嵌入式应用和高效指令执行的特点，常具有条件执行、灵活移位寻址等特点。这些特点（如每条指令可带条件码执行、操作数可先移位再运算）会影响指令格式的设计，并可能使控制逻辑和数据通路的设计相对于格式规整、指令简单的RISC-V更为复杂。"}	["答出ARM常具有条件执行特点。", "答出ARM常具有灵活移位寻址特点。", "说明这些特点会影响指令格式和控制逻辑。", "说明这可能使数据通路设计相对于RISC-V更复杂。"]	根据知识块[07]，ARM强调嵌入式应用和高效指令执行，常具有条件执行、灵活移位寻址等特点。与RISC-V对比时，重点看“指令格式和控制逻辑如何影响数据通路复杂度”。回答需结合给定特点并推导其对复杂度的影响。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
465	8	\N	\N	multiple_choice	medium	根据给定的知识块，RISC-V模型机目标指令集的核心子集（如RV32I）包含哪几种典型的指令格式？	[{"key": "A", "text": "R型、I型、S型、B型、U型、J型"}, {"key": "B", "text": "R型、I型、S型、D型、F型"}, {"key": "C", "text": "CISC型、RISC型"}, {"key": "D", "text": "单操作数、双操作数、三操作数"}]	{"answer": ["A"]}	[]	知识块明确指出典型格式包括R型、I型、S型、B型、U型、J型。选项B、C、D中的格式或分类在给定的知识块中没有提及，且不符合RV32I指令集标准。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
466	8	\N	\N	single_choice	medium	在RISC-V模型机中，U型指令（如lui）的主要功能是什么？	[{"key": "A", "text": "进行寄存器-寄存器的算术逻辑运算"}, {"key": "B", "text": "执行条件分支跳转"}, {"key": "C", "text": "将高位立即数装入寄存器"}, {"key": "D", "text": "访问数据存储器"}]	{"answer": "C"}	[]	根据知识块，U型指令用于高位立即数，具体例子lui是“立即数高位装入 -> 写回rd”。选项A是R型指令的功能，选项B是B型指令的功能，选项D是访存指令的功能。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
467	8	\N	\N	true_false	medium	在RISC-V模型机中，B型指令格式用于无条件跳转，J型指令格式用于条件分支。	[]	{"answer": "FALSE"}	[]	根据知识块，B型用于条件分支，J型用于跳转。题目描述将两者功能颠倒，因此是错误的。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
468	8	\N	\N	single_choice	medium	在RISC-V模型机的访存指令数据通路中，load指令（如lw）计算有效地址的操作是？	[{"key": "A", "text": "rs1 + rs2"}, {"key": "B", "text": "rs1 + 符号扩展立即数"}, {"key": "C", "text": "PC + 符号扩展立即数"}, {"key": "D", "text": "rd + 立即数"}]	{"answer": "B"}	[]	知识块明确说明：“load指令：rs1 + 符号扩展立即数得到有效地址”。选项A不符合I型load指令的格式，选项C是分支指令计算目标地址的方式之一，选项D在标准RV32I load指令中不适用。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
469	8	\N	\N	multiple_choice	medium	在RISC-V模型机硬布线控制单元设计中，控制信号的产生通常需要对指令的哪些字段进行译码？	[{"key": "A", "text": "opcode"}, {"key": "B", "text": "funct3"}, {"key": "C", "text": "funct7"}, {"key": "D", "text": "寄存器地址字段"}]	{"answer": ["A", "B", "C"]}	[]	知识块明确指出：“控制单元根据opcode、funct3、funct7等字段产生控制信号。”选项D（寄存器地址字段）用于寻址寄存器，但不是产生操作类型控制信号的译码依据。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
470	8	\N	\N	single_choice	easy	在RISC-V模型机设计中，用于实现条件分支（如beq）的指令格式是哪一种？	[{"key": "A", "text": "R型"}, {"key": "B", "text": "I型"}, {"key": "C", "text": "S型"}, {"key": "D", "text": "B型"}]	{"answer": "D"}	[]	根据知识块[ch08-s002-01]，B型用于条件分支。R型用于寄存器-寄存器运算，I型用于立即数运算、load等，S型用于store，均不符合条件分支的用途。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
471	8	\N	\N	single_choice	easy	在RISC-V的Load/Store架构中，下列哪类指令可以直接访问数据存储器进行数据读写？	[{"key": "A", "text": "算术逻辑指令（如add、sub）"}, {"key": "B", "text": "立即数运算指令（如addi）"}, {"key": "C", "text": "load指令和store指令"}, {"key": "D", "text": "所有指令都可以"}]	{"answer": "C"}	[]	根据知识块[ch08-s004-01]，访存类指令体现RISC的Load/Store思想：只有load/store直接访问存储器，普通运算在寄存器之间进行。因此A、B选项描述的指令运算均在寄存器间进行，不直接访存。D选项错误，因为只有load/store才直接访存。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
472	8	\N	\N	true_false	easy	在RISC-V的RV32I指令子集中，用于将一个32位立即数的高20位装入寄存器rd的指令（如lui）属于I型格式。	[]	{"answer": "FALSE"}	[]	根据知识块[ch08-s002-01]，U型用于高位立即数，lui等U型指令用于将立即数高位装入寄存器。I型用于立即数运算、load、jalr等。因此lui属于U型格式，而不是I型。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
473	8	\N	\N	multiple_choice	easy	在设计RISC-V模型机的控制单元时，产生控制信号通常需要依据指令中的哪些字段进行译码？	[{"key": "A", "text": "opcode"}, {"key": "B", "text": "funct3"}, {"key": "C", "text": "funct7"}, {"key": "D", "text": "寄存器编号（rs1, rs2, rd）"}]	{"answer": ["A", "B", "C"]}	[]	根据知识块[ch08-s006-01]，控制单元根据opcode、funct3、funct7等字段产生控制信号。寄存器编号（如rs1, rs2, rd）主要用于指定操作数来源和结果去向，是数据通路的一部分，但不是控制信号译码的主要依据（尽管某些控制逻辑可能间接相关，但题干问的是“通常需要依据”的字段，核心译码字段是opcode、funct3、funct7）。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
474	8	\N	\N	single_choice	easy	执行RISC-V的R型指令（如add rd, rs1, rs2）时，数据通路的操作顺序是怎样的？	[{"key": "A", "text": "读rs1和rs2 -> 立即数符号扩展 -> ALU运算 -> 写回rd"}, {"key": "B", "text": "读rs1和rs2 -> ALU运算 -> 写回rd"}, {"key": "C", "text": "读rs1 -> 立即数符号扩展 -> ALU运算 -> 写回rd"}, {"key": "D", "text": "读rs1和rs2 -> 访存 -> 写回rd"}]	{"answer": "B"}	[]	根据知识块[ch08-s003-01]，R型指令（如add、sub）的操作是：读rs1和rs2 -> ALU运算 -> 写回rd。A选项包含了“立即数符号扩展”，这是I型立即数指令的操作。C选项是I型立即数指令的操作。D选项包含了“访存”，这不是R型指令的操作，R型指令不访问存储器。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
42	6	\N	597	single_choice	medium	该计算机存储器是按照 编址的。	[{"key": "A", "text": "按照字节编址"}, {"key": "B", "text": "按照16位字编址"}, {"key": "C", "text": "按照32位字编址"}, {"key": "D", "text": "按照位编址"}]	{"answer": "B"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/02-第6章作业-2nd.txt#3.3	第6章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
475	8	\N	\N	fill_blank	medium	RISC-V模型机目标指令集选取了RV32I核心指令子集，其典型格式包括R型、I型、S型、B型、U型和______型。其中，用于条件分支的指令通常采用______型格式。	[]	{"blanks": [{"index": 1, "answer": "J", "acceptable_answers": ["J"]}, {"index": 2, "answer": "B", "acceptable_answers": ["B"]}]}	[]	根据知识块[ch08-s002-01]，RISC-V模型机目标指令集包含R、I、S、B、U、J型格式。其中，条件分支指令如beq采用B型格式。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
476	8	\N	\N	short_answer	medium	请分别简述RISC-V模型机中R型指令（如add）和load指令的数据通路主要步骤。	[]	{"reference_answer": "R型指令（如add）：读寄存器rs1和rs2 -> ALU进行运算 -> 将结果写回寄存器rd。\\nload指令：读寄存器rs1，并将立即数符号扩展 -> ALU计算有效地址（rs1 + 立即数） -> 从数据存储器读出数据 -> 将数据写回寄存器rd。"}	["正确描述R型指令的三个主要步骤：读寄存器、ALU运算、写回。", "正确描述load指令的四个主要步骤：读寄存器、地址计算、读存储器、写回。", "步骤描述准确，无混淆。"]	根据知识块[ch08-s003-01]和[ch08-s004-01]，R型指令数据通路为读rs1/rs2->ALU->写rd。load指令数据通路为算地址->读存储器->写rd。题目要求简述主要步骤，答案需准确对应。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
477	8	\N	\N	short_answer	medium	在RISC-V模型机中，条件分支指令（如beq）在满足条件时，PC如何更新？不满足条件时，PC又如何更新？	[]	{"reference_answer": "条件分支指令在满足比较条件时，PC更新为PC + 分支偏移（即PC + 偏移量）；不满足条件时，PC更新为PC + 4（指向下一条顺序指令）。"}	["正确说明满足条件时PC的更新方式（PC + 偏移）。", "正确说明不满足条件时PC的更新方式（PC + 4）。", "语言表述清晰，无歧义。"]	根据知识块[ch08-s005-01]，条件分支指令如beq，若满足条件则PC = PC + 分支偏移，否则PC = PC + 4。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
478	8	\N	\N	fill_blank	medium	RISC-V模型机的控制单元根据指令中的______、funct3和______等字段译码产生控制信号。常见的控制信号包括寄存器写使能、______、立即数类型选择、存储器读写使能等。	[]	{"blanks": [{"index": 1, "answer": "opcode", "acceptable_answers": ["opcode", "操作码"]}, {"index": 2, "answer": "funct7", "acceptable_answers": ["funct7"]}, {"index": 3, "answer": "ALU操作选择", "acceptable_answers": ["ALU操作选择", "ALU控制信号", "ALUOp"]}]}	[]	根据知识块[ch08-s006-01]和[ch08-s008-01]，控制单元根据opcode、funct3、funct7等字段译码产生控制信号。常见控制信号包括ALU操作选择。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
479	8	\N	\N	short_answer	medium	根据知识块，RISC-V模型机的设计主线是什么？请用一句话概括。	[]	{"reference_answer": "确定目标指令集 -> 确定系统结构 -> 设计数据通路 -> 分析各类指令执行流程 -> 设计控制单元。"}	["准确包含知识块中提到的五个关键阶段：确定目标指令集、确定系统结构、设计数据通路、分析指令执行流程、设计控制单元。", "表述顺序正确。"]	根据知识块[ch08-s001-01]，本章主线可压缩为：确定目标指令集 -> 确定系统结构 -> 设计数据通路 -> 分析各类指令执行流程 -> 设计控制单元。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
480	8	\N	\N	single_choice	medium	根据知识块，RISC-V模型机设计中，以下关于指令格式用途的描述，哪一项是正确的？	[{"key": "A", "text": "R型指令主要用于立即数运算，I型指令主要用于寄存器-寄存器运算。"}, {"key": "B", "text": "I型指令用于立即数运算和load指令，S型指令用于store指令。"}, {"key": "C", "text": "B型指令用于无条件跳转，J型指令用于条件分支。"}, {"key": "D", "text": "U型指令用于低位立即数装入，J型指令用于寄存器间接跳转。"}]	{"answer": "B"}	[]	根据知识块[08-s002-01]，R型多用于寄存器-寄存器运算，I型用于立即数运算、load、jalr等，S型用于store。因此B正确。A选项颠倒了R型和I型的主要用途。C选项中，B型用于条件分支，J型用于无条件跳转，描述相反。D选项中，U型用于高位立即数装入，jalr（I型）可用于寄存器间接跳转，描述错误。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
481	8	\N	\N	multiple_choice	medium	在RISC-V模型机数据通路中，执行以下哪些指令时，ALU的主要操作是计算一个存储器地址？	[{"key": "A", "text": "add"}, {"key": "B", "text": "lw"}, {"key": "C", "text": "sw"}, {"key": "D", "text": "beq"}]	{"answer": ["B", "C"]}	[]	根据知识块[08-s004-01]，load指令（如lw）和store指令（如sw）都需要计算有效地址（rs1 + 符号扩展立即数），此操作由ALU完成。add指令（[08-s003-01]）的ALU操作是加法运算，不计算地址。beq指令（[08-s005-01]）的ALU操作是比较，也不计算地址。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
482	8	\N	\N	true_false	medium	在RISC-V模型机中，执行`jal`指令时，会同时将返回地址`PC+4`写入目标寄存器`rd`，并计算跳转目标地址。	[]	{"answer": "TRUE"}	[]	根据知识块[08-s005-01]，jal指令的操作是：保存返回地址PC+4到rd，并跳转到目标地址。因此该描述正确。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
483	8	\N	\N	single_choice	medium	关于RISC-V模型机的控制单元设计，以下说法正确的是？	[{"key": "A", "text": "控制信号主要根据指令中的立即数字段译码产生。"}, {"key": "B", "text": "硬布线控制方式因其复杂性，不适用于RISC-V这类指令格式规整的模型机。"}, {"key": "C", "text": "控制单元根据opcode、funct3、funct7等字段产生控制信号。"}, {"key": "D", "text": "控制信号主要用于控制ALU的运算结果，与寄存器写使能和存储器读写无关。"}]	{"answer": "C"}	[]	根据知识块[08-s006-01]，控制单元根据opcode、funct3、funct7等字段产生控制信号，因此C正确。A错误，控制信号由指令的操作码等功能字段译码产生，而非立即数。B错误，知识块明确指出硬布线控制适合RISC-V这类格式规整、指令简单的模型机。D错误，控制信号包括寄存器写使能、ALU操作选择、存储器读写等多种信号。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
484	8	\N	\N	single_choice	medium	对比RISC-V和ARM模型机设计，以下哪一点是知识块中强调的对比重点？	[{"key": "A", "text": "ARM模型机必须使用微程序控制，而RISC-V模型机使用硬布线控制。"}, {"key": "B", "text": "ARM指令集比RISC-V指令集拥有更多的寻址模式。"}, {"key": "C", "text": "对比时重点看指令格式和控制逻辑如何影响数据通路复杂度。"}, {"key": "D", "text": "ARM模型机完全不包含条件执行和灵活移位寻址特点。"}]	{"answer": "C"}	[]	根据知识块[08-s007-01]，与RISC-V对比时，重点看“指令格式和控制逻辑如何影响数据通路复杂度”。因此C正确。A选项知识块未提及ARM必须使用微程序控制。B选项知识块未直接对比寻址模式数量。D选项与知识块描述的ARM特点（条件执行、灵活移位寻址）相悖。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
485	8	\N	\N	calculation	hard	假设一个RISC-V模型机执行以下指令序列，初始PC=0x0000_0000。请计算执行完`jal ra, offset`指令后，寄存器ra的值以及PC的值。\n\n地址  指令\n0x0000_0000: addi t0, zero, 10\n0x0000_0004: addi t1, zero, 20\n0x0000_0008: beq  t0, t1, 8\n0x0000_000C: addi t2, zero, 30\n0x0000_0010: jal  ra, -8\n\n注意：`jal ra, offset`指令的机器码中，偏移量`offset`字段（imm[20:1]）的值为`11111111111111111110`（二进制），请计算其有符号十进制值，并依此计算跳转目标地址。	[]	{"reference_answer": "ra的值为0x0000_0014，PC的值为0x0000_0008。\\n计算过程：\\n1. jal指令在执行时，其地址为0x0000_0010。根据RISC-V规范，jal指令将返回地址(PC+4)存入rd（此处为ra）。因此，ra = 0x0000_0010 + 4 = 0x0000_0014。\\n2. jal指令的偏移量字段`imm[20:1]`为`11111111111111111110`。这是一个20位的二进制数，最高位为1，表示负数。将其扩展为32位有符号整数：`11111111111111111111111111111110`（即-2的补码）。在计算目标地址时，这个值需要左移1位（乘以2），得到-4。\\n3. 跳转目标地址 = PC + 偏移量 = 0x0000_0010 + (-4) = 0x0000_0008。\\n因此，执行后ra=0x0000_0014，PC=0x0000_0008。"}	["正确计算并写出ra的值（0x0000_0014），占40%。", "正确解析二进制偏移量字段`11111111111111111110`为有符号十进制值（-2），并说明左移后为-4，占30%。", "正确计算跳转目标地址（0x0000_0008），占30%。"]	题目考察对jal指令数据通路的理解：一是保存返回地址PC+4到rd；二是计算跳转目标地址。jal指令的机器码格式中，偏移量是分段存储的，计算目标地址时需要将其符号扩展并左移1位。解析中给出了完整的计算步骤，确保答案唯一且基于RISC-V规范。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
486	8	\N	\N	short_answer	hard	在设计RISC-V模型机的硬布线控制单元时，需要为不同的指令类型产生正确的控制信号。请简述：\n1. 对于一条R型指令（如`add rd, rs1, rs2`），控制单元需要产生哪些关键控制信号（至少列出4个）来确保数据通路正确执行？\n2. 与ARM模型机相比，RISC-V指令格式规整（如opcode、funct3、funct7字段固定位置）对控制单元的设计带来了什么主要优势？	[]	{"reference_answer": "1. 对于R型指令`add rd, rs1, rs2`，关键控制信号包括：\\n   - 寄存器写使能（RegWrite）：置为有效，以允许将ALU结果写入rd。\\n   - ALU操作码（ALUOp）：设置为“加法”操作。\\n   - ALU源操作数选择（ALUSrc）：置为无效（或选择0），以指示ALU的第二个操作数来自寄存器rs2，而不是立即数。\\n   - 写回数据选择（MemtoReg）：置为无效（或选择0），以指示写回寄存器的数据来自ALU结果，而非存储器读出的数据。\\n   （其他合理答案如“分支信号无效”、“存储器写使能无效”等也可接受）\\n\\n2. RISC-V指令格式规整的主要优势是：控制逻辑的译码电路相对简单、规整，可以减少控制单元的复杂度和延迟。因为opcode、funct3、funct7等字段在机器码中的位置和位数是固定的，硬布线控制器可以直接通过这些固定字段的位组合来生成控制信号，而不需要复杂的逻辑来定位可变长度的字段。"}	["第一问：能正确列出至少4个针对R型指令的关键控制信号及其作用，描述准确。", "第二问：能准确指出RISC-V格式规整使得译码电路简单、规整，降低了控制单元复杂度和延迟。"]	第一问旨在检验对R型指令执行流程和所需控制信号的理解，这是控制单元设计的核心。第二问考察对RISC-V指令格式特点及其对硬件设计影响的理解，这是与ARM等指令集对比的一个关键点，符合知识块8.6和8.7的内容。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-01 15:09:35.80527+00	2026-06-01 15:09:35.80527+00	f	verified	0	0	0	0	0	0
487	9	\N	\N	single_choice	easy	外设不能直接与CPU相连进行数据交换，其根本原因是：	[{"key": "A", "text": "外设的种类和数量太多"}, {"key": "B", "text": "外设在数据格式、速度、时序和信号电平上与CPU不兼容"}, {"key": "C", "text": "CPU的指令集不支持外设操作"}, {"key": "D", "text": "外设不需要CPU的参与"}]	{"answer": "B"}	[]	根据知识块，外设不能直接与CPU兼容的原因包括数据格式、速度、逻辑时序和信号电平差异。选项A描述的是外设的特点，但不是不能直接连接的根本原因。选项C和D在知识块中没有提及，且不符合基本原理。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
488	9	\N	\N	multiple_choice	easy	一个典型的I/O接口电路通常包含哪些寄存器？	[{"key": "A", "text": "数据寄存器"}, {"key": "B", "text": "程序计数器"}, {"key": "C", "text": "状态寄存器"}, {"key": "D", "text": "控制寄存器"}]	{"answer": ["A", "C", "D"]}	[]	根据知识块，I/O接口通常包含数据寄存器、状态寄存器和控制寄存器。程序计数器是CPU内部用于指示下一条指令地址的寄存器，不属于I/O接口。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
489	9	\N	\N	true_false	easy	独立编址方式下，CPU必须使用专门的I/O指令来访问I/O端口。	[]	{"answer": "TRUE"}	[]	根据知识块，独立编址是指I/O端口有独立地址空间，需要专门I/O指令。而统一编址则使用普通访存指令。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
490	9	\N	\N	single_choice	easy	在以下数据交换方式中，CPU参与程度最高、效率通常最低的是：	[{"key": "A", "text": "程序查询方式"}, {"key": "B", "text": "中断方式"}, {"key": "C", "text": "DMA方式"}]	{"answer": "A"}	[]	根据知识块中的主线和比较，程序查询方式需要CPU不断查询外设状态，CPU参与程度最高，效率最低。中断方式在数据准备好后才通知CPU，CPU参与程度有所降低。DMA方式下，数据在主存和外设间直接传送，CPU只在开始和结束时参与，效率最高。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
491	9	\N	\N	true_false	easy	DMA方式在传送数据期间，CPU完全停止工作，直到数据块传送结束。	[]	{"answer": "FALSE"}	[]	根据知识块，DMA的常见传送方式有停止CPU访存、周期挪用和透明DMA。其中“停止CPU访存”方式会停止CPU对主存的访问，但CPU内部可能仍在工作；“周期挪用”方式CPU只是被暂停一个或几个存取周期；“透明DMA”方式CPU完全不感知。因此“完全停止工作”的说法过于绝对和不准确。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
492	9	\N	\N	fill_blank	medium	由于外设在速度、数据格式、逻辑时序和信号电平等方面与CPU存在差异，因此不能直接相连，需要通过______作为适配桥梁。	[]	{"blanks": [{"index": 1, "answer": "I/O接口", "acceptable_answers": ["I/O适配器", "输入输出接口"]}]}	[]	根据知识块[ch09-s002-01]和[ch09-s003-01]，外设因速度、格式、时序、电平等差异无法直接连接CPU，I/O接口（或称I/O适配器）正是解决这一问题的桥梁。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
493	9	\N	\N	short_answer	medium	I/O接口通常包含哪三种主要的寄存器？请分别简述其作用。	[]	{"reference_answer": "数据寄存器、状态寄存器、控制寄存器。\\n1. 数据寄存器：暂存CPU与外设交换的数据。\\n2. 状态寄存器：反映外设是否就绪、是否忙、是否出错等状态信息。\\n3. 控制寄存器：接收CPU发出的启动、停止、读写方式等控制命令。"}	["答出三种寄存器名称（每个1分）", "对每种寄存器的作用描述正确（每个1分）"]	根据知识块[ch09-s003-01]，I/O接口的核心寄存器包括数据、状态和控制寄存器，其作用如知识块所述。此题考查对这些基本结构的掌握。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
494	9	\N	\N	short_answer	medium	CPU访问I/O接口寄存器有哪两种编址方式？请简要说明它们的区别。	[]	{"reference_answer": "统一编址和独立编址。\\n1. 统一编址：I/O端口和主存储器共享同一个地址空间，使用访存指令即可访问端口。优点是编程统一。\\n2. 独立编址：I/O端口拥有独立的地址空间，需要使用专门的I/O指令（如IN/OUT）访问。优点是地址空间清晰、I/O语义明确。"}	["答出两种编址方式名称（每个1分）", "对每种编址方式的特点或区别描述正确（每个1-2分）"]	根据知识块[ch09-s004-01]，I/O端口的编址方式分为统一编址和独立编址，它们在地址空间、使用指令和编程特点上有明确区别。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
495	9	\N	\N	short_answer	medium	请简述中断系统在处理一个中断请求时，从请求到返回的主要步骤。	[]	{"reference_answer": "中断请求 -> 中断判优 -> 中断响应 -> 保护现场 -> 执行中断服务程序 -> 恢复现场 -> 中断返回。"}	["步骤完整、顺序正确（每个步骤1分，共7分）"]	根据知识块[ch09-s005-01]和[ch09-s007-01]，中断的标准过程包含这七个主要步骤。此题考查对中断流程的整体记忆和理解。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
496	9	\N	\N	short_answer	medium	DMA方式为什么能显著提高高速外设（如磁盘）与主存之间的数据传输效率？	[]	{"reference_answer": "因为DMA方式下，数据块传送由DMA控制器直接在主存和外设之间进行，无需CPU逐个字节地干预（CPU只在传送开始前进行初始化和传送结束后进行处理），从而释放了CPU，减少了CPU的介入开销，特别适合高速、大批量的数据传送。"}	["指出数据传送路径（外设<->主存）由DMA控制器直接控制（2分）", "指出CPU角色（初始化和结束处理，少参与）（2分）", "说明对效率提升的意义（释放CPU，减少开销）（1分）"]	根据知识块[ch09-s006-01]和[ch09-s008-01]，DMA的核心优势在于数据传送不经过CPU，实现了外设与主存的直接交换，CPU仅负责启动和结束处理，因此特别适合高速大块数据传输，效率高。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
497	9	\N	\N	multiple_choice	medium	根据知识块，I/O接口电路作为CPU与外设之间的桥梁，其主要功能包括（）。	[{"key": "A", "text": "暂存CPU与外设交换的数据"}, {"key": "B", "text": "进行数据格式转换、速度匹配和信号电平转换"}, {"key": "C", "text": "接收并保存CPU发出的控制命令"}, {"key": "D", "text": "直接执行CPU的指令以完成I/O操作"}, {"key": "E", "text": "提供反映外设工作状态的寄存器"}]	{"answer": ["A", "B", "C", "E"]}	[]	根据知识块，I/O接口包含数据寄存器（A）、电平转换（B）、控制寄存器（C）和状态寄存器（E）。选项D错误，因为接口是桥梁和适配器，不直接执行CPU指令，CPU指令的执行是在CPU内部完成的。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
498	9	\N	\N	single_choice	medium	关于I/O端口的统一编址和独立编址，以下描述正确的是（）。	[{"key": "A", "text": "统一编址需要专门的I/O指令来访问端口"}, {"key": "B", "text": "独立编址的I/O端口与内存共享同一个地址空间"}, {"key": "C", "text": "统一编址中，访问I/O端口和访问内存使用相同的指令"}, {"key": "D", "text": "独立编址的编程方式更统一，但地址空间不清晰"}]	{"answer": "C"}	[]	根据知识块，统一编址中I/O端口和内存统一在一个地址空间，用普通访存指令访问，因此C正确。A错误，统一编址不需要专门I/O指令。B错误，独立编址有独立地址空间。D错误，独立编址地址空间清晰，但编程不如统一编址统一。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
499	9	\N	\N	true_false	medium	中断系统中，中断屏蔽的作用是允许或禁止某些中断请求，可用于动态调整中断优先级。	[]	{"answer": "TRUE"}	[]	根据知识块，中断屏蔽用于允许或禁止某些中断请求。通过设置屏蔽字，可以动态改变中断源的优先级，实现优先级的动态调整，因此该说法正确。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
500	9	\N	\N	single_choice	medium	在DMA传送方式中，以下哪种方式会暂停CPU对主存的访问？	[{"key": "A", "text": "周期挪用"}, {"key": "B", "text": "停止CPU访存"}, {"key": "C", "text": "透明DMA"}, {"key": "D", "text": "CPU与DMA交替访问"}]	{"answer": "B"}	[]	根据知识块，DMA传送方式常见有停止CPU访存、周期挪用和透明DMA。其中，停止CPU访存方式下，DMA控制器获得总线控制权后，CPU完全停止访问主存，直到DMA传送结束。周期挪用是DMA利用CPU不访问主存的周期传送数据，并不暂停CPU整体访存。透明DMA是DMA在CPU访问主存的间隔中传送，对CPU透明。D选项在知识块中未提及。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
501	9	\N	\N	multiple_choice	medium	DMA控制器为了完成数据块传送，需要掌握的关键信息通常包括（）。	[{"key": "A", "text": "主存地址"}, {"key": "B", "text": "传送字数"}, {"key": "C", "text": "传送方向"}, {"key": "D", "text": "CPU的当前程序计数器值"}, {"key": "E", "text": "设备地址"}]	{"answer": ["A", "B", "C", "E"]}	[]	根据知识块，DMA控制器通常需要掌握主存地址（A）、传送字数（B）、传送方向（C）、设备地址（E）等信息。选项D错误，DMA传送期间CPU不参与数据传送，不需要知道CPU的程序计数器值，CPU只负责初始化和结束处理。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
502	9	\N	\N	fill_blank	hard	在I/O接口中，________寄存器用于反映外设是否就绪、是否忙或是否出错等状态信息，供CPU查询。	[]	{"blanks": [{"index": 1, "answer": "状态", "acceptable_answers": ["状态寄存器"]}]}	[]	根据知识块[09-s003-01]，I/O接口通常包含状态寄存器，其作用是反映外设是否就绪、是否忙、是否出错。数据寄存器暂存数据，控制寄存器接收CPU命令，地址译码、电平转换和控制逻辑不是寄存器。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
503	9	\N	\N	short_answer	hard	请简述为什么外设不能直接与CPU连接，而需要通过I/O接口。	[]	{"reference_answer": "外设不能直接与CPU连接，主要原因在于外设与CPU之间存在多方面差异，导致信息无法直接兼容。具体包括：1. 数据格式差异：外设信息格式多样（如串行/并行、模拟/数字），CPU通常处理并行数字数据。2. 速度差异：外设速度远低于CPU，直接连接会导致CPU资源浪费或等待。3. 逻辑时序差异：外设有独立的时序，异步性明显，与CPU时序不匹配。4. 信号电平差异：外设与CPU的电气特性（如电压）不同，需要电平转换。因此，I/O接口作为适配器（桥梁），解决上述问题，实现CPU与外设的可靠数据交换。"}	["指出外设与CPU存在差异（核心原因）", "列出至少三个具体差异（数据格式、速度、逻辑时序、信号电平）", "说明I/O接口作为适配器/桥梁的作用"]	根据知识块[09-s002-01]和[09-s003-01]，外设特点包括速度差异大、结构原理差异大、时序独立、异步性明显；外设信息不能直接与CPU兼容的原因包括数据格式、速度、逻辑时序和信号电平差异。I/O接口电路是CPU与外设之间的桥梁。答案需涵盖这些核心点。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
504	9	\N	\N	short_answer	hard	在中断系统中，中断判优和中断屏蔽的作用分别是什么？它们如何共同管理多个中断请求？	[]	{"reference_answer": "中断判优的作用是解决多个中断源同时请求时的优先级问题，决定哪个中断请求被优先响应。中断屏蔽的作用是允许或禁止某些中断请求，通过设置屏蔽字，可以动态控制哪些中断源可以发出请求或被响应。两者共同管理中断请求：首先，通过中断判优机制确定当前最高优先级的请求；然后，结合中断屏蔽状态，只有未被屏蔽且优先级足够高的请求才能被CPU响应。这样既保证了紧急事件优先处理，又允许系统根据需要临时禁止某些中断。"}	["明确中断判优的作用：解决同时请求的优先级问题", "明确中断屏蔽的作用：允许或禁止某些中断请求", "说明两者如何结合管理请求（判优确定优先级，屏蔽控制可请求性/可响应性）"]	根据知识块[09-s005-01]，中断判优解决多个中断源同时请求时的优先级问题，中断屏蔽用于允许或禁止某些中断请求。答案需分别解释两者作用，并说明它们在中断管理中的协同关系。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
505	9	\N	\N	short_answer	hard	DMA（直接内存访问）为什么能提高高速I/O设备的效率？请从CPU参与度和数据传送路径的角度解释。	[]	{"reference_answer": "DMA能提高高速I/O设备效率，主要因为：1. 数据传送路径直接：DMA方式下，外设与主存之间直接进行数据块传送，数据无需经过CPU，减少了数据在CPU中的中转环节。2. CPU参与度低：CPU只负责初始化DMA控制器（设置传送参数）和结束处理，在数据传送过程中CPU无需逐个字节干预，可以并行执行其他任务。对于高速设备，如果采用程序查询或中断方式，CPU需要频繁介入，效率低下；DMA通过硬件直接传送，匹配了高速设备的带宽需求，从而大幅提升效率。"}	["指出数据直接在主存与外设间传送（不经过CPU）", "指出CPU仅负责初始化和结束处理，传送中参与少", "对比其他方式（查询/中断）解释高速场景下的效率优势"]	根据知识块[09-s006-01]，DMA用于外设与主存之间直接进行数据块传送，CPU只负责初始化和结束处理。DMA适合高速大块数据传输。答案需从传送路径和CPU参与度两个核心角度解释其效率优势。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
530	9	\N	\N	single_choice	easy	DMA用于在外设与主存之间直接传送数据块，其适合的场景是？	[{"key": "A", "text": "键盘字符输入"}, {"key": "B", "text": "低速打印机输出"}, {"key": "C", "text": "磁盘、网卡等高速大块数据传输"}, {"key": "D", "text": "鼠标移动事件处理"}]	{"answer": "C"}	[]	根据知识块，DMA适合磁盘、网卡、显卡等高速大块数据传输。选项A、B、D描述的都是低速或小块数据场景，更适合用程序查询或中断方式处理，因此C最合适。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
506	9	\N	\N	short_answer	hard	比较I/O端口的统一编址和独立编址方式，从地址空间、访问指令和编程特点三个方面说明其主要区别。	[]	{"reference_answer": "统一编址与独立编址的主要区别如下：1. 地址空间：统一编址中，I/O端口和内存共享同一个地址空间；独立编址中，I/O端口有独立的、与内存分离的地址空间。2. 访问指令：统一编址使用普通访存指令（如MOV）访问I/O端口；独立编址需要专门的I/O指令（如IN、OUT）。3. 编程特点：统一编址编程统一，可以使用丰富的访存指令操作I/O，但地址空间共享可能使地址分配复杂；独立编址地址空间清晰，I/O语义明确，但指令集专门化，灵活性稍差。"}	["正确说明地址空间差异（共享 vs. 独立）", "正确说明访问指令差异（普通访存指令 vs. 专门I/O指令）", "正确说明编程特点差异（统一性、地址分配、语义明确性等）"]	根据知识块[09-s004-01]，统一编址：I/O端口和内存统一在一个地址空间，用普通访存指令访问；独立编址：I/O端口有独立地址空间，需要专门I/O指令。统一编址编程统一，独立编址地址空间清晰、I/O语义明确。答案需涵盖这三个方面的对比。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
507	9	\N	\N	single_choice	easy	下列哪项不是外设信息不能直接与CPU兼容的原因？	[{"key": "A", "text": "数据格式差异"}, {"key": "B", "text": "CPU运算速度过快"}, {"key": "C", "text": "逻辑时序差异"}, {"key": "D", "text": "信号电平差异"}]	{"answer": "B"}	[]	根据知识块，外设信息不能直接与CPU兼容的原因包括数据格式、速度、逻辑时序和信号电平差异。选项B“CPU运算速度过快”虽然涉及速度，但知识块强调的是外设与CPU之间的“速度差异”（外设速度慢），而非单纯CPU速度快，且“速度差异”是原因，但选项B的表述不准确，且不是知识块列出的直接原因（列出的直接原因包括数据格式、速度、逻辑时序和信号电平差异）。选项A、C、D都是知识块明确列出的原因。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
508	9	\N	\N	multiple_choice	easy	I/O接口中通常包含哪些寄存器？	[{"key": "A", "text": "数据寄存器"}, {"key": "B", "text": "状态寄存器"}, {"key": "C", "text": "控制寄存器"}, {"key": "D", "text": "地址寄存器"}]	{"answer": ["A", "B", "C"]}	[]	根据知识块，I/O接口通常包含数据寄存器、状态寄存器、控制寄存器。地址寄存器虽然在计算机组成中存在，但知识块未将“地址寄存器”列为I/O接口的必备寄存器，知识块提到的是地址译码、电平转换和控制逻辑，因此选项D不属于知识块指定的接口寄存器。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
509	9	\N	\N	true_false	easy	在统一编址方式下，I/O端口和内存共享同一个地址空间，可以用普通访存指令访问。	[]	{"answer": "TRUE"}	[]	根据知识块，统一编址是指I/O端口和内存统一在一个地址空间，用普通访存指令访问。该描述与知识块内容一致，因此为真。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
510	9	\N	\N	single_choice	easy	以下哪种DMA传送方式下，CPU在整个数据块传送期间完全不访问主存？	[{"key": "A", "text": "停止CPU访存"}, {"key": "B", "text": "周期挪用"}, {"key": "C", "text": "透明DMA"}, {"key": "D", "text": "交替访问"}]	{"answer": "A"}	[]	根据知识块，DMA传送方式常见有停止CPU访存、周期挪用和透明DMA。其中“停止CPU访存”方式意味着在整个DMA传送期间，CPU放弃对总线的使用权，完全不访问主存。选项B“周期挪用”是DMA控制器在CPU不访存的周期（如CPU执行不访问存储器的指令时）插入传送，CPU仍可能在其他周期访存。选项C“透明DMA”是利用CPU不访问总线的空闲时间进行传送，CPU可能访存。选项D“交替访问”未在知识块中提及。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
511	9	\N	\N	single_choice	easy	中断过程中，用于确定多个中断源同时请求时的优先级问题的步骤是？	[{"key": "A", "text": "中断请求"}, {"key": "B", "text": "中断判优"}, {"key": "C", "text": "中断响应"}, {"key": "D", "text": "中断屏蔽"}]	{"answer": "B"}	[]	根据知识块，中断过程包括中断请求、中断判优、中断响应等。其中明确说明“中断判优解决多个中断源同时请求时的优先级问题”。选项A“中断请求”是事件发生的信号；选项C“中断响应”是CPU决定处理中断；选项D“中断屏蔽”用于允许或禁止某些中断请求，与优先级判断不同。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
512	9	\N	\N	fill_blank	medium	I/O接口电路通常包含______、状态寄存器和控制寄存器，其中______用于暂存CPU与外设交换的数据。	[]	{"blanks": [{"index": 1, "answer": "数据寄存器", "acceptable_answers": ["数据寄存器"]}, {"index": 2, "answer": "数据寄存器", "acceptable_answers": ["数据寄存器"]}]}	[]	根据知识块，I/O接口通常包含数据寄存器、状态寄存器、控制寄存器等。数据寄存器的作用是暂存CPU与外设交换的数据，因此两个空都应填写“数据寄存器”。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
520	9	\N	\N	multiple_choice	medium	中断过程通常包括以下哪些步骤？	[{"key": "A", "text": "中断请求"}, {"key": "B", "text": "中断判优"}, {"key": "C", "text": "保护现场"}, {"key": "D", "text": "CPU初始化外设"}, {"key": "E", "text": "恢复现场"}]	{"answer": ["A", "B", "C", "E"]}	[]	根据知识块[05]和[07]，中断过程包括中断请求、中断判优、中断响应、保护现场、执行中断服务程序、恢复现场和返回。选项A、B、C、E均在其中。选项D“CPU初始化外设”是DMA传送开始前CPU需要做的工作（知识块[06]），不属于中断过程的必要步骤。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
513	9	\N	\N	short_answer	medium	简述外设信息为什么不能直接与CPU兼容，并说明I/O接口的“桥梁”作用体现在哪两个主要方面。	[]	{"reference_answer": "外设信息不能直接与CPU兼容的原因包括：1) 数据格式差异；2) 速度差异；3) 逻辑时序差异；4) 信号电平差异。I/O接口的“桥梁”作用主要体现在：1) 实现CPU与外设之间的数据格式、速度和时序的匹配与转换；2) 提供CPU访问外设所需的状态、控制寄存器等，并进行地址译码和电平转换。"}	["列出外设与CPU不兼容的四个主要原因中的至少三个。", "说明I/O接口的桥梁作用需包含“匹配转换”和“提供寄存器与地址译码”两个核心方面。"]	答案基于知识块[ch09-s002-01]中关于外设特点和I/O接口作用的描述。桥梁作用需要体现接口作为适配器，在格式、速度、时序、电平上进行转换，并为CPU提供访问入口。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
514	9	\N	\N	short_answer	medium	I/O端口的编址方式有哪两种？请分别说明其地址空间特点和访问指令。	[]	{"reference_answer": "两种编址方式是统一编址和独立编址。统一编址：I/O端口和内存共用一个地址空间，CPU使用普通的访存指令（如MOV）访问I/O端口。独立编址：I/O端口拥有独立的地址空间，CPU需要使用专门的I/O指令（如IN/OUT）访问。"}	["准确说出两种编址方式的名称。", "正确描述统一编址的地址空间为“统一/共用”且使用“访存指令”。", "正确描述独立编址的地址空间为“独立”且使用“专门的I/O指令”。"]	答案直接来源于知识块[ch09-s004-01]中对统一编址和独立编址的定义和特点描述，考察对两种编址方式核心区别的理解。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
515	9	\N	\N	short_answer	medium	DMA方式适合什么类型的I/O设备？请简述DMA控制器为完成一次数据块传送需要掌握的核心信息（至少列出四项）。	[]	{"reference_answer": "DMA适合高速大块数据传输的设备，如磁盘、网卡、显卡等。DMA控制器通常需要掌握的核心信息包括：1) 主存地址（数据块在内存中的起始地址）；2) 传送字数（要传送的数据量）；3) 传送方向（从外设到内存还是从内存到外设）；4) 设备地址（外设的识别信息）。"}	["设备类型正确，提及“高速”、“大块数据”或列举具体设备（磁盘、网卡、显卡等）。", "列出DMA控制器所需的核心信息四项，且表述准确（如主存地址、传送字数、传送方向、设备地址）。"]	答案依据知识块[ch09-s006-01]。DMA适用场景和控制器需要掌握的信息是该知识点的核心内容，题目要求检验对DMA核心机制的理解而非死记硬背。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
516	9	\N	\N	short_answer	medium	CPU与外设交换数据有程序查询、中断和DMA三种方式。从CPU参与程度和数据传送路径两个角度，简述DMA与程序查询方式的主要区别。	[]	{"reference_answer": "主要区别在于：1) CPU参与程度：程序查询方式下，CPU需要不断查询外设状态并主导数据传送，全程参与；DMA方式下，CPU只在传送开始前进行初始化，在传送结束后进行处理，数据传送过程CPU不参与。2) 数据传送路径：程序查询方式数据需要经过CPU（从外设到I/O接口，再到CPU，最后到内存）；DMA方式数据在外设和主存之间直接传送，不经过CPU。"}	["从CPU参与程度角度对比：指出查询方式CPU全程/持续参与，DMA方式CPU参与少（仅初始化和结束处理）。", "从数据传送路径角度对比：指出查询方式数据经过CPU，DMA方式数据直接在主存和外设间传送。"]	答案基于知识块[ch09-s007-01]和[ch09-s008-01]中关于交换方式和DMA核心的描述。从CPU参与度和数据路径进行对比是理解不同I/O方式效率差异的关键。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
517	9	\N	\N	multiple_choice	medium	根据知识块，I/O接口电路中通常包含哪些寄存器？	[{"key": "A", "text": "数据寄存器"}, {"key": "B", "text": "状态寄存器"}, {"key": "C", "text": "控制寄存器"}, {"key": "D", "text": "中断向量寄存器"}]	{"answer": ["A", "B", "C"]}	[]	根据知识块[03]，I/O接口通常包含数据寄存器、状态寄存器和控制寄存器。数据寄存器暂存数据，状态寄存器反映外设状态，控制寄存器接收CPU命令。选项D“中断向量寄存器”在给定知识块中未提及，属于中断系统内部的部件，不属于I/O接口寄存器。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
518	9	\N	\N	single_choice	medium	在DMA的三种常见传送方式中，哪种方式允许CPU在不使用总线时进行数据传送，从而减少对CPU程序执行的影响？	[{"key": "A", "text": "停止CPU访存"}, {"key": "B", "text": "周期挪用"}, {"key": "C", "text": "透明DMA"}, {"key": "D", "text": "CPU轮询"}]	{"answer": "B"}	[]	根据知识块[06]，DMA传送方式常见有停止CPU访存、周期挪用和透明DMA。其中“周期挪用”是指DMA控制器利用CPU不访问内存的周期进行数据传送，这样不会中断CPU的执行，减少了影响。选项A“停止CPU访存”需要CPU暂停；选项C“透明DMA”是利用CPU执行某些指令时不需要访问内存的周期进行传送，原理相似但名称不准确；选项D“CPU轮询”是程序查询方式，与DMA无关。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
519	9	\N	\N	true_false	medium	在独立编址的I/O系统中，CPU访问I/O端口需要使用专门的I/O指令。	[]	{"answer": "TRUE"}	[]	根据知识块[04]，独立编址是指I/O端口有独立地址空间，需要专门I/O指令进行访问。与之相对，统一编址则使用普通访存指令。因此该说法正确。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
531	9	\N	\N	true_false	easy	中断判优的作用是解决多个中断源同时请求时的优先级问题。	[]	{"answer": "TRUE"}	[]	根据知识块，中断判优解决多个中断源同时请求时的优先级问题。这是中断系统中的一个标准步骤，因此该说法正确。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
521	9	\N	\N	single_choice	medium	以下哪一项不是外设信息不能直接与CPU兼容的原因？	[{"key": "A", "text": "数据格式差异"}, {"key": "B", "text": "工作速度差异大"}, {"key": "C", "text": "CPU运算速度太快"}, {"key": "D", "text": "信号电平差异"}]	{"answer": "C"}	[]	根据知识块[02]，外设信息不能直接与CPU兼容的原因包括数据格式、速度、逻辑时序和信号电平差异。选项A、B、D分别对应格式、速度、电平差异。选项C“CPU运算速度太快”并非根本原因，核心在于外设速度慢且与CPU存在多种不兼容差异，而非单纯因为CPU快。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
522	9	\N	\N	fill_blank	hard	I/O接口中的______寄存器用于接收CPU发出的启动、停止、读写方式等控制命令。	[]	{"blanks": [{"index": 1, "answer": "控制", "acceptable_answers": ["控制寄存器"]}]}	[]	根据知识块[09-s003-01]，I/O接口通常包含控制寄存器，其作用是接收CPU发出的启动、停止、读写方式等控制命令。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
523	9	\N	\N	short_answer	hard	比较I/O统一编址和独立编址的主要优缺点。	[]	{"reference_answer": "统一编址：I/O端口和内存统一在一个地址空间，使用普通访存指令访问，优点是编程统一，访问方便；缺点是占用部分内存地址空间。独立编址：I/O端口有独立地址空间，需要专门I/O指令，优点是地址空间清晰、I/O语义明确，不占用内存地址空间；缺点是需要专门的I/O指令，编程稍复杂。"}	["正确描述统一编址的特点（统一地址空间、用访存指令）", "正确描述独立编址的特点（独立地址空间、用I/O指令）", "分别说明各自的优点和缺点"]	根据知识块[09-s004-01]，统一编址和独立编址在地址空间、使用的指令以及优缺点上均有明确描述。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
524	9	\N	\N	short_answer	hard	为什么DMA方式能够提高高速I/O设备的数据传输效率？	[]	{"reference_answer": "DMA方式允许外设与主存之间直接进行数据块传送，CPU只在传送开始前进行初始化和传送结束后进行处理，整个数据块传送过程由DMA控制器控制，不占用CPU执行程序指令的时间，从而释放了CPU，让CPU可以并行执行其他任务。相比程序查询和中断方式，DMA减少了CPU对I/O操作的干预次数和开销，特别适合磁盘、网卡等高速大块数据传输。"}	["指出DMA是外设与主存直接传送", "指出CPU只负责初始化和结束处理", "说明CPU在传送过程中被释放，可并行工作", "说明相比其他方式（查询、中断）CPU干预少"]	根据知识块[09-s006-01]和[09-s008-01]，DMA的核心是外设与主存直接交换数据，CPU少参与，因此能提高高速I/O效率。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
525	9	\N	\N	short_answer	hard	请简述中断响应及中断服务的完整过程（按顺序列出关键步骤）。	[]	{"reference_answer": "中断响应及服务过程的关键步骤按顺序为：1. 中断请求；2. 中断判优；3. 中断响应；4. 保护现场；5. 执行中断服务程序；6. 恢复现场；7. 中断返回。"}	["步骤完整，无遗漏", "步骤顺序正确", "使用标准术语（如保护现场、恢复现场）"]	根据知识块[09-s005-01]和[09-s007-01]，中断过程明确包括请求、判优、响应、保护现场、服务、恢复、返回七个步骤。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
526	9	\N	\N	fill_blank	hard	DMA控制器在进行数据传送前，通常需要掌握主存地址、传送字数、传送方向以及______等信息。	[]	{"blanks": [{"index": 1, "answer": "设备地址", "acceptable_answers": ["外设地址", "I/O设备地址"]}]}	[]	根据知识块[09-s006-01]，DMA控制器通常需要掌握主存地址、传送字数、传送方向、设备地址等信息。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
527	9	\N	\N	single_choice	easy	以下哪项不是外设不能直接与CPU连接的主要原因？	[{"key": "A", "text": "数据格式差异"}, {"key": "B", "text": "工作速度差异大"}, {"key": "C", "text": "CPU处理速度过快"}, {"key": "D", "text": "信号电平差异"}]	{"answer": "C"}	[]	根据知识块，外设信息不能直接与CPU兼容的原因包括数据格式、速度、逻辑时序和信号电平差异。选项C“CPU处理速度过快”并非知识块中列出的原因，且“过快”是相对概念，本质原因是“工作速度差异大”，因此C不合适。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
528	9	\N	\N	true_false	easy	I/O接口中的状态寄存器用于接收CPU发出的启动、停止等控制命令。	[]	{"answer": "FALSE"}	[]	根据知识块，状态寄存器反映外设是否就绪、是否忙、是否出错，用于反映外设状态。而接收CPU发出的启动、停止、读写方式等控制命令是控制寄存器的功能。因此该说法错误。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
529	9	\N	\N	multiple_choice	easy	关于I/O端口编址方式，以下说法正确的有？	[{"key": "A", "text": "统一编址下，I/O端口与内存共享同一地址空间"}, {"key": "B", "text": "独立编址需要使用专门的I/O指令访问端口"}, {"key": "C", "text": "统一编址使得编程接口更统一"}, {"key": "D", "text": "独立编址的地址空间不清晰，I/O语义不明确"}]	{"answer": ["A", "B", "C"]}	[]	根据知识块，统一编址是I/O端口和内存统一在一个地址空间，用普通访存指令访问，编程统一；独立编址是I/O端口有独立地址空间，需要专门I/O指令，地址空间清晰、I/O语义明确。因此A、B、C正确。D选项描述与知识块中“独立编址地址空间清晰、I/O语义明确”相反，故错误。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
532	9	\N	\N	fill_blank	medium	I/O接口作为CPU与外设之间的桥梁，其内部通常包含数据寄存器、______寄存器和控制寄存器，用于协调两者间的数据交换。	[]	{"blanks": [{"index": 1, "answer": "状态", "acceptable_answers": ["状态"]}]}	[]	根据知识块[ch09-s003-01]，I/O接口电路包含数据寄存器、状态寄存器和控制寄存器。数据寄存器暂存数据，状态寄存器反映外设状态（如就绪、忙、出错），控制寄存器接收CPU的控制命令。题目考查对I/O接口核心寄存器的记忆和理解。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
533	9	\N	\N	short_answer	medium	为什么外设不能直接与CPU相连，而必须通过I/O接口？请简述主要原因。	[]	{"reference_answer": "外设不能直接与CPU相连，必须通过I/O接口，主要原因在于外设与CPU之间存在显著差异。这些差异包括：1. 数据格式差异，外设信息格式多样，与CPU兼容的数字信号格式不同；2. 速度差异，外设工作速度通常远低于CPU，直接连接会导致CPU等待浪费时间；3. 逻辑时序差异，外设时序独立、异步性明显，与CPU的同步时序不匹配；4. 信号电平差异，外设信号电平可能与CPU的TTL或CMOS电平不兼容。I/O接口作为适配桥梁，可以解决这些差异，实现两者间的协调与数据交换。"}	["答出数据格式差异", "答出速度差异", "答出逻辑时序差异（或异步性）", "答出信号电平差异", "明确I/O接口的作用是适配/桥梁"]	此题综合考查对外设特点及I/O接口作用的理解。答案依据知识块[ch09-s002-01]中的描述：外设特点包括工作速度差异大、结构原理差异大、时序独立、异步性明显；外设信息不能直接与CPU兼容的原因包括数据格式、速度、逻辑时序和信号电平差异。I/O接口电路是CPU与外设之间的桥梁。答案需涵盖这些关键差异点。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
534	9	\N	\N	short_answer	medium	请描述中断处理过程中，从多个中断源同时提出请求到CPU最终响应其中一个请求所涉及的关键步骤（至少包括中断请求、中断判优、中断响应）。	[]	{"reference_answer": "当多个中断源同时提出请求时，中断处理过程的关键步骤如下：1. 中断请求：多个中断源通过中断请求线向CPU发出中断请求信号。2. 中断判优：中断系统根据预设的优先级（如硬件排队器或软件查询）对同时到达的请求进行判优，确定哪个中断源具有最高优先权。3. 中断响应：CPU在满足响应条件（如当前指令执行完毕、中断未被屏蔽）时，接受判优后胜出的中断请求，进入中断响应周期。响应后，CPU会进入后续的保护现场、执行服务程序等步骤。"}	["明确列出中断请求、中断判优、中断响应三个步骤", "对“中断判优”步骤说明其目的是解决优先级问题", "对“中断响应”步骤说明CPU接受胜出请求", "整体逻辑顺序正确"]	此题考查对中断核心流程的掌握，特别是多中断源下的处理逻辑。根据知识块[ch09-s005-01]，中断过程包括中断请求、中断判优、中断响应等步骤，且中断判优是解决多个中断源同时请求时的优先级问题。题目要求描述从“同时请求”到“响应其中一个”的关键步骤，因此答案需聚焦于这三个环节及其内在联系。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
535	9	\N	\N	short_answer	medium	与中断方式相比，DMA方式为什么能显著提高高速I/O设备（如磁盘）的数据传输效率？请从数据传送路径和CPU参与程度两个方面进行简述。	[]	{"reference_answer": "DMA方式能显著提高高速I/O设备数据传输效率，主要基于以下两点：1. 数据传送路径优化：DMA方式下，数据在外设与主存之间直接进行传送，无需经过CPU的累加器或寄存器中转，减少了数据拷贝环节，路径更短、更快。2. CPU参与程度降低：在DMA传送过程中，CPU仅在传送开始前进行初始化和结束时进行处理，传送期间CPU可以执行其他不访存的指令，或者通过“周期挪用”等方式让出总线，避免了像程序查询或中断方式那样，每个数据字（或字节）的传送都需要CPU介入，从而极大地解放了CPU，使其专注于计算任务。"}	["指出数据在“外设与主存之间”直接传送", "指出CPU“只负责初始化和结束处理”或“传送期间CPU少参与/可执行其他任务", "对比隐含了对中断方式（CPU需逐字介入）的效率劣势", "逻辑清晰，两点分别对应数据路径和CPU参与度"]	此题考查对DMA核心优势的理解。根据知识块[ch09-s006-01]和[ch09-s008-01]，DMA用于外设与主存之间直接进行数据块传送，CPU只负责初始化和结束处理。这与中断方式（CPU需为每个数据传送进行中断服务）形成鲜明对比。题目要求从数据传送路径和CPU参与程度两个具体方面阐述，答案需准确对应这两个要点，并解释其带来的效率提升。	ai:model-draft;chunks=ch09-s001-01,ch09-s002-01,ch09-s003-01,ch09-s004-01,ch09-s005-01,ch09-s006-01,ch09-s007-01,ch09-s008-01	AI题目生成	t	t	2026-06-01 15:15:08.593214+00	2026-06-01 15:15:08.593214+00	f	verified	0	0	0	0	0	0
542	1	\N	\N	short_answer	medium	冯·诺依曼体系结构提出了两个对现代计算机发展至关重要的基本思想，请简要说明。	[]	{"reference_answer": "1. 二进制：采用二进制表示数据和指令，便于电子线路实现。\\n2. 存储程序：将程序和数据预先存入存储器，计算机工作时自动从存储器取指令并执行，无需人工干预。"}	["答出二进制思想及其优势（便于电路实现）", "答出存储程序思想及其核心内容（程序与数据存入存储器，自动取指执行）", "表述清晰，逻辑正确"]	根据知识块[01-s002-01]和[01-s006-01]，冯·诺依曼体系结构的核心是二进制和存储程序这两个关键思想。二进制使信息表示和电路实现更简单可靠；存储程序思想是现代计算机能够自动、连续执行的基础。题目要求简要说明，因此需涵盖这两个要点的核心内涵。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-02 02:04:01.982163+00	2026-06-02 02:04:01.982163+00	f	temporary	0	0	0	0	0	0
43	6	\N	597	single_choice	medium	指令XOR r3,r0,[r2]是：	[{"key": "A", "text": "单字指令"}, {"key": "B", "text": "双字指令"}]	{"answer": "A"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/02-第6章作业-2nd.txt#3.4	第6章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
543	1	\N	\N	short_answer	medium	计算机系统采用分层结构的主要目的是什么？请从“抽象”和“界面”两个关键词的角度进行解释。	[]	{"reference_answer": "主要目的是隐藏底层复杂细节，让上层用户或程序只面对更简单的模型。\\n“抽象”的作用是隐藏每一层内部实现的复杂性，只向上层提供必要的功能和服务。\\n“界面”的作用是明确定义和连接不同层次之间的交互方式，例如软件与硬件之间、使用者与设计者之间、不同计算机语言之间的接口。"}	["明确指出分层的主要目的（隐藏复杂细节）", "分别解释“抽象”在分层中的作用", "分别解释“界面”在分层中的作用", "解释能够结合层次结构的概念"]	根据知识块[01-s008-01]，计算机系统层次结构的核心在于“抽象”和“界面”。抽象是实现分层目的（隐藏复杂性）的核心机制，而界面是各层次得以正确交互和组合的关键。题目直接指向这两个关键词，要求考生理解它们在分层设计中的具体作用。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-02 02:04:01.982163+00	2026-06-02 02:04:01.982163+00	f	temporary	0	0	0	0	0	0
544	1	\N	\N	short_answer	medium	以GCC编译一个典型的C语言源程序（如hello.c）为例，请按顺序写出将其变为可执行文件的主要步骤（可省略预处理阶段），并简要说明每步的核心任务。	[]	{"reference_answer": "1. 编译：将C语言高级源程序翻译成汇编语言程序（生成.s文件）。\\n2. 汇编：将汇编语言程序翻译成机器语言的目标文件（生成.o文件）。\\n3. 链接：将目标文件与所需的库函数等模块组合，生成最终的可执行文件。"}	["正确列出编译、汇编、链接三个步骤", "步骤顺序正确", "每步的核心任务描述准确（编译->汇编语言；汇编->目标文件；链接->可执行文件）"]	根据知识块[01-s007-01]，一个典型的编译型语言（如C）从源文件到可执行文件的过程包括预处理、编译、汇编、链接。题目要求省略预处理，并写出主要步骤。因此，答案应包含编译（高级语言->汇编）、汇编（汇编->目标文件）、链接（目标文件->可执行文件）三个关键环节。	ai:model-draft;chunks=ch01-s001-01,ch01-s002-01,ch01-s003-01,ch01-s004-01,ch01-s005-01,ch01-s006-01,ch01-s007-01,ch01-s008-01	AI题目生成	t	t	2026-06-02 02:04:01.982163+00	2026-06-02 02:04:01.982163+00	f	temporary	0	0	0	0	0	0
545	8	\N	\N	fill_blank	medium	在 RISC-V 模型机中，用于实现条件分支（如 beq）的指令格式是____型。这类指令在执行时，其核心操作是同时处理比较、目标地址计算和____选择。	[]	{"blanks": [{"index": 1, "answer": "B", "acceptable_answers": ["B"]}, {"index": 2, "answer": "PC", "acceptable_answers": ["PC", "程序计数器", "程序计数器(PC)"]}]}	[]	根据知识块 [ch08-s002-01]，B型格式用于条件分支。根据 [ch08-s005-01]，转移指令的关键是同时处理“比较/目标地址计算/PC选择”。因此，第一空为B，第二空为PC。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-02 02:05:14.657555+00	2026-06-02 02:05:14.657555+00	f	temporary	0	0	0	0	0	0
546	8	\N	\N	single_choice	medium	在 RISC-V 模型机中，执行一条 R 型指令（如 add）时，以下哪个描述的数据通路是正确的？	[{"key": "A", "text": "读 rs1 和 rs2 -> ALU 运算 -> 写回 rd"}, {"key": "B", "text": "读 rs1 -> 立即数符号扩展 -> ALU 运算 -> 写回 rd"}, {"key": "C", "text": "rs1 + 符号扩展立即数得到有效地址 -> 读数据存储器 -> 写回 rd"}, {"key": "D", "text": "保存返回地址 PC+4 到 rd，并跳转到目标地址"}]	{"answer": "A"}	[]	根据知识块 [ch08-s003-01]，R型指令的数据通路是“读rs1和rs2 -> ALU运算 -> 写回rd”。选项B描述的是I型立即数指令（如addi）的数据通路。选项C描述的是load指令的数据通路。选项D描述的是jal指令的部分功能。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-02 02:05:14.657555+00	2026-06-02 02:05:14.657555+00	f	temporary	0	0	0	0	0	0
547	8	\N	\N	calculation	medium	假设 RISC-V 模型机正在执行一条条件分支指令 beq。当前 PC 值为 0x00400000，指令中的分支偏移量（经符号扩展和左移后）为 -0x10。如果比较结果满足分支条件，那么执行后的新 PC 值是多少？	[]	{"reference_answer": "0x003FFF0"}	["正确识别新PC = PC + 分支偏移", "计算过程正确（0x00400000 - 0x10）", "最终结果正确"]	根据知识块 [ch08-s005-01]，对于条件分支指令（如beq），若满足条件，则新 PC = PC + 分支偏移。本题中，PC = 0x00400000，偏移量 = -0x10。因此新PC = 0x00400000 + (-0x10) = 0x00400000 - 0x10 = 0x003FFF0。注意十六进制运算。	ai:model-draft;chunks=ch08-s001-01,ch08-s002-01,ch08-s003-01,ch08-s004-01,ch08-s005-01,ch08-s006-01,ch08-s007-01,ch08-s008-01	AI题目生成	t	t	2026-06-02 02:05:14.657555+00	2026-06-02 02:05:14.657555+00	f	temporary	0	0	0	0	0	0
32	7	\N	595	fill_blank	medium	如果使用多周期CPU实现，每个阶段一个时钟周期，需要5个、4个、3个和2个阶段的指令分别占10%、20%、50%、20%。则其CPI= ；平均每条指令的执行时间是 ns；该计算机的执行速度是 MIPS；其主频最大值是 MHz。	[]	{"blanks": [{"index": 1, "answer": "3.2", "acceptable_answers": []}, {"index": 2, "answer": "160", "acceptable_answers": []}, {"index": 3, "answer": "6.25", "acceptable_answers": ["25/4"]}, {"index": 4, "answer": "20", "acceptable_answers": []}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/01-第7章作业-1st.txt#22.2	第7章作业-1st 已完成 智能分析 剩余148小时13分钟	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
33	7	\N	595	fill_blank	medium	如果使用流水线CPU实现，则其流水线时钟周期是 ns;理想情况下，其执行速度是单周期CPU的 倍，是多周期CPU的 倍。	[]	{"blanks": [{"index": 1, "answer": "50", "acceptable_answers": []}, {"index": 2, "answer": "3.1", "acceptable_answers": []}, {"index": 3, "answer": "3.2", "acceptable_answers": []}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/01-第7章作业-1st.txt#22.3	第7章作业-1st 已完成 智能分析 剩余148小时13分钟	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
596	6	\N	\N	question_group	medium	有一小段RV32I的汇编程序如下：\nlui t1, 0xFFFF0;\nlw t0, 0x100(s2);\nand t0, t0, t1\naddi t0, t0, 0x555\nsw t0, 0x100(s2);\n假设的寄存器s2内容是0020 0000H：	[]	{}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/02-第6章作业-2nd.txt#1	第6章作业-2nd 待批阅 智能分析	f	t	2026-06-02 03:00:20.17898+00	2026-06-02 03:00:20.17898+00	f	\N	0	0	0	0	0	0
34	6	\N	596	fill_blank	medium	请写出五条指令的机器指令码：\nlui t1, 0xFFFF0 机器指令码： ① H\nlw t0, 0x100(s2) 机器指令码： ② H\nand t0, t0, t1 机器指令码： ③ H\naddi t0, t0, 0x555 机器指令码： ④ H\nsw t0, 0x100(s2); 机器指令码： ⑤ H	[]	{"blanks": [{"index": 1, "answer": "ffff0337", "acceptable_answers": ["ffff0337h", "FFFF0337", "FFFF0337H"]}, {"index": 2, "answer": "10092283", "acceptable_answers": ["10092283h", "10092283H"]}, {"index": 3, "answer": "0062f2b3", "acceptable_answers": ["0062f2b3h", "0062F2B3", "0062F2B3H"]}, {"index": 4, "answer": "55528293", "acceptable_answers": ["55528293h", "55528293H"]}, {"index": 5, "answer": "10592023", "acceptable_answers": ["10592023h", "10592023H"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/02-第6章作业-2nd.txt#1.1	第6章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
36	6	\N	596	fill_blank	medium	如果内存单元0020 0100H的内容是12345678H，请问这5条指令执行结束后，该单元的内容是 ⑥ H	[]	{"blanks": [{"index": 1, "answer": "12340555", "acceptable_answers": ["12340555h", "12340555H"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/02-第6章作业-2nd.txt#1.3	第6章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
37	6	\N	596	fill_blank	medium	假设最后一条指令，变为sw t0, 0x800(s2)；请问该指令的目的操作数的有效地址EA是 ⑦ H	[]	{"blanks": [{"index": 1, "answer": "001ff800", "acceptable_answers": ["001ff800h", "001FF800", "001FF800H"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/02-第6章作业-2nd.txt#1.4	第6章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
38	6	\N	596	fill_blank	medium	五条指令中，指令 ① 只有寄存器类型的操作数；指令 ② 有立即数类型的操作数；指令 ③ 有存储器类型的操作数；R型格式的指令有 ④ ；I型格式的指令有 ⑤ ；S型格式的指令有 ⑥ ；U型格式的指令有 ⑦ 。\n请直接填写ABCDE，多个选项中间不加标点符号，譬如ABC。\nA.lui B.lw C.and D.addi E.sw	[]	{"blanks": [{"index": 1, "answer": "C", "acceptable_answers": ["c"]}, {"index": 2, "answer": "AD", "acceptable_answers": ["ad"]}, {"index": 3, "answer": "BE", "acceptable_answers": ["be"]}, {"index": 4, "answer": "C", "acceptable_answers": ["c"]}, {"index": 5, "answer": "BD", "acceptable_answers": ["bd"]}, {"index": 6, "answer": "E", "acceptable_answers": ["e"]}, {"index": 7, "answer": "A", "acceptable_answers": ["a"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/02-第6章作业-2nd.txt#1.5	第6章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
597	6	\N	\N	question_group	medium	假设某16位计算机X，指令字长有单字指令和双字指令两种，格式为：\nOP（5位）\nMOD（2位）\nrd（3位）\nrs1（3位）\nrs2（3位）\nImme/Addr/Offset（16位）\nOP是操作码，MOD是寻址方式码，rd是目的操作数的寄存器编码，rs1和rs2是源操作数的寄存器编码；Imme/Addr/Offset是部分指令的第二字，为立即数或者直接地址或者偏移量。有一段程序如下表所示，内存地址和指令代码/数据都是16进制表示。\n序号\n内存地址\n指令\n指令功能\n指令代码/数据\n1\n04000\nMOV r0, 00FFH\n00FFH→r0\n8400 00FF\n2\n04002\nMOV r1,10\n10→r1\n3\nMOV r2,4100H\n4100H→r2\n4\nL:\nXOR r3,r0,[r2]\nr0⊕mem(r2)→r3\n5\nMOV [r2],r3\nr3→mem(r2)\n6\nINC r2\nr2+1→r2\n7\nDEC r1\nr1-1→r1\n8\nJNZ L\nif(ZF=0) goto L\n9\nExit:\n……\n04100\n8899\n04101\naabb\n04102\n……	[]	{}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/02-第6章作业-2nd.txt#3	第6章作业-2nd 待批阅 智能分析	f	t	2026-06-02 03:00:20.17898+00	2026-06-02 03:00:20.17898+00	f	\N	0	0	0	0	0	0
40	6	\N	597	fill_blank	medium	如果该指令系统格式固定不变，则最多有 条指令。	[]	{"blanks": [{"index": 1, "answer": "32", "acceptable_answers": ["32条"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/02-第6章作业-2nd.txt#3.1	第6章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
41	6	\N	597	fill_blank	medium	假设其中有10条指令只使用了三个寄存器字段的两个寄存器，那么采用指令操作码扩展技术，最多能扩展这种类型的指令到 条。	[]	{"blanks": [{"index": 1, "answer": "80", "acceptable_answers": ["80条"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/02-第6章作业-2nd.txt#3.2	第6章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
44	6	\N	597	fill_blank	medium	8条指令中，双字指令有 条，单字指令有 条。	[]	{"blanks": [{"index": 1, "answer": "4", "acceptable_answers": ["4条"]}, {"index": 2, "answer": "4", "acceptable_answers": ["4条"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/02-第6章作业-2nd.txt#3.5	第6章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
45	6	\N	597	single_choice	medium	指令MOV [r2],r3的 源操作数 和 目的操作数 的寻址方式分别是：	[{"key": "A", "text": "寄存器寻址 和 寄存器寻址"}, {"key": "B", "text": "变址寻址 和 寄存器寻址"}, {"key": "C", "text": "寄存器间接寻址 和 寄存器寻址"}, {"key": "D", "text": "寄存器寻址 和 寄存器间接寻址"}]	{"answer": "D"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/02-第6章作业-2nd.txt#3.6	第6章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
46	6	\N	597	fill_blank	medium	标号Exit对应的内存地址是 H（十六进制表示）。	[]	{"blanks": [{"index": 1, "answer": "0400C", "acceptable_answers": ["0400CH", "0400c", "0400ch", "400C", "400CH", "400c", "400ch"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/02-第6章作业-2nd.txt#3.7	第6章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
47	6	\N	597	fill_blank	medium	写出序号为3的指令MOV r2,4100H的机器代码 H（十六进制表示），不使用的字段填充0。	[]	{"blanks": [{"index": 1, "answer": "84804100", "acceptable_answers": ["84804100H", "84804100h"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/02-第6章作业-2nd.txt#3.8	第6章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
48	6	\N	597	fill_blank	medium	写出序号为8的指令JNZ L的机器代码为 H（十六进制表示），其中JNZ的OP是（11100）2，采用相对寻址（MOD=11），不使用的字段填充0。	[]	{"blanks": [{"index": 1, "answer": "E600FFFA", "acceptable_answers": ["E600FFFAH", "e600fffa", "e600fffaH"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/02-第6章作业-2nd.txt#3.9	第6章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
49	6	\N	597	fill_blank	medium	程序循环执行 次。	[]	{"blanks": [{"index": 1, "answer": "10", "acceptable_answers": ["10次"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/02-第6章作业-2nd.txt#3.10	第6章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
50	6	\N	597	fill_blank	medium	当程序执行到Exit时，内存单元04100H的内容是 H（十六进制表示）。	[]	{"blanks": [{"index": 1, "answer": "8866", "acceptable_answers": ["8866H", "8866h"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/02-第6章作业-2nd.txt#3.11	第6章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
51	6	\N	597	short_answer	medium	请用一句话描述该段程序的功能。	[]	{"reference_answer": "答案不唯一。\\n将内存地址为04100H开始的10个单元的数据，低8位数据取反，高8位数据不变（存回原来单元）。\\n知识点：\\n1\\n2\\n3"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/02-第6章作业-2nd.txt#3.12	第6章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
598	5	\N	\N	question_group	medium	某机字长16 位，CPU地址总线18位，数据总线16位，存储器按字编址，CPU 的控制信号线有：MREQ#（存储器访问请求，低电平有效），R/W#（读写控制，低电平为写信号，高电平为读信号）。试问：	[]	{}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/05-第5章作业-2nd.txt#15	第5章作业-2nd 待批阅 智能分析	f	t	2026-06-02 03:00:20.17898+00	2026-06-02 03:00:20.17898+00	f	\N	0	0	0	0	0	0
87	5	\N	598	fill_blank	medium	该机可以配备的最大主存容量为多少字节？	[]	{"blanks": [{"index": 1, "answer": "512K", "acceptable_answers": ["2^19", "512KB", "2^19B"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/05-第5章作业-2nd.txt#15.1	第5章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
88	5	\N	598	fill_blank	medium	该机主存采用64K×1bit的DRAM芯片（内部为4个128×128阵列）构成最大主存空间，则共需 个芯片；单元刷新间隔为64ms，存储周期为50ns；若采用异步刷新方式，则刷新信号的周期为 ms；若采用集中式刷新，则集中刷新一遍存储器所有行所需的时间是 ns；	[]	{"blanks": [{"index": 1, "answer": "64", "acceptable_answers": ["2^6"]}, {"index": 2, "answer": "0.5", "acceptable_answers": ["64/128", "1/2"]}, {"index": 3, "answer": "6400", "acceptable_answers": ["6400ns"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/05-第5章作业-2nd.txt#15.2	第5章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
89	5	\N	598	short_answer	medium	已知该机已有8K×16位的ROM存储器，地址处于主存的最高端；现在再用若干个16K×8位的SRAM芯片形成128K×16位的RAM存储区域，起始地址为00000H，假设SRAM芯片有CS#（片选，低电平有效）和WE#（写使能，低电平有效）信号控制端；试：\n①写出ROM的地址范围；\n②写出RAM的地址范围；\n③SRAM需要几个芯片？\n④画出SRAM、ROM与CPU的连接图，请标明SRAM芯片个数、译码器的输入输出线、地址线、数据线、控制线及其连接。\n请做在纸上，拍照上传。（请正向拍照，不要90度旋转。）	[]	{"reference_answer": "①ROM地址范围：3E000H~3FFFFH（4分）\\n②RAM地址范围：00000H~1FFFFH（4分）\\n③SRAM需要16片（1分）\\n④芯片2片一组，共8组：（20分）\\n可以使用3：8译码器实现：\\n4:16译码器"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/05-第5章作业-2nd.txt#15.3	第5章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
601	3	\N	\N	question_group	medium	判断以下关于Pentium系列CPU中数据格式的说法是否正确：	[]	{}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/08-第3章作业-2nd.txt#16	第3章作业-2nd 待批阅 智能分析	f	t	2026-06-02 03:00:20.17898+00	2026-06-02 03:00:20.17898+00	f	\N	0	0	0	0	0	0
90	5	\N	598	fill_blank	medium	若为该机配备2K×16位的Cache，每块8字节，采用直接映射方式，则主存地址被划分的三个字段：高位标记 位；Cache行地址 位；块内地址 位。	[]	{"blanks": [{"index": 1, "answer": "7", "acceptable_answers": ["7位"]}, {"index": 2, "answer": "9", "acceptable_answers": ["9位"]}, {"index": 3, "answer": "2", "acceptable_answers": ["2位"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/05-第5章作业-2nd.txt#15.4	第5章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
599	4	\N	\N	question_group	medium	下图所示为一个单总线结构运算器，请给出完成运算操作R2+R7→R3的步骤、发送的控制信号。	[]	{}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/07-第4章作业.txt#14	第4章作业 待批阅 智能分析	f	t	2026-06-02 03:00:20.17898+00	2026-06-02 03:00:20.17898+00	f	\N	0	0	0	0	0	0
134	4	\N	599	single_choice	medium	完成运算需要几个步骤（CPU周期）：	[{"key": "A", "text": "1"}, {"key": "B", "text": "2"}, {"key": "C", "text": "3"}, {"key": "D", "text": "不确定"}]	{"answer": "C"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/07-第4章作业.txt#14.1	第4章作业 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
135	4	\N	599	short_answer	medium	按顺序写出执行的步骤。	[]	{"reference_answer": "（1）R2→LA\\n（2）R7→IB，LA+IB→LC；或者R7→IB，F=A+B，F→LC；\\n（3）LC→R3\\n意思对即可；要分三步。"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/07-第4章作业.txt#14.2	第4章作业 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
136	4	\N	599	multiple_choice	medium	对于R2→LA操作，应该发送的地址和控制信号是：	[{"key": "A", "text": "RA=2"}, {"key": "B", "text": "WA=2"}, {"key": "C", "text": "GRout=1"}, {"key": "D", "text": "GRin=1"}, {"key": "E", "text": "LAin=1"}]	{"answer": ["A", "C", "E"]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/07-第4章作业.txt#14.3	第4章作业 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
137	4	\N	599	multiple_choice	medium	对于LC→R3的操作，应该发送的地址和控制信号是：	[{"key": "A", "text": "RA=3"}, {"key": "B", "text": "WA=3"}, {"key": "C", "text": "GRout=1"}, {"key": "D", "text": "GRin=1"}, {"key": "E", "text": "LCout=1"}, {"key": "F", "text": "LCin=1"}]	{"answer": ["B", "D", "E"]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/07-第4章作业.txt#14.4	第4章作业 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
138	4	\N	599	single_choice	medium	执行运算的步骤应该是：	[{"key": "A", "text": "LA+IB→R3"}, {"key": "B", "text": "LA+IB→LC"}, {"key": "C", "text": "R7→IB，LA+IB→R3"}, {"key": "D", "text": "R7→IB，LA+IB→LC"}]	{"answer": "D"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/07-第4章作业.txt#14.5	第4章作业 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
139	4	\N	599	multiple_choice	medium	执行运算操作R7→IB，F=A+B，F→LC，应该发送的控制信号有：	[{"key": "A", "text": "ALU_OP功能码为加法的功能码"}, {"key": "B", "text": "RA=7"}, {"key": "C", "text": "WA=3"}, {"key": "D", "text": "GRout"}, {"key": "E", "text": "GRin"}, {"key": "F", "text": "LCout"}, {"key": "G", "text": "LCin"}]	{"answer": ["A", "B", "D", "G"]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/07-第4章作业.txt#14.6	第4章作业 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
600	4	\N	\N	question_group	medium	设某机支持如下格式的浮点数，其中阶码用移码表示，尾数用补码表示：\n设（X）10 = 30.5；Y的浮点数编码用16进制表示为9D7AH。	[]	{}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/07-第4章作业.txt#15	第4章作业 待批阅 智能分析	f	t	2026-06-02 03:00:20.17898+00	2026-06-02 03:00:20.17898+00	f	\N	0	0	0	0	0	0
140	4	\N	600	short_answer	medium	写出X的规格化浮点数编码。	[]	{"reference_answer": "X=11110.1=0.111 1010 0000×2+101\\nMx=0.111 1010 0000 Ex=+101\\n[Mx]补=0.111 1010 0000 [Ex]移=1,101\\n[X]浮=0.111 1010 0000 1,101\\n（如果用16进制表示为7A0DH，也可以）"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/07-第4章作业.txt#15.1	第4章作业 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
141	4	\N	600	short_answer	medium	求出Y的二进制真值。	[]	{"reference_answer": "9D7AH=1001 1101 0111 1010b\\n按照浮点数格式，则：[My]补=1.001 1101 0111 [Ey]移=1,010\\nMy= -0.110 0010 1001 Ey =+010\\nY= My × 2Ey = -0.110 0010 1001 × 2+010= -11. 0 0010 1001b"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/07-第4章作业.txt#15.2	第4章作业 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
142	4	\N	600	fill_blank	medium	如果数据Y的浮点数编码9D7AH存入存储器地址N，存储器按照字节编址、采用小端格式存储，则该浮点数在内存地址N中是（ ① ）H；在地址N+1中是（ ② ）H。	[]	{"blanks": [{"index": 1, "answer": "7A", "acceptable_answers": ["7AH", "7a", "7ah"]}, {"index": 2, "answer": "9D", "acceptable_answers": ["9DH", "9d", "9dh"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/07-第4章作业.txt#15.3	第4章作业 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
143	4	\N	600	short_answer	medium	请完成[X-Y]浮的计算，列出计算过程，写出计算结果；要求尾数用补码运算，阶码用移码计算，按照0舍1入法舍入。	[]	{"reference_answer": "规格化浮点数如下，设Z=X-Y：\\n[X]浮= 0.111 1010 0000 1,101\\n[Y]浮= 1.001 1101 0111 1,010\\n①对阶：△E = [Ex]移+[-Ey]补= 01,101 + 11,110 = 01,011\\nMy右移3 bit，Ey加3\\n[X]浮= 0.111 1010 0000 1,101\\n[Y]浮= 1.111 0011 1010（111） 1,101\\n②尾数相减：\\n[Mz]补 =[Mx-My]补 =[Mx]补+[-My]补\\n[-My]补=00. 000 1100 0101 （001）\\n00.111 1010 0000\\n+ 00.000 1100 0101 （001）\\n01.000 0110 0101 （001）\\n③结果规格化：有溢出，右规1位（Mz右移1位，阶码+1）\\n[Mz]补=00.100 0011 0010 （1001）\\n[Ez]移=01,101+00,001=01,110；无溢出，[Ez]移=1,110。\\n④舍入：[Mz]补入1\\n[Mz]补=0.100 0011 0011 [Ez]移=1,110；\\n得：[X-Y]浮= 0.100 0011 0011 1,110\\n（如果写出16进制编码，为433EH）"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/07-第4章作业.txt#15.4	第4章作业 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
159	3	\N	601	true_false	medium	数据按字节编址，也只能按照字节访问。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "FALSE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/08-第3章作业-2nd.txt#16.1	第3章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
160	3	\N	601	true_false	medium	字数据是指16位二进制数据。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "TRUE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/08-第3章作业-2nd.txt#16.2	第3章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
161	3	\N	601	true_false	medium	数据在内存中存放方式是小端模式，即低位字节在低地址端，高位字节在高地址端。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "TRUE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/08-第3章作业-2nd.txt#16.3	第3章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
162	3	\N	601	true_false	medium	支持的数据类型中，有定点整数、定点小数以及浮点数。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "FALSE"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/08-第3章作业-2nd.txt#16.4	第3章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
163	3	\N	601	true_false	medium	支持IEEE754标准的单精度、双精度浮点数，不支持临时浮点数格式。	[{"key": "A", "text": "对"}, {"key": "B", "text": "错"}]	{"answer": "FALSE"}	[]	数据按字节编址，但是可以按照字节、字（16位）、双字（32位）访问。\n六. 完型填空（共1题，4分）	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/08-第3章作业-2nd.txt#16.5	第3章作业-2nd 待批阅 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
602	3	\N	\N	question_group	medium	写出下列十进制各数的原码、反码和补码，机器数长度为8位：\n（注：符号位和最高有效位之间，整数：不写“，”；小数：请写“.”）	[]	{}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/09-第3章作业-1st.txt#1	第3章作业-1st 已完成 智能分析	f	t	2026-06-02 03:00:20.17898+00	2026-06-02 03:00:20.17898+00	f	\N	0	0	0	0	0	0
164	3	\N	602	fill_blank	medium	（1）0 [0]原= ；[0]反= ；[0]补= ；\n这里，0为整数。	[]	{"blanks": [{"index": 1, "answer": "00000000", "acceptable_answers": ["10000000", "00000000或10000000", "00000000/10000000", "00000000或者10000000", "00000000和10000000", "00000000、10000000", "00000000", "10000000"]}, {"index": 2, "answer": "00000000", "acceptable_answers": ["11111111", "00000000或11111111", "00000000/11111111", "00000000或者11111111", "00000000和11111111", "00000000、11111111", "00000000", "11111111"]}, {"index": 3, "answer": "00000000", "acceptable_answers": []}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/09-第3章作业-1st.txt#1.1	第3章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
165	3	\N	602	fill_blank	medium	（2）-127 [-127]原= ；[-127]反= ；[-127]补= ；	[]	{"blanks": [{"index": 1, "answer": "11111111", "acceptable_answers": ["1,1111111", "1，1111111"]}, {"index": 2, "answer": "10000000", "acceptable_answers": ["1，0000000", "1,0000000"]}, {"index": 3, "answer": "10000001", "acceptable_answers": ["1，0000001", "1,0000001"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/09-第3章作业-1st.txt#1.2	第3章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
166	3	\N	602	fill_blank	medium	（3）-0.5 [-0.5]原= ；[-0.5]反= ；[-0.5]补= ；	[]	{"blanks": [{"index": 1, "answer": "1.1000000", "acceptable_answers": []}, {"index": 2, "answer": "1.0111111", "acceptable_answers": []}, {"index": 3, "answer": "1.1000000", "acceptable_answers": []}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/09-第3章作业-1st.txt#1.3	第3章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
167	3	\N	602	fill_blank	medium	（4）-19/128 [-19/128]原= ；[-19/128]反= ；[-19/128]补= ；	[]	{"blanks": [{"index": 1, "answer": "1.0010011", "acceptable_answers": []}, {"index": 2, "answer": "1.1101100", "acceptable_answers": []}, {"index": 3, "answer": "1.1101101", "acceptable_answers": []}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/09-第3章作业-1st.txt#1.4	第3章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
168	3	\N	602	fill_blank	medium	（5）100 [100]原= ；[100]反= ；[100]补= ；	[]	{"blanks": [{"index": 1, "answer": "01100100", "acceptable_answers": ["0,1100100", "0，1100100"]}, {"index": 2, "answer": "01100100", "acceptable_answers": ["0,1100100", "0，1100100"]}, {"index": 3, "answer": "01100100", "acceptable_answers": ["0,1100100", "0，1100100"]}]}	[]		/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/09-第3章作业-1st.txt#1.5	第3章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
603	3	\N	\N	question_group	medium	设某机器数字长为8位，有两个数的16进制表示形式为9CH和FFH，问：若它们分别表示为下列格式的机器数时，其对应的十进制真值是多少？（可以写成分数或者小数，例如-1/8，或者-0.125）	[]	{}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/09-第3章作业-1st.txt#2	第3章作业-1st 已完成 智能分析	f	t	2026-06-02 03:00:20.17898+00	2026-06-02 03:00:20.17898+00	f	\N	0	0	0	0	0	0
169	3	\N	603	fill_blank	medium	无符号整数；\n9CH对应的十进制真值是：\nFFH对应的十进制真值是：	[]	{"blanks": [{"index": 1, "answer": "156", "acceptable_answers": ["+156"]}, {"index": 2, "answer": "255", "acceptable_answers": ["+255"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/09-第3章作业-1st.txt#2.1	第3章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
170	3	\N	603	fill_blank	medium	原码表示的定点整数；\n9CH对应的十进制真值是：\nFFH对应的十进制真值是：	[]	{"blanks": [{"index": 1, "answer": "-28", "acceptable_answers": []}, {"index": 2, "answer": "-127", "acceptable_answers": []}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/09-第3章作业-1st.txt#2.2	第3章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
171	3	\N	603	fill_blank	medium	原码表示的定点小数；\n9CH对应的十进制真值是：\nFFH对应的十进制真值是：	[]	{"blanks": [{"index": 1, "answer": "-28/128", "acceptable_answers": ["-0.21875", "-7/32", "-0.21875（即-7/32）"]}, {"index": 2, "answer": "-127/128", "acceptable_answers": ["-0.9921875", "-0.9921875（即-127/128）", "-(1-2^ -7 )"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/09-第3章作业-1st.txt#2.3	第3章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
172	3	\N	603	fill_blank	medium	补码表示的定点整数；\n9CH对应的十进制真值是：\nFFH对应的十进制真值是：	[]	{"blanks": [{"index": 1, "answer": "-100", "acceptable_answers": []}, {"index": 2, "answer": "-1", "acceptable_answers": []}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/09-第3章作业-1st.txt#2.4	第3章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
173	3	\N	603	fill_blank	medium	补码表示的定点小数；\n9CH对应的十进制真值是：\nFFH对应的十进制真值是：	[]	{"blanks": [{"index": 1, "answer": "-100/128", "acceptable_answers": ["-0.78125", "-25/32"]}, {"index": 2, "answer": "-1/128", "acceptable_answers": ["-0.0078125"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/09-第3章作业-1st.txt#2.5	第3章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
174	3	\N	603	fill_blank	medium	反码表示的定点整数；\n9CH对应的十进制真值是：\nFFH对应的十进制真值是：	[]	{"blanks": [{"index": 1, "answer": "-99", "acceptable_answers": []}, {"index": 2, "answer": "-0", "acceptable_answers": ["0"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/09-第3章作业-1st.txt#2.6	第3章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
175	3	\N	603	fill_blank	medium	移码表示的定点整数；\n9CH对应的十进制真值是：\nFFH对应的十进制真值是：	[]	{"blanks": [{"index": 1, "answer": "28", "acceptable_answers": ["+28"]}, {"index": 2, "answer": "127", "acceptable_answers": ["+127"]}]}	[]	二. 填空题（共3题，39分）	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/09-第3章作业-1st.txt#2.7	第3章作业-1st 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
604	1	\N	\N	question_group	medium	计算机中有以下三种语言：	[]	{}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/10-第1章作业.txt#18	第1章作业 已完成 智能分析	f	t	2026-06-02 03:00:20.17898+00	2026-06-02 03:00:20.17898+00	f	\N	0	0	0	0	0	0
194	1	\N	604	single_choice	medium	直接能在计算机硬件上执行的语言是：	[{"key": "A", "text": "机器语言"}, {"key": "B", "text": "汇编语言"}, {"key": "C", "text": "高级语言"}]	{"answer": "A"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/10-第1章作业.txt#18.1	第1章作业 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
195	1	\N	604	multiple_choice	medium	面向机器的语言有：	[{"key": "A", "text": "机器语言"}, {"key": "B", "text": "汇编语言"}, {"key": "C", "text": "高级语言"}]	{"answer": ["A", "B"]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/10-第1章作业.txt#18.2	第1章作业 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
196	1	\N	604	single_choice	medium	面向用户的语言有：	[{"key": "A", "text": "机器语言"}, {"key": "B", "text": "汇编语言"}, {"key": "C", "text": "高级语言"}]	{"answer": "C"}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/10-第1章作业.txt#18.3	第1章作业 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
197	1	\N	604	multiple_choice	medium	符号语言有：	[{"key": "A", "text": "机器语言"}, {"key": "B", "text": "汇编语言"}, {"key": "C", "text": "高级语言"}]	{"answer": ["B", "C"]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/10-第1章作业.txt#18.4	第1章作业 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
198	1	\N	604	multiple_choice	medium	需要翻译后才能执行的语言是：	[{"key": "A", "text": "机器语言"}, {"key": "B", "text": "汇编语言"}, {"key": "C", "text": "高级语言"}]	{"answer": ["B", "C"]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/10-第1章作业.txt#18.5	第1章作业 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
605	1	\N	\N	question_group	medium	某指令集体系结构包含算术逻辑运算、浮点处理、数据传送、控制转移四类指令，有两种不同的实现方式M1和M2，对应的时钟频率为2.5GHz和3GHz。在M1和M2上运行一个基准测试程序X，它所包含的各类指令比例及CPI如下表所示：\n指令类型\n算术运算\n浮点处理\n数据传送\n控制转移\n在基准测试程序X中的比例\n30%\n10%\n40%\n20%\nM1的CPI\n1\n3\n2\n3\nM2的CPI\n2\n3\n2\n2	[]	{}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/10-第1章作业.txt#19	第1章作业 已完成 智能分析	f	t	2026-06-02 03:00:20.17898+00	2026-06-02 03:00:20.17898+00	f	\N	0	0	0	0	0	0
199	1	\N	605	fill_blank	medium	M1的平均CPI是（ 1 ），M2的平均CPI是（ 2 ），（ 3 ）比较快？（第3空直接填M1或者M2）	[]	{"blanks": [{"index": 1, "answer": "2.0", "acceptable_answers": ["2"]}, {"index": 2, "answer": "2.1", "acceptable_answers": []}, {"index": 3, "answer": "M1", "acceptable_answers": ["m1"]}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/10-第1章作业.txt#19.1	第1章作业 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
200	1	\N	605	fill_blank	medium	M1的MIPS指标为（ 1 ）MIPS；M2的MIPS指标为（ 2 ）MIPS；从MIPS指标看，（ 3 ）更快？\n（MIPS指标取整数，第3空直接填M1或者M2）	[]	{"blanks": [{"index": 1, "answer": "1250", "acceptable_answers": []}, {"index": 2, "answer": "1429", "acceptable_answers": []}, {"index": 3, "answer": "M2", "acceptable_answers": []}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/10-第1章作业.txt#19.2	第1章作业 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
201	1	\N	605	fill_blank	medium	M1和M2运行X所需时间之比为多少？（取2位小数）	[]	{"blanks": [{"index": 1, "answer": "1.14\\n六. 填空题（共1题，6分）", "acceptable_answers": []}]}	[]	\N	/Users/yzh666/workspace/comp-org-review-assistant/materials/homework-examples/raw/10-第1章作业.txt#19.3	第1章作业 已完成 智能分析	f	t	2026-06-01 12:35:28.19546+00	2026-06-01 12:35:28.19546+00	f	\N	0	0	0	0	0	0
316	2	\N	\N	multiple_choice	easy	总线特性包括哪几类？	[{"key": "A", "text": "电气特性"}, {"key": "B", "text": "机械特性"}, {"key": "C", "text": "功能特性"}, {"key": "D", "text": "时间特性"}]	{"answer": ["A", "B", "C", "D"]}	[]	根据知识块[ch02-s002-01]和[ch02-s008-01]，总线特性明确包括电气特性、机械特性、功能特性和时间特性这四类。其他选项如“协议特性”等不在给定知识块范围内。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	1	0	0	0	0
318	2	\N	\N	single_choice	easy	在集中式总线判优方式中，哪种方式是通过一个计数器循环查询各设备来确定总线使用权的？	[{"key": "A", "text": "链式查询"}, {"key": "B", "text": "计数器定时查询"}, {"key": "C", "text": "独立请求"}, {"key": "D", "text": "分布式判优"}]	{"answer": "B"}	[]	根据知识块[ch02-s006-01]和[ch02-s008-01]，集中式判优的三种方式是链式查询、计数器定时查询和独立请求方式。计数器定时查询正是通过一个计数器循环查询各设备来决定总线使用权的。链式查询通过硬件链路顺序查询，独立请求由每个设备有独立的请求/响应线，分布式判优不属于集中式。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	1	0	0	0	0
320	2	\N	\N	fill_blank	medium	若某总线宽度为64位，时钟频率为800MHz，每个时钟周期可传送1次数据，则该总线的理论带宽为______GB/s。	[]	{"blanks": [{"index": 1, "answer": "6.4", "acceptable_answers": ["6.4", "6.4GB/s"]}]}	[]	根据总线带宽公式：总线带宽 = 总线宽度(bit)/8 × 总线频率 × 每周期传送次数。代入数据：(64 / 8) × 800M × 1 = 8 × 800MB/s = 6400MB/s = 6.4GB/s。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	1	0	0	0	0
323	2	\N	\N	fill_blank	medium	总线的四类特性是______特性、______特性、______特性和______特性。	[]	{"blanks": [{"index": 1, "answer": "电气", "acceptable_answers": ["电气"]}, {"index": 2, "answer": "机械", "acceptable_answers": ["机械"]}, {"index": 3, "answer": "功能", "acceptable_answers": ["功能"]}, {"index": 4, "answer": "时间", "acceptable_answers": ["时间"]}]}	[]	根据知识块明确总结的“总线四类特性：电气、机械、功能、时间”，本题为必须背下的核心概念，答案唯一。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	1	0	0	0	0
326	2	\N	\N	single_choice	medium	在集中式总线判优方式中，各设备的总线请求信号通过一条公共的请求线串行传递，优先级由设备离总线控制器的物理距离决定，这种方式是：	[{"key": "A", "text": "链式查询"}, {"key": "B", "text": "计数器定时查询"}, {"key": "C", "text": "独立请求"}, {"key": "D", "text": "分布式判优"}]	{"answer": "A"}	[]	链式查询方式的特点是，总线允许信号（BG）像链条一样串行连接各设备，离总线控制器最近的设备优先级最高。计数器定时查询通过设备地址查询，独立请求为每个设备设置独立的请求线和允许线，分布式判优逻辑分散在各模块中。因此，描述符合链式查询的特点。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	1	0	0	0	0
335	2	\N	\N	single_choice	easy	以下哪一项不属于总线的基本特性？	[{"key": "A", "text": "电气特性"}, {"key": "B", "text": "机械特性"}, {"key": "C", "text": "物理特性"}, {"key": "D", "text": "时间特性"}]	{"answer": "C"}	[]	根据知识块，总线的基本特性包括电气特性、机械特性、功能特性和时间特性。选项C“物理特性”不是总线的基本特性之一，它描述的是物理角度下的总线，如“一组实现互连和通信的导线”，但不是其技术特性分类。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	1	0	0	0	0
338	2	\N	\N	single_choice	easy	在集中式总线判优方式中，哪一种方式通过一个公共的计数器来查询各设备？	[{"key": "A", "text": "链式查询"}, {"key": "B", "text": "计数器定时查询"}, {"key": "C", "text": "独立请求"}, {"key": "D", "text": "分布式判优"}]	{"answer": "B"}	[]	根据知识块，集中式判优常见有链式查询、计数器定时查询、独立请求方式。其中，计数器定时查询方式是通过一个公共的计数器来查询各设备。选项A链式查询是通过菊花链信号传递查询；选项C独立请求是每个设备有独立的请求和响应线；选项D分布式判优不属于集中式判优。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	1	0	0	0	0
349	2	\N	\N	single_choice	medium	同步通信与异步通信的主要区别在于？	[{"key": "A", "text": "同步通信靠请求/应答握手，异步通信靠统一时钟"}, {"key": "B", "text": "同步通信靠统一时钟，异步通信靠请求/应答握手"}, {"key": "C", "text": "同步通信只能用于并行总线，异步通信只能用于串行总线"}, {"key": "D", "text": "同步通信速度慢，异步通信速度快"}]	{"answer": "B"}	[]	根据知识块[ch02-s006-01]，通信定时包括同步通信、异步通信和半同步通信。同步通信靠统一时钟协调，异步通信靠请求/应答（握手）方式协调。选项A将两者的特点颠倒了；选项C和D描述的关系在给定知识块中没有依据，且与常见理解不符。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	1	0	0	0	0
355	2	\N	\N	single_choice	easy	根据总线的功能分类，以下哪一种总线通常由CPU发出，用于指定要访问的存储单元或I/O端口地址？	[{"key": "A", "text": "数据总线（DB）"}, {"key": "B", "text": "地址总线（AB）"}, {"key": "C", "text": "控制总线（CB）"}, {"key": "D", "text": "片内总线"}]	{"answer": "B"}	[]	地址总线（AB）的功能是传送地址信号，通常由CPU（主设备）发出，用于确定要访问的存储单元或I/O端口，从而决定系统的寻址范围。数据总线（DB）主要用于传送数据，通常是双向的。控制总线（CB）传送各种控制信号。片内总线是按位置和层次分类的总线，不是按功能分类的。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	1	0	0	0	0
356	2	\N	\N	multiple_choice	easy	总线的特性是描述总线的重要方面。下列哪些属于总线的基本特性？	[{"key": "A", "text": "电气特性"}, {"key": "B", "text": "机械特性"}, {"key": "C", "text": "功能特性"}, {"key": "D", "text": "时间特性"}, {"key": "E", "text": "成本特性"}]	{"answer": ["A", "B", "C", "D"]}	[]	根据知识块，总线的特性包括电气特性、机械特性、功能特性和时间特性。这四类特性从不同角度描述了总线的规范。成本特性不是总线的基本技术特性范畴。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	1	0	0	0	0
359	2	\N	\N	single_choice	easy	为了克服单总线结构容易形成通信瓶颈的缺点，现代计算机系统常采用哪种结构来提高并发性和扩展性？	[{"key": "A", "text": "单总线结构"}, {"key": "B", "text": "多总线结构"}, {"key": "C", "text": "环形总线结构"}, {"key": "D", "text": "星形总线结构"}]	{"answer": "B"}	[]	根据知识块，单总线结构虽然简单、成本低，但所有部件共享一条通路，容易形成瓶颈。而多总线结构把CPU-存储器高速通路和I/O通路分开，可以提高并发性和扩展性，从而克服单总线的缺点。环形总线和星形总线是网络拓扑概念，不是本章讨论的总线系统结构分类。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	1	0	0	0	0
360	2	\N	\N	fill_blank	medium	总线是一组带有电气、机械、功能和______约定的公共通信通道。	[]	{"blanks": [{"index": 1, "answer": "时序", "acceptable_answers": ["时序", "时间"]}]}	[]	根据知识块，总线特性包括电气、机械、功能和时间特性。题目中“时序”与“时间”特性含义一致，都指总线信号的时间关系约定。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	1	0	0	0	0
363	2	\N	\N	fill_blank	medium	集中式总线判优的三种常见方式是：链式查询、______定时查询和独立请求方式。	[]	{"blanks": [{"index": 1, "answer": "计数器", "acceptable_answers": ["计数器"]}]}	[]	根据知识块，集中式判优常见有链式查询、计数器定时查询、独立请求方式。填入“计数器”即可完整表述第二种方式。	ai:model-draft;chunks=ch02-s001-01,ch02-s002-01,ch02-s003-01,ch02-s004-01,ch02-s005-01,ch02-s006-01,ch02-s007-01,ch02-s008-01	AI题目生成	t	t	2026-06-01 14:59:09.7832+00	2026-06-01 14:59:09.7832+00	f	verified	0	1	0	0	0	0
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: comp_org
--

COPY public.users (id, student_id, password_hash, nickname, created_at, updated_at) FROM stdin;
1	24050823	$2b$12$Oapzd.kbYDFCmAwDZc11P.TusREjWlA1wR7btkDq0th..AdRVl2h.	神	2026-06-02 07:19:53.47339+00	2026-06-02 07:19:53.47339+00
2	99060201	$2b$12$Be0GEd5.BVcn.fgMoARyHeEz.sJVU9VH8T.mRFMsza73WDRhmaxxm	Codex Preview	2026-06-02 12:22:33.613164+00	2026-06-02 12:22:33.613164+00
\.


--
-- Data for Name: wrong_questions; Type: TABLE DATA; Schema: public; Owner: comp_org
--

COPY public.wrong_questions (id, user_id, question_id, wrong_count, last_wrong_at, mastered) FROM stdin;
1	demo	199	1	2026-06-01 12:48:52.322974+00	f
2	demo	192	1	2026-06-01 12:48:52.322974+00	f
21	demo	8	1	2026-06-01 14:54:42.497253+00	f
30	anon-2f10427c-5413-46a7-ac98-9d64c60a4e30	340	1	2026-06-02 06:04:48.161111+00	f
31	anon-2f10427c-5413-46a7-ac98-9d64c60a4e30	320	1	2026-06-02 06:04:48.161111+00	f
35	1	295	1	2026-06-02 09:24:44.245024+00	t
34	1	202	2	2026-06-02 12:46:48.727158+00	f
36	1	1	1	2026-06-02 12:46:48.71574+00	f
37	1	183	1	2026-06-02 12:46:48.71574+00	f
38	2	301	1	2026-06-02 12:51:56.192654+00	f
\.


--
-- Name: answer_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: comp_org
--

SELECT pg_catalog.setval('public.answer_records_id_seq', 785, true);


--
-- Name: chapters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: comp_org
--

SELECT pg_catalog.setval('public.chapters_id_seq', 9, true);


--
-- Name: knowledge_chunks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: comp_org
--

SELECT pg_catalog.setval('public.knowledge_chunks_id_seq', 380, true);


--
-- Name: knowledge_points_id_seq; Type: SEQUENCE SET; Schema: public; Owner: comp_org
--

SELECT pg_catalog.setval('public.knowledge_points_id_seq', 95, true);


--
-- Name: practice_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: comp_org
--

SELECT pg_catalog.setval('public.practice_sessions_id_seq', 270, true);


--
-- Name: question_feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: comp_org
--

SELECT pg_catalog.setval('public.question_feedback_id_seq', 41, true);


--
-- Name: questions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: comp_org
--

SELECT pg_catalog.setval('public.questions_id_seq', 698, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: comp_org
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: wrong_questions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: comp_org
--

SELECT pg_catalog.setval('public.wrong_questions_id_seq', 38, true);


--
-- Name: answer_records answer_records_pkey; Type: CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.answer_records
    ADD CONSTRAINT answer_records_pkey PRIMARY KEY (id);


--
-- Name: answer_records answer_records_session_id_question_id_key; Type: CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.answer_records
    ADD CONSTRAINT answer_records_session_id_question_id_key UNIQUE (session_id, question_id);


--
-- Name: chapters chapters_order_index_key; Type: CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.chapters
    ADD CONSTRAINT chapters_order_index_key UNIQUE (order_index);


--
-- Name: chapters chapters_pkey; Type: CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.chapters
    ADD CONSTRAINT chapters_pkey PRIMARY KEY (id);


--
-- Name: chapters chapters_source_file_key; Type: CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.chapters
    ADD CONSTRAINT chapters_source_file_key UNIQUE (source_file);


--
-- Name: knowledge_chunks knowledge_chunks_chunk_id_key; Type: CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.knowledge_chunks
    ADD CONSTRAINT knowledge_chunks_chunk_id_key UNIQUE (chunk_id);


--
-- Name: knowledge_chunks knowledge_chunks_pkey; Type: CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.knowledge_chunks
    ADD CONSTRAINT knowledge_chunks_pkey PRIMARY KEY (id);


--
-- Name: knowledge_points knowledge_points_chapter_id_name_key; Type: CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.knowledge_points
    ADD CONSTRAINT knowledge_points_chapter_id_name_key UNIQUE (chapter_id, name);


--
-- Name: knowledge_points knowledge_points_pkey; Type: CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.knowledge_points
    ADD CONSTRAINT knowledge_points_pkey PRIMARY KEY (id);


--
-- Name: practice_sessions practice_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.practice_sessions
    ADD CONSTRAINT practice_sessions_pkey PRIMARY KEY (id);


--
-- Name: question_feedback question_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.question_feedback
    ADD CONSTRAINT question_feedback_pkey PRIMARY KEY (id);


--
-- Name: question_feedback question_feedback_user_id_question_id_key; Type: CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.question_feedback
    ADD CONSTRAINT question_feedback_user_id_question_id_key UNIQUE (user_id, question_id);


--
-- Name: questions questions_pkey; Type: CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_student_id_key; Type: CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_student_id_key UNIQUE (student_id);


--
-- Name: wrong_questions wrong_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.wrong_questions
    ADD CONSTRAINT wrong_questions_pkey PRIMARY KEY (id);


--
-- Name: wrong_questions wrong_questions_user_id_question_id_key; Type: CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.wrong_questions
    ADD CONSTRAINT wrong_questions_user_id_question_id_key UNIQUE (user_id, question_id);


--
-- Name: idx_answer_records_session_id; Type: INDEX; Schema: public; Owner: comp_org
--

CREATE INDEX idx_answer_records_session_id ON public.answer_records USING btree (session_id);


--
-- Name: idx_knowledge_chunks_chapter_id; Type: INDEX; Schema: public; Owner: comp_org
--

CREATE INDEX idx_knowledge_chunks_chapter_id ON public.knowledge_chunks USING btree (chapter_id);


--
-- Name: idx_knowledge_points_chapter_id; Type: INDEX; Schema: public; Owner: comp_org
--

CREATE INDEX idx_knowledge_points_chapter_id ON public.knowledge_points USING btree (chapter_id);


--
-- Name: idx_practice_sessions_user_id; Type: INDEX; Schema: public; Owner: comp_org
--

CREATE INDEX idx_practice_sessions_user_id ON public.practice_sessions USING btree (user_id);


--
-- Name: idx_question_feedback_question_id; Type: INDEX; Schema: public; Owner: comp_org
--

CREATE INDEX idx_question_feedback_question_id ON public.question_feedback USING btree (question_id);


--
-- Name: idx_questions_ai_status; Type: INDEX; Schema: public; Owner: comp_org
--

CREATE INDEX idx_questions_ai_status ON public.questions USING btree (ai_status) WHERE (ai_status IS NOT NULL);


--
-- Name: idx_questions_chapter_type_reviewed; Type: INDEX; Schema: public; Owner: comp_org
--

CREATE INDEX idx_questions_chapter_type_reviewed ON public.questions USING btree (chapter_id, type, is_reviewed);


--
-- Name: idx_questions_parent_question_id; Type: INDEX; Schema: public; Owner: comp_org
--

CREATE INDEX idx_questions_parent_question_id ON public.questions USING btree (parent_question_id);


--
-- Name: idx_users_student_id; Type: INDEX; Schema: public; Owner: comp_org
--

CREATE INDEX idx_users_student_id ON public.users USING btree (student_id);


--
-- Name: idx_wrong_questions_user_mastered; Type: INDEX; Schema: public; Owner: comp_org
--

CREATE INDEX idx_wrong_questions_user_mastered ON public.wrong_questions USING btree (user_id, mastered);


--
-- Name: answer_records answer_records_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.answer_records
    ADD CONSTRAINT answer_records_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.questions(id) ON DELETE RESTRICT;


--
-- Name: answer_records answer_records_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.answer_records
    ADD CONSTRAINT answer_records_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.practice_sessions(id) ON DELETE CASCADE;


--
-- Name: knowledge_chunks knowledge_chunks_chapter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.knowledge_chunks
    ADD CONSTRAINT knowledge_chunks_chapter_id_fkey FOREIGN KEY (chapter_id) REFERENCES public.chapters(id) ON DELETE CASCADE;


--
-- Name: knowledge_points knowledge_points_chapter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.knowledge_points
    ADD CONSTRAINT knowledge_points_chapter_id_fkey FOREIGN KEY (chapter_id) REFERENCES public.chapters(id) ON DELETE CASCADE;


--
-- Name: practice_sessions practice_sessions_chapter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.practice_sessions
    ADD CONSTRAINT practice_sessions_chapter_id_fkey FOREIGN KEY (chapter_id) REFERENCES public.chapters(id) ON DELETE SET NULL;


--
-- Name: question_feedback question_feedback_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.question_feedback
    ADD CONSTRAINT question_feedback_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.questions(id) ON DELETE CASCADE;


--
-- Name: questions questions_chapter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_chapter_id_fkey FOREIGN KEY (chapter_id) REFERENCES public.chapters(id) ON DELETE RESTRICT;


--
-- Name: questions questions_knowledge_point_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_knowledge_point_id_fkey FOREIGN KEY (knowledge_point_id) REFERENCES public.knowledge_points(id) ON DELETE SET NULL;


--
-- Name: questions questions_parent_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.questions
    ADD CONSTRAINT questions_parent_question_id_fkey FOREIGN KEY (parent_question_id) REFERENCES public.questions(id) ON DELETE CASCADE;


--
-- Name: wrong_questions wrong_questions_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: comp_org
--

ALTER TABLE ONLY public.wrong_questions
    ADD CONSTRAINT wrong_questions_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.questions(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict gLbEBwcZ2cZdKocsJf19bfdyAUGqDDabh6q7ZmJfnIAQ1beCApx2LpqN3xhPbQj

